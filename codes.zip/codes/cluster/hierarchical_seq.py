"""
@Type doc
@Author xjp
@CreateDate 2025-04-07_21:04:58
@Description 基于序列版的层次聚类
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import os
import sys
sys.path.append("../")

from mytools import myFile, groupFlow
from gensim.models import Word2Vec
import numpy as np

#from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import AgglomerativeClustering
import math


"""
# 1.读取数据
name = "o2oa_user_1"
rootPath = "E:/doctor/小论文/流量分析/实验/dataset/res/SS/"

inputPath = os.path.join(rootPath,name+".json")


data = myFile.loadJson(inputPath)

# 2.分割数据
# 分组数据对象
group = groupFlow.GroupFlow()

# (1)按照ip分组数据
data_ip = group.groupByIp(data)


# (2).按照端口对划分数据
data_port = []
for data_temp in data_ip:
    data_port_temp = group.groupByPort(data_temp)
    data_port.extend(data_port_temp)
    


# (3).按照时间间隔分割数据
data_time = []
for flows in data_port:
    data_time.extend(group.groupByTimeInterval(flows))

data = data_time


# 3.清除干扰数据
# 清除干扰数据(没有payload的流量数据)和流量序列中流量数量小于一定数值的数据
data_temp = []
for d in data:
    if len(d) <=1:
        continue
    flag = False
    # 先判断是否有payload
    for flow in d:
        if flow["payload"] != "":
            flag  =True
            break
    if flag:
        data_temp.append(d)

data = data_temp
"""

def hierarchical(data):

    # 4.提取特征(一个流量序列提取一组特征)
    features = []
    label_std = []

    for flows in data:
        # 处理每一个流量序列
        temp = []
        # 提取源端口
        temp.append(flows[0]["sport"])
        # 提取目的端口
        temp.append(flows[0]["dport"])
        # 提取流量数量
        temp.append(len(flows))
        # 提取持续时间
        temp.append(float(flows[-1]["time"]) - float(flows[0]["time"]))
        # 提取流量长度总和
        temp.append(sum(t["length"] for t in flows))
        # 提取流量长度均值
        temp.append(sum(t["length"] for t in flows)/len(flows))
        # 提取IP长度总和
        temp.append(sum(t["length_ip"] for t in flows))
        # 两条流量之间时间间隔的均值
        diff = []
        for i in range(len(flows)-1):
            diff.append(float(flows[i+1]["time"]) - float(flows[i]["time"]))
        if len(diff)!=0:
            temp.append(sum(diff)/len(diff))
        else:
            temp.append(0)
        # 提取payload数量不为空的流量数量
        count = 0
        for flow in flows:
            if flow["payload_text"] != "":
                count+=1
        temp.append(count)
        
        # 数据包到达速率
        temp.append((float(flows[-1]["time"]) - float(flows[0]["time"]))/len(flows))
        
        # 加入到总特征中
        features.append(temp)
        # 加入标签
        label = []
        for flow in flows:
            label.append(flow["label"])
        label_std.append(label)




    # 5.标准化
    scaler = StandardScaler()
    feature_sta = scaler.fit_transform(features)





    # 6.归一化
    scaler = MinMaxScaler()
    feature_nor = scaler.fit_transform(feature_sta)


    # 7.聚类计算

    hierarchical = AgglomerativeClustering(n_clusters=6)
    labels = hierarchical.fit_predict(feature_nor)




    # 8.统计聚类结果

    res = {}
    for i in range(len(labels)):
        if labels[i] not in res:
            res[labels[i]] = []
        res[labels[i]].extend(label_std[i])
    return res
"""
# 9.计算结果
def __calcIn(data):
    TP = 0
    FN = 0
    for key in data.keys():
        # 计算每一个类内的
        left  =0
        while left < len(data[key]) -1:
            right = left +1 
            while right < len(data[key]):
                if data[key][left] == data[key][right]:
                    TP +=1
                else:
                    FN +=1
                right +=1
            left +=1
    return TP, FN
def __calcOut(data):
    FP = 0
    keys = list(data.keys())
    left = 0
    while left < len(keys) - 1:
        right = left + 1
        while right < len(keys):
            for data1 in data[keys[left]]:
                for data2 in data[keys[right]]:
                    if data1 == data2 and "common" not in data1:
                        FP +=1
            right +=1
        left += 1
    return FP

def __clacRes(data:dict):
    TP, FN = __calcIn(data)
    FP = __calcOut(data)
    res = math.sqrt((TP/(TP+FP)*(TP/(TP+FN))))
    
    return res

final_res = __clacRes(res)
"""




