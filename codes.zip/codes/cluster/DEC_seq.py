"""
@Type doc
@Author xjp
@CreateDate 2025-04-07_21:48:47
@Description 基于流量序列的深度嵌入聚类(DEC)
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import numpy as np
import tensorflow as tf
from tensorflow.keras import layers
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from mytools import myFile, groupFlow
import os

# 0.定义自编码器模型
class Autoencoder(tf.keras.Model):
    def __init__(self, input_dim, encoding_dim):
        super(Autoencoder, self).__init__()
        self.encoder = tf.keras.Sequential([
            layers.Dense(encoding_dim, activation='relu', input_shape=(input_dim,))
        ])
        self.decoder = tf.keras.Sequential([
            layers.Dense(input_dim, activation="sigmoid")
        ])
    
    def call(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return decoded

"""
# 1.读取数据
name = "gitlab1"
rootPath = "E:/doctor/小论文/流量分析/实验/dataset/res/SS/"

inputPath = os.path.join(rootPath,name+".json")


data = myFile.loadJson(inputPath)

# 2.分割数据
# 分组数据对象
group = groupFlow.GroupFlow()

# (1)按照ip分组数据
data_ip = group.groupByIp(data)


# (2).按照端口对划分数据
data_port = []
for data_temp in data_ip:
    data_port_temp = group.groupByPort(data_temp)
    data_port.extend(data_port_temp)
    


# (3).按照时间间隔分割数据
data_time = []
for flows in data_port:
    data_time.extend(group.groupByTimeInterval(flows))

data = data_time


# 3.清除干扰数据
# 清除干扰数据(没有payload的流量数据)和流量序列中流量数量小于一定数值的数据
data_temp = []
for d in data:
    if len(d) <=1:
        continue
    flag = False
    # 先判断是否有payload
    for flow in d:
        if flow["payload"] != "":
            flag  =True
            break
    if flag:
        data_temp.append(d)

data = data_temp
"""

def dec(data):
# 4.提取特征(一个流量序列提取一组特征)
features = []
label_std = []

for flows in data:
    # 处理每一个流量序列
    temp = []
    # 提取源端口
    temp.append(flows[0]["sport"])
    # 提取目的端口
    temp.append(flows[0]["dport"])
    # 提取流量数量
    temp.append(len(flows))
    # 提取持续时间
    temp.append(float(flows[-1]["time"]) - float(flows[0]["time"]))
    # 提取流量长度总和
    temp.append(sum(t["length"] for t in flows))
    # 提取流量长度均值
    temp.append(sum(t["length"] for t in flows)/len(flows))
    # 提取IP长度总和
    temp.append(sum(t["length_ip"] for t in flows))
    # 两条流量之间时间间隔的均值
    diff = []
    for i in range(len(flows)-1):
        diff.append(float(flows[i+1]["time"]) - float(flows[i]["time"]))
    if len(diff)!=0:
        temp.append(sum(diff)/len(diff))
    else:
        temp.append(0)
    # 提取payload数量不为空的流量数量
    count = 0
    for flow in flows:
        if flow["payload"] != "":
            count+=1
    temp.append(count)
    
    # 数据包到达速率
    temp.append((float(flows[-1]["time"]) - float(flows[0]["time"]))/len(flows))
    
    # 加入到总特征中
    features.append(temp)
    # 加入标签
    label = []
    for flow in flows:
        label.append(flow["label"])
    label_std.append(label)




# 5.标准化
scaler = StandardScaler()
feature_sta = scaler.fit_transform(features)





# 6.归一化
scaler = MinMaxScaler()
feature_nor = scaler.fit_transform(feature_sta)


# 7.

input_dim = 10
x = np.random.randn(100,10)









