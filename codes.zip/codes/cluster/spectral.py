"""
@Type doc
@Author xjp
@CreateDate 2025-06-02_20:50:27
@Description kde聚类
@Version 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import os
import sys
sys.path.append("../")



#from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import SpectralClustering


def sc(data):
    # 4.提取特征(一个流量序列提取一组特征)
    features = []
    label_std = []

    for flows in data:
        # 处理每一个流量序列
        temp = []
        # 提取源端口
        temp.append(flows[0]["sport"])
        # 提取目的端口
        temp.append(flows[0]["dport"])
        # 提取流量数量
        temp.append(len(flows))
        # 提取持续时间
        temp.append(float(flows[-1]["time"]) - float(flows[0]["time"]))
        # 提取流量长度总和
        temp.append(sum(t["length"] for t in flows))
        # 提取流量长度均值
        temp.append(sum(t["length"] for t in flows)/len(flows))
        # 提取IP长度总和
        temp.append(sum(t["length_ip"] for t in flows))
        # 两条流量之间时间间隔的均值
        diff = []
        for i in range(len(flows)-1):
            diff.append(float(flows[i+1]["time"]) - float(flows[i]["time"]))
        if len(diff)!=0:
            temp.append(sum(diff)/len(diff))
        else:
            temp.append(0)
        # 提取payload数量不为空的流量数量
        count = 0
        for flow in flows:
            if flow["payload_text"] != "":
                count+=1
        temp.append(count)
        
        # 数据包到达速率
        temp.append((float(flows[-1]["time"]) - float(flows[0]["time"]))/len(flows))
        
        # 加入到总特征中
        features.append(temp)
        # 加入标签
        label = []
        for flow in flows:
            label.append(flow["label"])
        label_std.append(label)




    # 5.标准化
    scaler = StandardScaler()
    feature_sta = scaler.fit_transform(features)





    # 6.归一化
    scaler = MinMaxScaler()
    feature_nor = scaler.fit_transform(feature_sta)


    # 7.聚类计算
    # 注意eps的设置
    # gitlab 0.1
    
    # 初始化 DENCLUE（带宽=0.5，密度阈值=0.1）
    

    # 谱聚类（簇数=3，使用高斯核）
    sc = SpectralClustering(n_clusters=6, affinity='rbf', random_state=42)
    y_pred = sc.fit_predict(feature_nor)
    labels = sc.labels_

    # 8.统计聚类结果

    res = {}
    for i in range(len(labels)):
        if labels[i] not in res:
            res[labels[i]] = []
        res[labels[i]].extend(label_std[i])
    return res