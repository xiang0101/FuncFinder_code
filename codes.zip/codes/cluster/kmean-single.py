"""
@Type doc
@Author xjp
@CreateDate 2025-04-06_21:53:27
@Description 处理特征
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import os
import sys
sys.path.append("../")

from mytools import myFile
from gensim.models import Word2Vec
import numpy as np

#from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cluster import KMeans
import math

# 1.读取数据
name = "mysql1"
rootPath = "E:/doctor/小论文/流量分析/实验/dataset/res/SS/"

inputPath = os.path.join(rootPath,name+".json")


data = myFile.loadJson(inputPath)





# 2.提取对应的特征

def dealPayload(payload):
    sentences = [payload.split()]
    model = Word2Vec(sentences, min_count=1)
    vector_list = [model.wv[word] for word in sentences[0] if word in model.wv]
    if vector_list:
        payload_vector = np.mean(vector_list, axis=0)
    #pca = PCA(n_components=1)
    #res  =pca.fit_transform(payload_vector)
    res = sum(payload_vector) / len(payload_vector)
    return res

# 3.清除干扰数据
# 清除干扰数据(没有payload的流量数据)和流量序列中流量数量小于一定数值的数据
data_temp = []
for d in data:
    if len(d) <=1:
        continue
    flag = False
    # 先判断是否有payload
    for flow in d:
        if flow["payload"] != "":
            flag  =True
            break
    if flag:
        data_temp.append(d)

data = data_temp


# 4.提取特征

features = []
labels_std = []
preTime = 0
for flow in data:
    temp = []
    # 时间间隔
    if preTime == 0:
        temp.append(preTime)
    else:
        temp.append(float(flow["time"]) - preTime)
    preTime = float(flow["time"])
    # 源IP
    temp.append(flow["sip"])
    # 目的IP
    temp.append(flow["dip"])
    # 源端口
    temp.append(int(flow["sport"]))
    # 目的端口
    temp.append(int(flow["dport"]))
    # 包大小
    temp.append(int(flow["length"]))
    # IP包大小
    temp.append(int(flow["length_ip"]))
    # ttl
    temp.append(int(flow["ttl"]))
    # proto
    temp.append(int(flow["proto"]))
    
    payload = flow["payload"]
    # payload长度
    temp.append(len(payload))
    # payload
    #temp.append(flow["payload"])
    if payload != "":
        temp.append(dealPayload(payload))
    else:
        temp.append(0)
    
    features.append(temp)
    
    
    # 标签数据
    labels_std.append(flow["label"])


# 5.标准化处理

# 标准化所有的ip地址
index = 1
ip_dict ={}
for temp in features:
    if temp[1] not in ip_dict.keys():
        ip_dict[temp[1]] = index
        index +=1
    temp[1] = ip_dict[temp[1]]
    if temp[2] not in ip_dict.keys():
        ip_dict[temp[2]] = index
        index +=1
    temp[2] = ip_dict[temp[2]]


# 标准化数值特征
scaler = StandardScaler()
feature_sta = scaler.fit_transform(features)


# 6.归一化处理

scaler = MinMaxScaler()
feature_nor = scaler.fit_transform(feature_sta)



# 7.聚类
n_clusters = 6
kmeans = KMeans(n_clusters=n_clusters, random_state=42)
kmeans.fit(feature_nor)

labels = kmeans.labels_

res = {}
for i in range(len(labels)):
    if labels[i] not in res:
        res[labels[i]] = []
    res[labels[i]].append(labels_std[i])


# 8.计算结果
# 计算最终结果

def __calcIn(data):
    TP = 0
    FN = 0
    for key in data.keys():
        # 计算每一个类内的
        left  =0
        while left < len(data[key]) -1:
            right = left +1 
            while right < len(data[key]):
                if data[key][left] == data[key][right]:
                    TP +=1
                else:
                    FN +=1
                right +=1
            left +=1
    return TP, FN
def __calcOut(data):
    FP = 0
    keys = list(data.keys())
    left = 0
    while left < len(keys) - 1:
        right = left + 1
        while right < len(keys):
            for data1 in data[keys[left]]:
                for data2 in data[keys[right]]:
                    if data1 == data2 and "common" not in data1:
                        FP +=1
            right +=1
        left += 1
    return FP

def __clacRes(data:dict):
    TP, FN = __calcIn(data)
    FP = __calcOut(data)
    res = math.sqrt((TP/(TP+FP)*(TP/(TP+FN))))
    
    return res

final_res = __clacRes(res)






