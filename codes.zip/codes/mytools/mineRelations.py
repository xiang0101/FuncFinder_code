"""
@Type doc
@Author xjp
@CreateDate 2025-03-26_15:19:48
@Description 关系分析
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""



import json
from typing import List
from mytools.calcSim import simToken
import copy


"""
@Type class
@Author xjp
@CreateDate 2025-03-26_15:26:50
@Description 挖掘关系类
"""
class MineRealtiuons:
    def __init__(self, data:dict):
        self.data = copy.deepcopy(data)

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-26_15:23:37
    @Description 挖掘关系的主函数 
    @Param 
    @Return 
    """
    def mineRelatiuonsMain(self)->dict:
        
        # 复制一份数据
        data = copy.deepcopy(self.data)
        # 利用flag查找特定流量flow
        self.__flag_to_flow = {}
        # 将所有数据加入到一个时间序列中
        time_list = self.__addToTimeList(data)
        # 统计位置关系
        stat_pos = self.__countPosRelations(time_list)
        # 计算位置关系
        stat_final = self.__calcPosRelations(stat_pos)
        # 挖掘最终关系
        relations = self.__mineRelations(stat_final)
        return relations


    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-26_15:25:08
    @Description 将所有数据按照时间顺序加入到时间序列z 
    @Param 
    @Return 
    """
    def __addToTimeList(self, data:dict)->List:
        # 给数据按照顺序编号,并将数据中最早和最晚时间加入到队列中
        # 时间队列
        time_list = []
        for key in data.keys():
            index = 0
            for flows in data[key]:
                # 提取最早时间
                time_pre = float(flows[0]["time"])
                # 提取最晚时间
                if flows[-1]["time_last"] != "":
                    time_last = float(flows[-1]["time_last"])
                else:
                    time_last = float(flows[-1]["time"])
                # 将时间加入队列中
                name = key + "_" + str(index)
                index +=1
                time_list.append([time_pre,name,"s"])
                time_list.append([time_last,name,"e"])
                # 备份数据,可以直接通过name查找到数据
                self.__flag_to_flow[name] = flows

        # 时间序列按照时间从早到晚排序
        time_list.sort(key = lambda t: t[0])
        return time_list

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-26_15:40:11
    @Description  统计每一对同编号的s和e组合之前、之中、之后都出现哪些编号+序号
    @Param time_list:时间序列;time_thre:时间阈值;
    @Return 
    """
    def __countPosRelations(self, time_list:List, time_thre:int = 1)->dict:
        # 队首游标
        cursor_pre = 0
        # 队尾游标
        cursor_last = 1
        # 存储统计结果
        stat_res = {}
        while cursor_pre < len(time_list):
            # 获取当前流量信息
            flow = time_list[cursor_pre]
            if flow[2] == "e":
                cursor_pre += 1
                continue
            # 当前时间
            time_now = flow[0]
            # 将当前流量加入结果集中
            key = flow[1]
            stat_res[key] = {
                "pre":[],
                "mid":[],
                "last":[]
            }

            # 向前搜索
            # 存储队首位置
            cursor_temp = cursor_pre
            cursor_pre -= 1 
            while cursor_pre >=0:
                if (float(time_now) - float(time_list[cursor_pre][0])) > float(time_thre):
                    break
                # 加入pre中
                stat_res[key]["pre"].append(time_list[cursor_pre][1])
                cursor_pre -=1
            # 恢复索引
            cursor_pre = cursor_temp

            # 中间搜索
            cursor_last = cursor_pre + 1
            while key != time_list[cursor_last][1]:
                stat_res[key]["mid"].append(time_list[cursor_last][1])
                cursor_last += 1
            # 更新尾部时间信息
            time_last = time_list[cursor_last][0]
            # 向后搜索
            cursor_last += 1
            while cursor_last < len(time_list):
                if (float(time_list[cursor_last][0]) - float(time_last)) > float(time_thre):
                    break
                stat_res[key]["last"].append(time_list[cursor_last][1])
                cursor_last += 1
            # 更新队首
            cursor_pre +=1    

        return stat_res
    


    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-19_19:01:26
    @Description 处理交叉的数据,看最终该数据被分到那一组 
    @Param data:{"pre":[],"mid":[],"last":[]}
    @Return data:{"pre":[],"mid":[],"last":[]}
    """
    def __processCrossData(self,data:dict)->dict:
        pre = data["pre"]
        mid = data["mid"]
        last = data["last"]
        res = {
            "pre":[],
            "mid":[],
            "last":[]
        }
        # 存储所有的编号
        names = []
        # 先确认各个编号应该属于哪个组
        pre_dict = {}
        for p in pre:
            name = p.split("_")[0] + "_" + p.split("_")[1]
            if name not in pre_dict.keys():
                names.append(name)
                pre_dict[name] = 0
            pre_dict[name] += 1

        mid_dict = {}
        for p in mid:
            name = p.split("_")[0] + "_" + p.split("_")[1]
            if name not in mid_dict.keys():
                names.append(name)
                mid_dict[name] = 0
            mid_dict[name] += 1

        last_dict = {}
        for p in last:
            name = p.split("_")[0] + "_" + p.split("_")[1]
            if name not in last_dict.keys():
                names.append(name)
                last_dict[name] = 0
            last_dict[name] += 1
        # 确认编号归属
        flag_dict = {}
        for name in names:
            countPre = 0
            countMid = 0
            countLast = 0
            if name in pre_dict.keys():
                countPre = pre_dict[name]
            if name in mid_dict.keys():
                countMid = mid_dict[name]
            if name in last_dict.keys():
                countLast = last_dict[name] 
            if countPre >= countMid and countPre >= countLast:
                flag_dict[name] = "pre"
            elif countMid >= countPre and countMid >= countLast:
                flag_dict[name] = "mid"
            else:
                flag_dict[name] = "last"

        for p in pre:
            name = p.split("_")[0] + "_" + p.split("_")[1] 
            myList = res[flag_dict[name]]
            if p not in myList:
                myList.append(p)
        for p in mid:
            name = p.split("_")[0] + "_" + p.split("_")[1] 
            myList = res[flag_dict[name]]
            if p not in myList:
                myList.append(p)
        for p in last:
            name = p.split("_")[0] + "_" + p.split("_")[1] 
            myList = res[flag_dict[name]]
            if p not in myList:
                myList.append(p)
        return res

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-26_16:00:25
    @Description 统计每一对流量之前、之中、之后都出现了哪些关系 
    @Param 
    @Return 
    """
    def __calcPosRelations(self, stat_pos:dict)->dict:
        stat_res = copy.deepcopy(stat_pos)

        # 1.对统计后的数据去重
        for key1 in stat_res.keys():
            for key2 in stat_res[key1].keys():
                stat_res[key1][key2] = list(set(stat_res[key1][key2]))
        # 2.统计每个种类之前、之后、之中出现的其他流量
        stat_final = {}
        for key in stat_res.keys():
            name = str(key).split("_")[0]
            if name not in stat_final.keys():
                stat_final[name] = {
                    "pre":[],
                    "mid":[],
                    "last":[]
                }
            stat_final[name]["pre"].extend(stat_res[key]["pre"])
            stat_final[name]["mid"].extend(stat_res[key]["mid"])
            stat_final[name]["last"].extend(stat_res[key]["last"])
        stat_res = None

        # 3.处理统计结果数据
        # (1)去重数据
        for key in stat_final.keys():
            stat_final[key]["pre"] = list(set(stat_final[key]["pre"]))
            stat_final[key]["mid"] = list(set(stat_final[key]["mid"]))
            stat_final[key]["last"] = list(set(stat_final[key]["last"]))

        # (2)清除和自己编号相同的数据
        for key in stat_final.keys():
            name = str(key).split("_")[0]
            temp = []
            for f in stat_final[key]["pre"]:
                t = f.split("_")[0]
                if name != t:
                    temp.append(f)
            stat_final[key]["pre"] = temp
            temp = []
            for f in stat_final[key]["mid"]:
                t = f.split("_")[0]
                if name != t:
                    temp.append(f)
            stat_final[key]["mid"] = temp
            temp = []
            for f in stat_final[key]["last"]:
                t = f.split("_")[0]
                if name != t:
                    temp.append(f)
            stat_final[key]["last"] = temp
        # (3)处理交叉数据
        for key in stat_final.keys():
            stat_final[key] = self.__processCrossData(stat_final[key])


        # (4) 将数据中的最后一个标志删除
        for key in stat_final.keys():
            temp = []
            for f in stat_final[key]["pre"]:
                t = f.split("_")[0]
                temp.append(t)
            stat_final[key]["pre"] = temp
            temp = []
            for f in stat_final[key]["mid"]:
                t = f.split("_")[0]
                temp.append(t)
            stat_final[key]["mid"] = temp
            temp = []
            for f in stat_final[key]["last"]:
                t = f.split("_")[0]
                temp.append(t)
            stat_final[key]["last"] = temp
        return stat_final



    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-20_22:01:52
    @Description 判断两个流量组是否有关系 
    @Param 
    @Return 
    """
    def __getRel(self,totalCount1:int, totalCount2:int, count1:int, count2:int)->bool:
        # (1)条件1 有1个数据量在其总数的一定范围内
        if count1/totalCount1<0.8 and count2/totalCount2<0.8:
            return False
        # (2)条件2 两个数据量相差范围比较小
        if count1 >= count2:
            if count2 / count1 >= 0.8:
                return True
        else:
            if count1 /count2 >= 0.8:
                return True
        return False


    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-26_16:18:35
    @Description 挖掘最终的关系 
    @Param 
    @Return 
    """
    def __mineRelations(self, stat_final:dict)->dict:
        # 1.统计各个数据出现的数量
        stat_final_count = {}
        for key in stat_final.keys(): 
            stat_final_count[key] = {}
            
            for key2 in stat_final[key].keys():
                stat_final_count[key][key2] = {}
                for f in stat_final[key][key2]:
                    if f not in stat_final_count[key][key2].keys():
                        stat_final_count[key][key2][f] = 0
                    stat_final_count[key][key2][f] += 1
        # 2.统计流量总数
        flow_count = {}
        for key in stat_final_count.keys():
            flow_count[key] = 0

        for key in self.__flag_to_flow.keys():
            name = str(key).split("_")[0]
            flow_count[name] += 1

        # 3.统计关系
        relations = {
            "pl":[], # 前后关系
            "in":[] # 包含关系
        }


        for key in stat_final_count.keys():
            pre = stat_final_count[key]["pre"]
            mid = stat_final_count[key]["mid"]
            last = stat_final_count[key]["last"]
            for p in pre.keys():
                if key in stat_final_count[p]["last"].keys():
                    if self.__getRel(totalCount1=flow_count[key],totalCount2=flow_count[p],count1 = pre[p],count2= stat_final_count[p]["last"][key]):
                        # 有关系
                        #  前后关系
                        relations["pl"].append([p,key])
                        stat_final_count[p]["last"].pop(key)
            stat_final_count[key]["pre"] = {}
            for m in mid:
                if key in stat_final_count[m]["mid"].keys():
                    if self.__getRel(totalCount1=flow_count[key],totalCount2=flow_count[m],count1 = mid[m],count2= stat_final_count[m]["mid"][key]):
                        # 包含关系
                        relations["in"].append([m,key])
                        stat_final_count[m]["mid"].pop(key)
            stat_final_count[key]["mid"] = {}
            for l in last.keys():
                if key in stat_final_count[l]["pre"].keys():
                    if self.__getRel(totalCount1=flow_count[key],totalCount2=flow_count[l],count1 = last[l],count2= stat_final_count[l]["pre"][key]):
                        # 有关系
                        #  前后关系
                        relations["pl"].append([l,key])
                        stat_final_count[l]["pre"].pop(key)
            stat_final_count[key]["last"] = {}
        return relations








