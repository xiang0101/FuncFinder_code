"""
@Type doc
@Author xjp
@CreateDate 2025-03-24_17:40:14
@Description 包含合并流量的相关操作
@Version v1.0
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""


from typing import List
from . import compFlow
import copy


"""
@Type function
@Author xjp
@CreateDate 2025-03-24_19:13: 32
@Description 合并相反方向上的流量 
@Param 
@Return 
"""
def mergeDualFlow(flows:List):
    if len(flows) == 1:
        flows[0]["direction"] = "s"
        flows[0]["time_last"] = flows[0]["time"]
        return flows
    res = []
    index = 0
    while index < len(flows):
        # 先获取特征
        if index +1 == len(flows):
            f = copy.deepcopy(flows[index])
            f["direction"] = "s"
            f["time_last"] = f["time"]
            res.append(f)
            index += 1
            continue
        
        f = None
        if compFlow.compDualFlow(flows[index],flows[index+1]):
            # 此时两条流量数据可以合并为1条
            f = copy.deepcopy(flows[index])
            f["direction"] = "d"
            f["time_last"] = flows[index+1]["time"]
            index +=2
        if f == None:
            f = copy.deepcopy(flows[index])
            f["direction"] = "s"
            f["time_last"] = f["time"]
            index +=1 
        res.append(f)
    return res






"""
@Type function
@Author xjp
@CreateDate 2025-03-24_21:55:12
@Description 合并连续相同的流量 
@Param 
@Return 
"""
def mergeSameFlow(flows:List)->List:
    res = []
    left = 0
    right = 0
    while left < len(flows):
        right = left + 1
        while right < len(flows):
            # 比较两条流量是否相同
            if compFlow.compSameFlow(flows[left],flows[right]):
                right += 1
            else:
                right -= 1
                break
        # 超出范围则返回最后一条流量
        if right == len(flows):
            right -=1
        # 相等则说明没有相同的,添加1条即可
        f = copy.deepcopy(flows[left])
        if left == right:   
            f["count"] = 0         
            res.append(f)
            left +=1
        else:
            f["count"] = (right-left)
            if flows[right]["time_last"] != "":
                f["time_last"] = flows[right]["time_last"]
            else:
                f["time_last"] = flows[right]["time"]
            left = right + 1
            res.append(f)
    return res



"""
@Type function
@Author xjp
@CreateDate 2025-03-26_14:58:34
@Description 统计流量数据 
@Param 
@Return 
"""
def countFlow(flows:List)->int:
    res = 0
    for flow in flows:
        if flow["direction"] == "s":
            res += 1
            res += flow["count"]
        else:
            res += 2
            res += flow["count"]*2
    return res