"""
@Type doc
@Author xjp
@CreateDate 2025-03-13_09:49:11
@Description 计算相似度相关方法
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

# !!!后续修改为类,只加载一次模型就行


from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Sentence - BERT
#from sentence_transformers import SentenceTransformer
import regex as re


"""
@Type function
@Author xjp
@CreateDate 2025-03-13_09:50:20
@Description 计算两个文本是否相似
@Param 
@Return 
"""
def simText(text1:str, text2:str, simthre:float = 60.0)->bool:
    if text1 == text2:
        return True
    if text1 == "" or text2 == "":
        return False
    try:
        vectorizer = CountVectorizer()
        corpus = (text1, text2)
        vectors = vectorizer.fit_transform(corpus)
        similarity = cosine_similarity(vectors)
        sim = similarity[0][1]
    except:
        return False
    if (sim*100) < simthre:
        return False
    return True


"""
@Type function
@Author xjp
@CreateDate 2025-03-13_09:54:04
@Description 比较两条流量是否相同 
@Param 
@Return 
"""
def simFlow(flow1:dict, flow2:dict)->bool:
    # 不需要比较,排除在外的key
    externKeys = ["time","time_last","raw","count","flag",""]


"""
@Type function
@Author xjp
@CreateDate 2025-04-09_19:29:50
@Description 按照内容和类型的相似度比较算法 
@Param 
@Return 
"""
def compSimType(flow1:dict, flow2:dict)->bool:
    # 获取数据类型
    type1 = flow1["payload_type"]
    type2 = flow2["payload_type"]
    if type1 == type2:
        # 不存在payload直接相同
        if type1 == "none":
            return True
    else:
        return False
    payload1 = flow1["payload_text"]
    payload2 = flow2["payload_text"]
    # 判断是否为http请求
    if type1 == "http-req":
        # 先判断请求头中的key是否一致
        if not set(payload1.keys()) == set(payload2.keys()):
            return False

        # 判断请求类型是否一致
        if payload1["method"] != payload2["method"]:
            return False
        # 判断uri是否相似
        if simText(payload1["uri"], payload2["uri"]):
            # 判断参数类型是否一致
            if set(payload1["params"].keys()) != set(payload2["params"].keys()):
                return False
        else:
            return False
    # 判断是否为http响应
    elif type1 == "http-res":
        try:
            # 判断状态码是否相同
            if payload1["code"] != payload2["code"]:
                return False
            # 判断Server是否相同
            if "Server" in payload1["headers"].keys() and "Server" in payload2["headers"].keys():
                if payload1["headers"]["Server"] != payload2["headers"]["Server"]:
                    return False
            else:
                return False
            # 判断Content-Type是否相同
            if "Content-Type" in payload1["headers"].keys() and "Content-Type" in payload2["headers"].keys():
                if payload1["headers"]["Content-Type"] != payload2["headers"]["Content-Type"]:
                    return False
            else:
                return False
        except:
            return False
        return True
    elif type1 == "str":
        if not simText(payload1, payload2):
            return False
    elif type1 == "json":
        # 比较json格式
        keys1 = payload1.keys()
        keys2 = payload2.keys()
        if not set(keys1) == set(keys2):
            return False
    elif type1 == "num":
        return True
    elif type1 == "html":
        if not simText(payload1[:200],payload2[:200]):
            return False
    elif type1 == "bytes":
        return True
    elif type1 == "ini":
        if not simText(payload1[:200],payload2[:200]):
            return False
    elif type1 == "xml":
        if not simText(payload1[:200],payload2[:200]):
            return False

    return True



"""
@Type function
@Author xjp
@CreateDate 2025-04-13_17:50:56
@Description 完全相同匹配 
@Param 
@Return 
"""
def compAllType(flow1:dict, flow2:dict)->bool:
    # 获取信息
    sip1 = flow1["sip"]
    dip1 = flow1["dip"]

    sip2 = flow2["sip"]
    dip2 = flow2["dip"]
    
    sport1 = flow1["sport"]
    dport1 = flow1["dport"]

    sport2 = flow2["sport"]
    dport2 = flow2["dport"]

    # 判断是否有一个固定端口相同
    if (sport1 == sport2 and dport1 == dport2) or (sport1 == sport2 and dport1 != dport2) or (sport1 == dport2 and dport1 != sport2) or (dport1 == sport2 and sport1 != dport2) or (dport1 == dport2 and sport1 != sport2):
        pass
    else:
        return False

    # 获取数据类型
    type1 = flow1["payload_type"]
    type2 = flow2["payload_type"]
    if type1 == type2:
        # 不存在payload直接相同
        if type1 == "none":
            return True
    else:
        return False
    payload1 = flow1["payload_text"]
    payload2 = flow2["payload_text"]
    if payload1 == payload2:
        return True
    # 判断是否为http请求
    if type1 == "http-req":
        # 先判断请求头中的key是否一致
        if not set(payload1.keys()) == set(payload2.keys()):
            return False

        # 判断请求类型是否一致
        if payload1["method"] != payload2["method"]:
            return False
        # 判断uri是否相同
        if payload1["uri"]==payload2["uri"]:
            # 判断参数类型是否一致
            if set(payload1["params"].keys()) != set(payload2["params"].keys()):
                return False
            return True
        elif simText(payload1["uri"],payload2["uri"]):
            # 判断参数类型是否一致
            if set(payload1["params"].keys()) != set(payload2["params"].keys()):
                return False
            elif len(payload1["params"].keys()) ==0:
                return False
            else:
                # 判断参数值是否相同
                for key in payload1["params"].keys():
                    if payload1["params"][key]!=payload2["params"][key]:
                        return False
                return True
        else:
            return False
    # 判断是否为http响应
    elif type1 == "http-res":
        try:
            # 先判断key是否一致
            if not set(payload1.keys()) == set(payload2.keys()):
                return False

            # 判断状态码是否相同
            if payload1["code"] != payload2["code"]:
                return False
            # 判断Server是否相同
            if "Server" in payload1.keys() and "Server" in payload2.keys():
                if payload1["Server"] != payload2["Server"]:
                    return False
            
            # 判断Content-Type是否相同
            if "Content-Type" in payload1.keys() and "Content-Type" in payload2.keys():
                if payload1["Content-Type"] != payload2["Content-Type"]:
                    return False
            
        except:
            return False
        return True
    elif type1 == "str":
        if not simText(payload1, payload2):
            return False
    elif type1 == "json":
        try:
            # 比较json格式
            keys1 = payload1.keys()
            keys2 = payload2.keys()
            if not set(keys1) == set(keys2):
                return False
        except:
            return False
    elif type1 == "num":
        return True
    elif type1 == "html":
        if not simText(payload1[:200],payload2[:200]):
            return False
    elif type1 == "bytes":
        return True
    elif type1 == "ini":
        if not simText(payload1[:200],payload2[:200]):
            return False
    elif type1 == "xml":
        if not simText(payload1[:200],payload2[:200]):
            return False

    return True


"""
@Type function
@Author xjp
@CreateDate 2025-04-13_18:16:01
@Description 计算两个payload的得分 
@Param 
@Return 
"""
def calcSimScore(payload_type, payload1, payload2):
    # 先判断是何类型的payload
    if payload_type == "none":
        return 1
    elif payload_type == "str":
        if payload1 == payload2:
            return 2
        elif simText(payload1, payload2):
            return 1
        else:
            return 0
    elif payload_type == "json":
        if list(payload1.keys()).sort() == list(payload2.keys()).sort():
            for key in payload1.keys():
                if payload1[key] != payload2[key]:
                    return 1
            return 2
        return 0
    elif payload_type == "list":
        if payload1.sort() == payload2.sort():
            return 1
        return 0
    elif payload_type == "http-req":
        if list(payload1["headers"].keys()).sort() == list(payload2["headers"].keys()).sort():
            count =0
            # 判断请求方法
            if payload1["method"] != payload2["method"]:
                return 0
            # 判断uri
            if payload1["headers"]["uri"] == payload2["headers"]["uri"]:
                count +=1
            elif simText(payload1["headers"]["uri"],payload2["headers"]["uri"]):
                pass
            else:
                return 0
            # 判断参数
            # 获取参数
            payload1_params = payload1["headers"]["params"]
            payload2_params = payload2["headers"]["params"]
            # 先判断参数类型是否一致
            if list(payload1_params.keys()).sort() == list(payload2_params.keys()).sort():
                # 判断参数值是否一致
                for key in payload1_params.keys():
                    if payload1_params[key] != payload2_params[key]:
                        return count
                count +=1
                return count    
            else:
                return 0
        else:
            return 0

    elif payload_type == "http-res":
        if list(payload1["headers"].keys()).sort() == list(payload2["headers"].keys()).sort():
            if payload1["code"] != payload2["code"]:
                return 1
            for key in payload1["headers"].keys():
                if payload1["headers"][key] != payload2["headers"][key]:
                    return 1
            return 2
        return 0
    else:
        return 1




"""
@Type function
@Author xjp
@CreateDate 2025-03-20_19:00:28
@Description 按照token比较相似度 
@Param 
@Return 
"""
def simToken(text1:str, text2:str, thre:int=0.6)->bool:
    if text1 == "" and text2 == "":
        return True
    if text1 == "" or text2 == "":
        return False
    # 分割token

    #textTokens1 = text1.split(" ")
    #textTokens2 = text2.split(" ")
    # 20250331 更换新的分割算法
    delimiters = ',;| .=:_'
    pattern = f'[{delimiters}]'
    # 使用 re.split() 进行分割
    textTokens1 = re.split(pattern, text1[:200])
    textTokens2 = re.split(pattern, text2[:200])
    count = 0
    maxCount = max(len(textTokens1),len(textTokens2))
    index = 0
    while index < len(textTokens1) and index < len(textTokens2):
        if simText(textTokens1[index],textTokens2[index]):
            count += 1
        index += 1
    if (count/maxCount) >= thre:
        return True
    #elif (count/maxCount) >= 0.3:
        #if len(text1) == len(text2):
            #return True
    return False


"""
@Type function
@Author xjp
@CreateDate 2025-04-19_15:15:18
@Description token比较算法2.0 
@Param 
@Return 
"""
def simToken2(text1:str, text2:str, thre:int= 0.6)->bool:
    if text1 == text2:
        return True
    if text1 == "" or text2 == "":
        return False
    # 1.计算整体相似度
    try:
        vectorizer = CountVectorizer()
        corpus = (text1, text2)
        vectors = vectorizer.fit_transform(corpus)
        similarity = cosine_similarity(vectors)
        sim1 = similarity[0][1]
    except:
        return False
    # 2.计算token相似度
    delimiters = ',| =:/'
    pattern = f'[{delimiters}]'
    # 使用 re.split() 进行分割
    textTokens1 = re.split(pattern, text1[:200])
    textTokens2 = re.split(pattern, text2[:200])
    if len(textTokens1) != len(textTokens2):
        return False
    index = 0
    count = 0
    while index < len(textTokens1) and index < len(textTokens2):
        if simText(textTokens1[index],textTokens2[index]):
            count += 1
        index += 1
    sim2 = count/len(textTokens1)
    if (sim1*0.5+sim2*0.5) > thre:
        return True
    return False
"""
@Type function
@Author xjp
@CreateDate 2025-03-24_21:28:38
@Description Sentence - BERT(SBERT)是在 BERT 基础上改进的模型，专门用于生成句子级别的嵌入向量。通过微调 BERT 模型，使得生成的句子向量可以直接用于计算句子之间的相似度，计算速度比 BERT 快。
@Param 
@Return 

def simSentence(text1:str, text2:str, thre:int = 0.7)->bool:
    # 模型定义
    modelSentence = SentenceTransformer("../models/all-MiniLM-L6-v2")
    if text1 == text2:
        return True
    if text1 == "" or text2 == "":
        return False
    embedding1 = modelSentence.encode(text1)
    embedding2 = modelSentence.encode(text2)
    sim = cosine_similarity([embedding1],[embedding2])[0][0]
    if sim >= thre:
        return True
    return False
"""

"""
@Type function
@Author xjp
@CreateDate 2025-03-24_21:35:59
@Description RoBERTa（Robustly Optimized BERT Approach）,对 BERT 进行了改进，采用了更大的批量大小、更长的训练时间和更多的数据进行训练。在多个自然语言处理任务中表现优于 BERT，能够生成更准确的文本表示。(未测试)
@Param 
@Return 
"""
def simRoBERTa(text1:str, text2:str, thre:int = 0.7)->bool:
    from transformers import AutoTokenizer, AutoModel
    import torch
    from sklearn.metrics.pairwise import cosine_similarity

    # 加载预训练的 RoBERTa 模型和分词器
    tokenizer = AutoTokenizer.from_pretrained('roberta-base')
    model = AutoModel.from_pretrained('roberta-base')

    text1 = "The quick brown fox jumps over the lazy dog"
    text2 = "Never jump over the lazy dog quickly"

    # 对文本进行分词
    inputs1 = tokenizer(text1, return_tensors='pt')
    inputs2 = tokenizer(text2, return_tensors='pt')

    # 输入模型获取输出
    with torch.no_grad():
        outputs1 = model(**inputs1)
        outputs2 = model(**inputs2)

    # 取 [CLS] 标记的输出作为文本表示
    embedding1 = outputs1.last_hidden_state[:, 0, :].numpy()
    embedding2 = outputs2.last_hidden_state[:, 0, :].numpy()

    # 计算余弦相似度
    similarity = cosine_similarity(embedding1, embedding2)[0][0]
    print(f"文本相似度: {similarity}")






"""
@Type function
@Author xjp
@CreateDate 2025-03-24_21:35:59
@Description ALBERT（A Lite BERT）对 BERT 进行了轻量化改进，通过参数共享等技术减少了模型的参数量。在保持较高性能的同时，降低了计算资源需求，提高了训练和推理速度。(未测试)
@Param 
@Return 
"""
def simALBERT(text1:str, text2:str, thre:int = 0.7)->bool:
    from transformers import AutoTokenizer, AutoModel
    import torch
    from sklearn.metrics.pairwise import cosine_similarity

    # 加载预训练的 ALBERT 模型和分词器
    tokenizer = AutoTokenizer.from_pretrained('albert-base-v2')
    model = AutoModel.from_pretrained('albert-base-v2')

    text1 = "The quick brown fox jumps over the lazy dog"
    text2 = "Never jump over the lazy dog quickly"

    # 对文本进行分词
    inputs1 = tokenizer(text1, return_tensors='pt')
    inputs2 = tokenizer(text2, return_tensors='pt')

    # 输入模型获取输出
    with torch.no_grad():
        outputs1 = model(**inputs1)
        outputs2 = model(**inputs2)

    # 取 [CLS] 标记的输出作为文本表示
    embedding1 = outputs1.last_hidden_state[:, 0, :].numpy()
    embedding2 = outputs2.last_hidden_state[:, 0, :].numpy()

    # 计算余弦相似度
    similarity = cosine_similarity(embedding1, embedding2)[0][0]
    print(f"文本相似度: {similarity}")


    

if __name__ == "__main__":
    text1 = ''
    text2 = ""
    if simToken(text1, text2):
        print("ok")
    else:
        print("no")        
        
        
        
        
        
        
        """
    text1 = "Date 2022 TUE 22 15:23:15" 
    text1 = "Date 1986 JUN 16 6:05:10" 
        
    embedding1 = modelSentence.encode(text1)
    embedding2 = modelSentence.encode(text2)
    sim = cosine_similarity([embedding1],[embedding2])[0][0]
    print(sim)"""