"""
@Type doc
@Author xjp
@CreateDate 2025-04-09_10:25:48
@Description 解析流量3.0版 细化payload类型 
@Version 3.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""


from scapy.all import rdpcap, Packet, Raw
import myRegex
regex = myRegex.MyRegex()
from typing import List, Tuple

def parseOnePcap(path:str)->List:
    res = []
    try:
        # 读取流量包
        packets = rdpcap(path)
        if packets != None:   
            for p in packets:
                try:
                    temp = {}
                    # 获取时间戳
                    temp["time"] = p.time
                    temp["length"] = len(p)
                    if p.haslayer("IP"):
                        # 解析源IP
                        temp["sip"] = p["IP"].src
                        # 解析目的IP
                        temp["dip"] = p["IP"].dst
                        # 解析源port
                        temp["sport"] = str(p["IP"].sport)
                        # 解析目的port
                        temp["dport"] = str(p["IP"].dport)
                        # 解析协议
                        temp["proto"] = p["IP"].proto
                        # IP版本
                        temp["version"] = p["IP"].version
                        # IP首部长度
                        temp["headlength"] = p["IP"].ihl
                        # 服务类型
                        temp["tos"] = p["IP"].tos
                        # IP包长度
                        temp["length_ip"] = p["IP"].len
                        # ip包标识
                        temp["ip_id"] = p["IP"].id
                        # 标志位
                        #temp["ip_flags"] = p["IP"].flags
                        # 片偏移
                        temp["ip_frag"] = p["IP"].frag
                        # 生存时间
                        temp["ttl"] = p["IP"].ttl
                        # url
                        temp["url"] = ""
                        # url参数
                        temp["param"] = {}
                    if p.haslayer("TCP"):
                        # 序列号
                        temp["tcp_seq"] = p["TCP"].seq
                        # 确认号
                        temp["tcp_ack"] = p["TCP"].ack
                        # 首部长度
                        temp["tcp_dataofs"] = p["TCP"].dataofs
                        # 标志位
                        #temp["tcp_flags"] = p["TCP"].flags
                        # 窗口大小
                        temp["tcp_window"] = p["TCP"].window
                        # 校验和
                        temp["tcp_chksum"] = p["TCP"].chksum
                    # 解析Raw层
                    try:
                        if p.haslayer(Raw):
                            #temp["raw"] = p["Raw"].load.decode().split("\r\n")
                            temp["raw"] = p["Raw"].load
                            temp["payload"] = p["Raw"].load.decode().replace("\r\n"," ").replace("\n"," ")
                            """
                            if type(temp["raw"]) == str:
                                temp["payload"] = p["Raw"].load.decode().replace("\r\n"," ").replace("\n"," ")
                            elif type(temp["raw"]) == list:
                                t = ""
                                for r in temp["raw"]:
                                    t += r + " "
                                t = t[:-1]
                                temp["payload"] = t
                            else:
                                print(type(temp["raw"]))
                            """
                        else:
                            temp["payload"] = ""
                            temp["raw"] = ""

                    except:
                        temp["payload"] = ""
                        temp["raw"] = ""
            
                    # 汇总结果到最终结果集中
                    res.append(temp)
                except Exception as e:
                    print(e)
    except Exception as e:
        print(f"解析流量失败:{e}")
    # 清除无效数据
    res_temp = []
    for r in res:
        if "sip" not in r.keys() or "dip" not in r.keys():
            pass
        else:
            res_temp.append(r)
    res = res_temp


    for r in res:
        t = __parsePayload(r["raw"])
        r["payload_type"] = t[0]
        r["payload_text"] = t[1]

    
    return res



"""
@Type function
@Author xjp
@CreateDate 2025-04-09_10:37:39
@Description 解析payload数据
@Param payload:字节数据
@Return List(数据类型,具体的值)
"""
def __parsePayload(payload)->List:
    res = []
    try:
        text = payload.decode()
        res = ["str", payload]
    except:
        res = ["bytes", payload]
    return res