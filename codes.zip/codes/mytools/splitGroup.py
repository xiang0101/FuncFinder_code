"""
@Type doc
@Author xjp
@CreateDate 2025-04-08_14:43:01
@Description 用于将一组流量数据分割为不同的组
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from typing import List
import numpy as np
import copy
from .calcSim import simToken
import math
import random

"""
@Type function
@Author xjp
@CreateDate 2025-04-08_22:01:58
@Description 将一个组分割为多个组
@Param 
@Return 
"""
def splitGroupToGroups(group:List[List[dict]])->List:
    # 1.给数据编组
    data_flow = {}
    for i in range(len(group)):
        data_flow[str(i)] = group[i]
    # 2.提取每个流量序列都包含的特征
    data_payloads = __extractPayload(data_flow)
    # data_payloads = [[A,B,C,...],[D,E,F,...]]
    # 如果不存在每个流量序列都有的payload,则直接返回原数据
    if len(data_payloads) == 0:
        return group
    # 3.获取payload和tokens分组结果
    split_res = []
    for data_payload in data_payloads:
        split_res = __getSplitRes(data_payload)
        if len(split_res) != 0:
            break
    # 4.按照分割结果分割数据
    if len(split_res) == 0:
        return group
    else:
        res = []
        for flows in split_res:
            temp = []
            for flow in flows:
                temp.append(data_flow[flow])
            res.append(temp)
    return res
"""
@Type function
@Author xjp
@CreateDate 2025-04-08_22:16:43
@Description 判断每一组payload中, 
@Param 
@Return 
"""
def __getSplitRes(data:List[str]):
    dict_payload = {}
    for i in range(len(data)):
        dict_payload[str(i)] = data[i]
    # (1) 分割token
    data_payload = [v for p,v in dict_payload.items()]
    data_tokens = [d.split(" ") for d in data_payload]

    # 给每一个flow 一个唯一编号
    data_flow = {}
    for i in range(len(data_tokens)):
        data_flow[str(i)] = {
            "payload":data_payload[i],
            "tokens":data_tokens[i]
            }
    # (2)获取最多的token的数量
    max_token_num = max([len(d) for d in data_tokens])
    # (3)统计每个位置每次词出现的次数
    dict_token_num = {}
    for i in range(max_token_num):
        dict_token_num[str(i)] = {}
    for tokens in data_tokens:
        for i in range(len(tokens)):
            if tokens[i] not in dict_token_num[str(i)].keys():
                dict_token_num[str(i)][tokens[i]] = 0
            dict_token_num[str(i)][tokens[i]] += 1
    # (4)筛选出异常的组
    data_res = {}
    for key in dict_token_num.keys():
        # 全部一致则跳过
        if len(dict_token_num[key].keys()) == 1:
            continue
        # 每个都不同
        if len(dict_token_num[key].keys()) == len(dict_payload.keys()):
            continue
        # 只有两个类则直接加入
        if len(dict_token_num[key].keys()) ==2:
            data_res[key] = dict_token_num[key]
            continue
        t = math.ceil(len(dict_payload.keys())/len(dict_token_num[key].keys()))
        temp = {}
        for key2 in dict_token_num[key].keys():
            if dict_token_num[key][key2] > t:
                temp[key2] = dict_token_num[key][key2]
        data_res[key] = temp

    # (5)按照各项分组数据
    data_payload_group = {}
    # 添加key
    for key1 in data_res.keys():
        data_payload_group[key1] = {}
        for key2 in data_res[key1].keys():
            data_payload_group[key1][key2] = []
        data_payload_group[key1]["other"] = []
    for key in data_res.keys(): 
        for flow in data_flow.keys():
            flag = False
            for key2 in data_res[key].keys():
                if data_flow[flow]["tokens"][int(key)] == key2:
                    flag = True
                    data_payload_group[key][key2].append(flow)
                    break
            if not flag:
                data_payload_group[key]["other"].append(flow)
    # 移除为空的other分组
    for key in data_payload_group.keys():
        if len(data_payload_group[key]["other"]) == 0:
            data_payload_group[key].pop("other")
    # (6)计算每两个组之间是否有交叉数据
    data_cross = {}
    for key in data_payload_group.keys():
        data_cross[key] = []    
    keys = list(data_payload_group.keys())
    left = 0
    while left <len(keys) - 1:
        right = left + 1
        while right < len(keys):
            t = __calcCrossData(data_payload_group[keys[left]],data_payload_group[keys[right]])
            if t == True:
                data_cross[keys[left]].append(keys[right])
                data_cross[keys[right]].append(keys[left])
            right +=1
        left += 1
    # 
    # 先找出所有的划分标准
    data_std = []
    for key in data_cross.keys():
        temp = [key]
        temp.extend(data_cross[key])
        temp.sort()
        data_std.append(temp)
        
        
    data_std = [list(item) for item in set(tuple(sub_list) for sub_list in data_std)] 
    if len(data_std) == 0:
        # 不需要划分数据
        return data_std
    # 获取筛选结果
    choice = __chooseFinalStd(data_payload_group, data_std)

    # 按照筛选结果划分数据
    data_final_res = [list(data_flow.keys())]    
    for key in choice:    
        temp_res = []
        for flows in data_final_res:
            
            # 所有的key
            dict_temp = {}
            for key2 in data_res[key].keys():
                dict_temp[key2] = []
            dict_temp["other"] = []
            for flow in flows:
                t = data_flow[flow]["tokens"][int(key)]
                if t in dict_temp.keys():
                    dict_temp[t].append(flow)
                else:
                    dict_temp["other"].append(flow)
            # 将所有数据取出
            for key2 in dict_temp.keys():
                if len(dict_temp[key2]) != 0:
                    temp_res.append(dict_temp[key2])

        data_final_res = temp_res
        return data_final_res
def __chooseFinalStd(data_payload_group, data_std):
    # 选择标准
    res = []
    # 组合数量尽可能多
    flag = False
    max_l = 0
    for cp in data_std:
        if len(cp) == max_l:
            flag = False
        elif len(cp) > max_l:
            max_l=len(cp)
            flag = True
    if flag == True:
        for cp in data_std:
            if len(cp) == max_l:
                res = cp
                return res
        
    # 分组数量尽可能小
    flag = False
    min_group = 100000
    g  =[]
    for cp in data_std:
        count = 0
        for c in cp:
            count += len(data_payload_group[c].keys())
        if count < min_group:
            min_group = count
            flag = True
            g  = cp
        elif count == min_group:
            flag = False
    if flag == True:
        res = g
        return res

    # 尽可能不存在other,other数量尽可能少
    flag = False
    g = []
    min_group = 100000
    for cp in data_std:
        count  =0
        for c in cp:
            if "other" in data_payload_group[c].keys():
                count += data_payload_group[c]["other"]
        if count < min_group:
            flag = True
            g = cp
            min_group = count
        elif count == min_group:
            flag =False
    
    if flag == True:
        res = g
        return res
    
    # 实在分不出来则随机选择1组
    res = random.choice(data_std)
    return res

# 计算两个组之间是否有交叉数据    
def __calcCrossData(group1, group2)->bool:
    for key1 in group1.keys():
        temp = []
        for d in group1[key1]:
            for key2 in group2.keys():
                if d in group2[key2]:
                    temp.append(key2)
        temp = list(set(temp))
        if len(temp) == len(group2.keys()):
            return False
    return True

"""
@Type function
@Author xjp
@CreateDate 2025-04-08_22:05:11
@Description 提取所有流量序列共有的payload 
@Param 
@Return 
"""
def __extractPayload(data_flow:dict):
    data_bak = copy.deepcopy(data_flow)
    # 提取非空payload
    dict_payload = {}
    for key in data_bak.keys():
        temp = []
        for flow in data_bak[key]:
            if flow["payload"] != "":
                temp.append(flow["payload"])
        dict_payload[key] = temp
    # 筛选出所有相似的payload
    data_temp = []
    std = dict_payload["0"]
    for p in std:
        temp = [("0",p)]
        for i in range(len(dict_payload.keys())-1):
            for j in range(len(dict_payload[str(i+1)])):
                p2 = dict_payload[str(i+1)][j]
                if p2 == "":
                    continue
                if simToken(p, p2):
                    temp.append((str(i+1),p2))
                    dict_payload[str(i+1)][j] = ""
                    break
        data_temp.append(temp)

    # 选出每个组都包含的payload
    data_temp_t = []
    for temp in data_temp:
        if len(temp) == len(dict_payload.keys()):
            data_temp_t.append(temp)
    # 提取最终结果
    data_res = []
    for data in data_temp_t:
        temp = []
        for d in data:
            temp.append(d[1])
        data_res.append(temp)
    return data_res













def __custom_tokenizer(text):
    return text.split(" ")

"""
@Type function
@Author xjp
@CreateDate 2025-04-08_14:44:46
@Description 计算传入数据的TFIDF值 
@Param 
@Return 
"""
def calcTFIDF(data:List):

    #inputData = np.array(data).reshape(-1,1)
    #print(inputData.dtype)
    #inputData = [x.decode("utf-8") for x in inputData]
    # 创建TF-IDF 向量化器
    vectorizer = TfidfVectorizer(tokenizer=__custom_tokenizer)
    # 计算TF - IDF值
    tfidf_matrix = vectorizer.fit_transform(data)

    # 获取特征名称
    feature_names = vectorizer.get_feature_names_out()

    # 遍历每个文档
    for doc_index in range(len(data)):
        feature_index = tfidf_matrix[doc_index,:].nonzero()[1]
        tfidf_scores = zip(feature_index,[tfidf_matrix[doc_index,x] for x in feature_index])
        print(f"文档{doc_index+1} 的TF-IDF值:")
        for w,s in [(feature_names[i], s) for (i,s) in tfidf_scores]:
            print(f"{w}:{s}")
        print()