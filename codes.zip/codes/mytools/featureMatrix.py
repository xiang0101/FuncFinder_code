"""
@Type doc
@Author xjp
@CreateDate 2025-04-11_16:09:41
@Description 特征矩阵相关操作
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import copy
from typing import List
import numpy as np

"""
@Type function
@Author xjp
@CreateDate 2025-04-11_16:14:35
@Description 提取每一个流量序列的核心特征矩阵 
@Param flows_dict = {"1":[[],[],[],[],...],...}
@Return 
"""
def extractCoreFeatureMatrix(flows_dict:dict)->dict:
    # 备份一份防止影响原数据
    flows_dict_c = copy.deepcopy(flows_dict)
    # 存储最终结果
    res = {}
    for key_r in flows_dict_c.keys():
        print(key_r)
        # (1)提取每一个流量的特征矩阵
        data_temp = flows_dict_c[key_r]
        flows_feature = {}
        index = 0
        for flows in data_temp:
            features = __extractFlowsFeature(flows)
            flows_feature[str(index)] = features
            index += 1

        # (2)融合特征
        merge_feature_matrix = flows_feature["0"]["matrix"]
        merge_features = np.empty((len(merge_feature_matrix),), dtype=object)
        merge_features[:] = None
        merge_features = merge_features.tolist()
        # 遍历每一个流量序列
        for key in flows_feature.keys():
            # 遍历每一个特征
            for i in range(len(merge_feature_matrix)):
                merge_features[i] = __mergeFeatures(merge_features[i],flows_feature[key]["features"][i],merge_feature_matrix[i])
        res[key_r]  = {
            "core_feature_matrix":merge_feature_matrix,
            "features":merge_features
            }
    return res


"""
@Type function
@Author xjp
@CreateDate 2025-04-15_10:32:18
@Description 按照特征类型融合特征 
@Param 
@Return 
"""
def __mergeFeatures(all_features, feature, payload_type):
    # 初始化all_features
    if all_features == None:
        if payload_type == "str" or payload_type == "bytes":
            all_features = [feature]
        elif payload_type == "json":
            all_features = {}
            for k,v in feature.items():
                all_features[k] = [v]
        elif payload_type == "list":
            all_features = [feature.sort()]
        elif payload_type == "http-req":
            all_features = {}
            for k,v in feature.items():
                if k == "params":
                    all_features[k] = {}
                    for k2,v2 in feature[k].items():
                        all_features[k][k2] = [v2]
                else:
                    all_features[k]=[v]    
        elif payload_type =="http-res":
            all_features = {}
            for k,v in feature.items():
                all_features[k]=[v]
        else:
            all_features = [feature]    
        return all_features




    if payload_type == "str" or payload_type == "bytes":
        all_features.append(feature)
        all_features = list(set(all_features))
    elif payload_type == "json":
        for k,v in feature.items():
            if v not in all_features[k]:
                all_features[k].append(v)
    elif payload_type == "list":
        all_features.append(feature.sort())
        all_features = list(set(all_features))
    elif payload_type == "http-req":
        for k,v in feature.items():
            if k == "params":
                for k2,v2 in feature[k].items():
                    if v2 not in all_features[k][k2]:
                        all_features[k][k2].append(v2)
            else:
                if v not in all_features[k]:
                    all_features[k].append(v)
        
    elif payload_type =="http-res":
        for k,v in feature.items():
            if v not in all_features[k]:
                all_features[k].append(v)
    else:
        all_features.append(feature)
        all_features = list(set(all_features))
    return all_features


# 提取一个流量序列的特征矩阵
def __extractFlowsFeature(flows:List)->dict:
    feature_matrix = []
    features = []
    for flow in flows:
        if flow["payload_type"] != "none":
            feature_matrix.append(flow["payload_type"])
            features.append(flow["payload_text"])
    res = {
        "matrix":feature_matrix,
        "features":features
        }
    return res





# (2)将多个流量序列的特征融合为一个
def __mergeFeatureMatrix(feature_matrixs:List[List])->List:
    # 先选出一个标准特征矩阵
    res_std = feature_matrixs[0]
    # 从第一个开始和其他的比较
    index = 1
    while index < len(feature_matrixs):
        matrix = feature_matrixs[index]
        # 如果完全相同则直接跳过
        if res_std != matrix:
            # 比较每个不为none的特征之间内容的区别
            temp = []
            left = 0
            right = 0
            while left < len(res_std) and right < len(matrix):
                # 找到第1个不为none的特征并记录其中的内容
                feats1 = []
                feats2 = []
                while left < len(res_std):
                    if res_std[left] != "none":
                        break
                    feats1.append("none")
                    left +=1
                while right < len(matrix):
                    if matrix[right] != "none":
                        break
                    feats2.append("none")
                    right +=1
                # 达到序列尾部了
                if left == len(res_std) or right == len(matrix):
                    if len(feats1) != 0 or len(feats2) != 0:
                        temp.append("none")
                else:
                    if len(feats1)!= 0 or len(feats2) != 0:
                        temp.append("none")
                    temp.append(res_std[left])
                feats1 = []
                feats2 = []
                left += 1
                right += 1
            res_std = temp
        index += 1
    return res_std
    
