"""
@Type doc
@Author xjp
@CreateDate 2025-04-01_16:25:16
@Description 尝试合并按照特征分类后的组
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import random
import copy
from .calcSim import simToken
from typing import List


"""
@Type function
@Author xjp
@CreateDate 2025-04-01_21:41:06
@Description 尝试合并两个组中的内容 
@Param 
@Return 
"""
def mergeTwoGroups(groups1, groups2):
    # 先随机选择分组
    choice_groups1 = {}
    choice_groups2 = {}
    # 每种长度选择一个
    for key in groups1.keys():
        choice_groups1[key] = __chooseList(groups1[key])
    for key in groups2.keys():
        choice_groups2[key] = __chooseList(groups2[key])
    # 计算匹配结果
    match_res = {}
    for key1 in choice_groups1.keys():
        print(key1)
        match_res[key1] = {}
        for key2 in choice_groups2.keys():
            match_res[key1][key2] = []
            for flows1 in choice_groups1[key1]:
                for flows2 in choice_groups2[key2]:
                    t = __matchTwoFlows(flows1,flows2)
                    match_res[key1][key2].append(t)
    # 计算res结果
    res = __calcFinalRes(match_res)
    final_res = {}
    for key in res.keys():
        temp = -1
        res_key = ""
        for key2 in res[key].keys():
            if res[key][key2] > 0.65 and res[key][key2] > temp:
                temp = res[key][key2]
                res_key = key2
        if res_key != "":
            final_res[key] = res_key
    return final_res
    
"""
@Type function
@Author xjp
@CreateDate 2025-04-01_16:49:23
@Description 判断哪些组需要合并 
@Param all_groups = {"0":[[],[],...],"1":[[],[],...]}
@Return 
"""
def mergeGroups(all_groups:dict)->dict:
    # 先随机选择分组
    choice_groups = {}
    # 每种长度选择一个
    for key in all_groups.keys():
        choice_groups[key] = __chooseList(all_groups[key])
    # 获取所有的key
    keys = list(choice_groups.keys())
    # 计算索引
    match_res = {}
    left = 0
    while left +1 <len(keys):
        print(left)
        match_res[keys[left]] = {}
        right = left + 1
        while right< len(keys):
            match_res[keys[left]][keys[right]] = []
            for flows_list_left in choice_groups[keys[left]]:
                for flows_list_right in choice_groups[keys[right]]:
                    t = __matchTwoFlows(flows_list_left,flows_list_right)
                    match_res[keys[left]][keys[right]].append(t)
            right += 1
        left += 1
    # 计算res结果
    res = __calcFinalRes(match_res)
    final_res = {}
    for key in res.keys():
        temp = -1
        res_key = ""
        for key2 in res[key].keys():
            if res[key][key2] > 0.65 and res[key][key2] > temp:
                temp = res[key][key2]
                res_key = key2
        if res_key != "":
            final_res[key] = res_key
    return final_res
        

"""
@Type function
@Author xjp
@CreateDate 2025-04-01_17:14:19
@Description 计算最终统计结果 
@Param 
@Return 
"""
def __calcFinalRes(match_res:dict)->dict:
    res = {}
    for key1 in match_res.keys():
        res[key1] = {}
        for key2 in match_res[key1].keys():
            if len(match_res[key1][key2]) <=2:
                all_nums = match_res[key1][key2]
                #res[key1][key2] = sum(all_nums)/len(all_nums)
                res[key1][key2] = max(all_nums)
                continue
            all_nums = match_res[key1][key2]
            max_value = max(all_nums)
            min_value = min(all_nums)
            # 移除最大值和最小值
            all_nums.remove(max_value)
            all_nums.remove(min_value)
            #res[key1][key2] = sum(all_nums)/len(all_nums)
            res[key1][key2] = max(all_nums)
    return res


def __matchTwoFlows(flows1, flows2):
    index1 = 0
    index2 = 0
    total = max(len(flows1),len(flows2))
    res_all = 0
    # 先推进到完全匹配
    while index1 < len(flows1) and index2 < len(flows2):
        if __compAllSim(flows1[index1], flows2[index2]):
            res_all += 2
            index1 += 1
            index2 += 1
        else:
            break
    # 剩下的流量
    res_loc = 0
    flows1_temp = copy.deepcopy(flows1[index1:])
    flows2_temp = copy.deepcopy(flows2[index2:])
    for flow in flows1_temp:
        flow["matched"] = False
    for flow in flows2_temp:
        flow["matched"] = False
    for flow1 in flows1_temp:
        for flow2 in flows2_temp:
            if flow2["matched"] == True:
                continue
            if __compAllSim(flow1, flow2):
                res_loc += 2
                flow1["matched"] = True
                flow2["matched"] = True
                break
    # 获取剩下的流量
    flows1_temp_2 = []
    flows2_temp_2 = []
    for flow in flows1_temp:
        if flow["matched"] == False:
            flows1_temp_2.append(flow)
    for flow in flows2_temp:
        if flow["matched"] == False:
            flows2_temp_2.append(flow)
    # 剩下的再比较相似度
    flows1_temp = flows1_temp_2
    flows2_temp = flows2_temp_2
    res_sim = 0
    for flow1 in flows1_temp:
        for flow2 in flows2_temp:
            if flow2["matched"] == True:
                continue
            if __compLikeSim(flow1, flow2):
                res_sim += 1
                flow1["matched"] = True
                flow2["matched"] = True
                break
    # 获取剩下的流量
    flows1_temp_2 = []
    flows2_temp_2 = []
    for flow in flows1_temp:
        if flow["matched"] == False:
            flows1_temp_2.append(flow)
    for flow in flows2_temp:
        if flow["matched"] == False:
            flows2_temp_2.append(flow)
    
    # 剩下的再比较结构相似度
    flows1_temp = flows1_temp_2
    flows2_temp = flows2_temp_2
    """
    res_str = 0
    for flow1 in flows1_temp:
        for flow2 in flows2_temp:
            if flow2["matched"] == True:
                continue
            if __compStructureSim(flow1, flow2):
                #res_str += 1
                flow1["matched"] = True
                flow2["matched"] = True
                break
    """
    res = res_all + res_loc + res_sim# + res_str
    flows1_temp1 = []
    for flow in flows1_temp:
        #if flow["payload"]!="" and flow["matched"] == False:
        if flow["matched"] == False:
            flows1_temp1.append(flow)
    flows1_temp = flows1_temp1
    flows2_temp2 = []
    for flow in flows2_temp:
        #if flow["payload"]!="" and flow["matched"] == False:
        if flow["matched"] == False:
            flows2_temp2.append(flow)
    flows2_temp = flows2_temp2

    if len(flows1_temp) == 0 and len(flows2_temp) != 0:
        # 可能是包含关系
        res += len(flows2_temp)
    elif len(flows2_temp) == 0 and len(flows1_temp) != 0:
        res += len(flows1_temp)
    else:
        #res -= len(flows1_temp)
        #res -= len(flows2_temp)
        res -= max(len(flows1_temp),len(flows2_temp))
        if len(flows1_temp) != 0:
            for flow in flows1_temp:
                if flow["payload"] != "":
                    res -=2
        else:
            for flow in flows2_temp:
                if flow["payload"] != "":
                    res -=2
    t = res/(total*2)
    return t


"""
@Type function
@Author xjp
@CreateDate 2025-04-01_16:54:58
@Description 计算两条流量的结构相似度 
@Param 
@Return 
"""
def __compStructureSim(flow1, flow2):
    if not (flow1["sport"] == flow2["sport"] or flow1["dport"] == flow2["dport"]):
        return False
    if flow1["direction"] != flow2["direction"]:
        return False
    if flow1["payload"] == flow2["payload"] or (flow1["payload"] != "" and flow2["payload"] != ""):
        return True
    return False


"""
@Type function
@Author xjp
@CreateDate 2025-04-01_16:55:12
@Description 计算两条流量的payload相似度 
@Param 
@Return 
"""
def __compLikeSim(flow1, flow2):
    if not (flow1["sport"] == flow2["sport"] or flow1["dport"] == flow2["dport"]):
        return False
    if flow1["direction"] != flow2["direction"]:
        return False
    if simToken(flow1["payload"], flow2["payload"]):
        return True
    return False




"""
@Type function
@Author xjp
@CreateDate 2025-04-01_16:55:30
@Description 比较两条流量是否完全相同 
@Param 
@Return 
"""
def __compAllSim(flow1, flow2):
    if not (flow1["sport"] == flow2["sport"] or flow1["dport"] == flow2["dport"]):
        return False
    if flow1["direction"] != flow2["direction"]:
        return False
    if flow1["payload"] == flow2["payload"]:
        return True
    return False



"""
@Type function
@Author xjp
@CreateDate 2025-04-01_16:43:34
@Description 统计每个flwos_list中的流量数量,并从每种数量流量序列中随机抽取一个流量序列 
@Param 
@Return 
"""
def __chooseList(flows_list):
    # 先按照长度分组
    group_by_num = {}
    for flows in flows_list:
        key = str(len(flows))
        if key not in group_by_num.keys():
            group_by_num[key] = []
        group_by_num[key].append(flows)
    # 从每个长度组随机抽取一个数据
    res = []
    for key in group_by_num.keys():
        t = random.choice(group_by_num[key])
        res.append(t)
    # 返回复制的数据,防止对原数据产生影响
    return copy.deepcopy(res)


"""
@Type function
@Author xjp
@CreateDate 2025-04-05_18:32:35
@Description 按照结构合并流量数据(合并low组数据) 
@Param 
@Return 
"""
def mergeByStructure(flows_list)->dict:
    # 先将所有数据打混
    flow_list =[]
    for key in flows_list.keys():
        flow_list.extend(flows_list[key])
    # 按照流量序列的数量分组
    """
    group_by_num = {}
    for flows in flow_list:
        key = str(len(flows))
        if key not in group_by_num.keys():
            group_by_num[key] = []
        group_by_num[key].append(flows)
    """
    # 相同数量内的流量先按照结构分组
    group_res = []
    __groupByStructure(flow_list,group_res)
    keys = list(flows_list.keys())
    res = {}
    index = 0
    while index < len(group_res):
        res[keys[index]] = group_res[index]
        index +=1
    return res

def __groupByStructure(flow_list:List[List[dict]], group_res:List):
    # 数量小于一定数值单独分为一组
    if len(flow_list) < 2:
        group_res.append(flow_list)
        return
    # 选出一个标准
    flows_std = flow_list[0]
    # 将其和所有其他的比较
    group_left = [flows_std]
    group_right = []
    index = 1
    while index < len(flow_list):
        if __matchTwoFlowsByStructure(flows_std, flow_list[index]):
            group_left.append(flow_list[index])
        else:
            group_right.append(flow_list[index])
        index += 1    
    group_res.append(group_left)
    if len(group_right) != 0:
        __groupByStructure(group_right,group_res)

"""
@Type function
@Author xjp
@CreateDate 2025-04-05_18:47:50
@Description 比较两个流量序列是否结构相似 
@Param 
@Return 
"""
def __matchTwoFlowsByStructure(flows1:List, flows2:List)->bool:
    index1 = 0
    index2 = 0
    while index1 < len(flows1) and index2 < len(flows2):
        if flows1[index1]["sport"] == flows2[index2]["sport"] or flows1[index1]["dport"] == flows2[index2]["dport"]:
            pass
        if (flows1[index1]["payload"]!="" and flows2[index2]["payload"] != "") or (flows1[index1]["payload"] == flows2[index2]["payload"]):
            index1 += 1
            index2 += 1
            continue
        break
    if index1 == len(flows1) or index2 == len(flows2):
        return True
    return False



"""
@Type function
@Author xjp
@CreateDate 2025-04-05_19:06:42
@Description 最后尝试将较多的低组合并到高组(计算低组和高组的结构相似度) 
@Param 
@Return 
"""
def mergeLastGroups(low_group:dict, high_group:dict):
    # 遍历计算每个数量大小的相似度结果
    
    
    # 先随机选择分组
    choice_low_groups = {}
    # 每种长度选择一个
    for key in low_group.keys():
        choice_low_groups[key] = __chooseList(low_group[key])
    
    choice_high_groups = {}
    # 每种长度选择一个
    for key in high_group.keys():
        choice_high_groups[key] = __chooseList(high_group[key])
    match_res = {}
    for key1 in choice_low_groups.keys():
        match_res[key1] = {}
        for key2 in choice_high_groups.keys():
            match_res[key1][key2] = []
            for flows1 in choice_low_groups[key1]:
                for flows2 in choice_high_groups[key2]:
                    match_res[key1][key2].append(__matchTwoFlowsByStructure(flows1,flows2))
    return match_res
    

"""
@Type function
@Author xjp
@CreateDate 2025-04-07_16:24:13
@Description 合并组自身 
@Param 
@Return 
"""
def mergeGroupSelf(match_res:dict, groups:dict):
    # 合并数据
    data_merge = []
    for key in match_res.keys():
        flag = False
        for d in data_merge:
            if key in d:
                d.append(match_res[key])
                flag  =True
                break
            
        if not flag:
            for d in data_merge:
                if match_res[key] in d:
                    d.append(key)
                    flag  =True
                    break
        if not flag:
            temp = [key, match_res[key]]
            data_merge.append(temp)

    # 合并有交叉的数据
    index1 =0 
    while index1 < len(data_merge)-1:
        index2 = index1 + 1
        while index2 < len(data_merge):
            # 判断是否有交叉数据
            if bool(set(data_merge[index1]).intersection(set(data_merge[index2]))):
                data_merge[index1].extend(data_merge[index2])
                data_merge[index2] = []
            index2 += 1
        index1 += 1
        
    # 去重和去除空值
    data_merge_temp = []
    for d in data_merge:
        if len(d) != 0:
            data_merge_temp.append(list(set(d)))
            
    # 包装数据
    data_merge = {}
    for d in data_merge_temp:
        data_merge[d[0]] = d[1:]
        
        
        
    # 合并数据
    for key in data_merge.keys():
        for key2 in data_merge[key]:
            groups[key].extend(groups[key2])
            groups.pop(key2)