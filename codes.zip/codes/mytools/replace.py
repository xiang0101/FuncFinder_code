"""
@Type doc
@Author xjp
@CreateDate 2025-03-25_10:54:44
@Description 替换ip和端口
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

from typing import List
import copy


def replaceIpAndPort(flow_list:List[List[dict]])->List:
    # 复制一份数据
    flow_list_res = copy.deepcopy(flow_list)
    # 先查找是否存在固定端口
    port_temp = {}
    # 存储固定端口的列表
    confirm_port = []
    # 统计该组的每个流量序列中,端口出现的次数,最终用来找固定端口
    for flows in flow_list_res:
        # 获取该流量序列中的两个端口
        sport = str(flows[0]["sport"])
        dport = str(flows[0]["dport"])
        # 更新端口出现次数
        if sport not in port_temp.keys():
            port_temp[sport] = 0
        port_temp[sport] += 1
        if dport not in port_temp.keys():
            port_temp[dport] = 0
        port_temp[dport] += 1
    # 判断是否存在固定端口
    for port in port_temp.keys():
        if port in confirm_port:
            continue
        # 每次都出现的端口为固定端口
        if port_temp[port] == len(flow_list_res) and len(flow_list_res)>1:
            confirm_port.append(port)
    # 如果存在固定端口,则把固定端口对应的ip设置为ip1,另一个ip设置为ip2
    if len(confirm_port) == 2:
        # 两个都是固定端口
        port_symbol = {}
        port_symbol[str(confirm_port[0])] = "ip1"
        port_symbol[str(confirm_port[1])] = "ip2"
        for flows in flow_list_res:
            for flow in flows:
                flow["sip"] = port_symbol[str(flow["sport"])]
                flow["dip"] = port_symbol[str(flow["dport"])]
    elif len(confirm_port) == 1:
        # 只有一个固定端口,固定端口ip设置为ip1
        for flows in flow_list_res:
            for flow in flows:
                if str(flow["sport"]) in confirm_port:
                    flow["sip"] = "ip1"
                    flow["dip"] = "ip2"
                    flow["dport"] = "port2"
                else:
                    flow["sip"] = "ip2"
                    flow["dip"] = "ip1"
                    flow["sport"] = "port2"
    else:
        # 没有固定端口,第一次出现的ip设置为ip1
        for flows in flow_list_res:
            ip_symbol = {}
            ip_symbol[flows[0]["sip"]] = {"ip":"ip1","port":"port1"}
            ip_symbol[flows[0]["dip"]] = {"ip":"ip2","port":"port2"}
            for flow in flows:
                flow["sport"] = ip_symbol[flow["sip"]]["port"]
                flow["dport"] = ip_symbol[flow["dip"]]["port"]
                flow["sip"] = ip_symbol[flow["sip"]]["ip"]
                flow["dip"] = ip_symbol[flow["dip"]]["ip"]
    return flow_list_res