"""
@Type doc
@Author xjp
@CreateDate 2025-04-15_15:05:11
@Description 融合特征矩阵
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

from typing import List
import copy
from . import calcSim

"""
@Type function
@Author xjp
@CreateDate 2025-04-15_15:06:18
@Description 提取两个特征矩阵的最大前缀 
@Param 
@Return 
"""
def extractMaxFeaturePrefix(matrix1, matrix2, features1, features2):
    res = []
    index = 0
    while index < len(matrix1) and index < len(matrix2):
        if matrix1[index] != matrix2[index]:
            return res
        if not __isSameFeature(matrix1[index],features1[index],features2[index]):
            return res
        res.append(matrix1[index])
        index +=1
    return res

"""
@Type function
@Author xjp
@CreateDate 2025-04-19_15:09:44
@Description 提取最大相似特征前缀矩阵 
@Param 
@Return 
"""
def extractMaxSimFeaturePrefix(matrix1, matrix2, features1, features2):
    res = []
    index = 0
    while index < len(matrix1) and index < len(matrix2):
        if matrix1[index] != matrix2[index]:
            return res
        if not __isSimFeature(matrix1[index],features1[index],features2[index]):
            return res
        res.append(matrix1[index])
        index +=1
    return res

"""
@Type function
@Author xjp
@CreateDate 2025-04-15_15:50:47
@Description 提取两个特征矩阵的所有匹配子序列位置 
@Param matrix1:主特征矩阵(长度较长的);matrix2:子特征矩阵(长度较短的);
@Return 
"""
def extractMaxFeatureSubSeq(matrix1, matrix2, features1, features2):
    if len(matrix1) < len(matrix2):
        return []
    res = []
    matrix2_temp = copy.deepcopy(matrix2)
    # 先找到所有匹配的位置
    match_loc = __findAllSubSeq(matrix1, matrix2)
    num = 0
    isHead = True
    if len(match_loc) == 0:
        num = 1
        # 开始删减位置
        while len(match_loc) == 0 and num<len(matrix2):
            # 从头部开始删减
            matrix2_temp = matrix2[num:]
            match_loc = __findAllSubSeq(matrix1, matrix2_temp)
            if len(match_loc) != 0:
                isHead = True
                break
            # 从尾部删减
            matrix2_temp = matrix2[:(-1)*num]
            match_loc = __findAllSubSeq(matrix1, matrix2_temp)
            if len(match_loc) != 0:
                isHead = False
                break
            num += 1
        # 没有找到匹配的位置
        if len(match_loc) == 0:
            return res
    # 判断每个匹配的位置是否有效
    for loc in match_loc:
        if loc == 0:
            continue
        left = loc
        right = 0
        flag = True
        while left < len(matrix1) and right < len(matrix2_temp):
            if isHead:
                if not __isSameFeature(matrix1[left],features1[left],features2[right+num]):
                    flag = False
                    break
            else:
                if not __isSameFeature(matrix1[left],features1[left],features2[right]):
                    flag = False
                    break
            left += 1
            right += 1
        if flag:
            # 此时位置判断有效
            res.append([loc,matrix2_temp]) 
    return res




# 找到所有的子序列  
def __findAllSubSeq(mainList:List,subList:List)->List:
    main_length = len(mainList)
    sub_length = len(subList)
    if sub_length > main_length:
        return []
    res  = []
    # 遍历主序列,检查每一个可能的起始位置
    for i in range(main_length - sub_length + 1):
        match = True
        # 检查从当前起始位置开始的子序列是否于目标子序列匹配
        for j in range(sub_length):
            if mainList[i+j] != subList[j]:
                match = False
                break
        if match:
            res.append(i)
    return res



"""
@Type function
@Author xjp
@CreateDate 2025-04-15_15:07:43
@Description 判断两个特定类型的特征是否相同 
@Param 
@Return 
"""
def __isSameFeature(feature_type:str, feature1, feature2)->bool:
    if feature_type == "str":
        return __has_intersection_set(feature1, feature2)
    elif feature_type == "bytes":
        # !!!!
        return True
        # 提取每个字节的前8位
        list1 = [t[:8] for t in feature1]
        list2 = [t[:8] for t in feature2]
        return __has_intersection_set(list1, list2)
    elif feature_type == "json":
        # 判断json格式的key是否相同
        keys1 = set(list(feature1.keys()))
        keys2 = set(list(feature2.keys()))
        if keys1 == keys2:
            return True
        return False
    elif feature_type == "http-req":
        # 先判断key是否相同
        keys1 = set(list(feature1.keys()))
        keys2 = set(list(feature2.keys()))
        if keys1 != keys2:
            return False
        # 比较几个特定特征
        if "method" in keys1 and "method" in keys2:
            if not __has_intersection_set(feature1["method"],feature2["method"]):
                return False
        # 比较uri
        if "uri" in keys1 and "uri" in keys2:
            if not __has_intersection_set(feature1["uri"],feature2["uri"]):
                return False
        # 比较参数类型
        if "params" in keys1 and "params" in keys2:
            if feature1["params"] == feature2["params"]:
                return True
            if not __has_intersection_set(list(feature1["params"].keys()),list(feature2["params"].keys())):
                return False
        return True


    elif feature_type == "http-res":
        # 先判断key是否相同
        keys1 = set(list(feature1.keys()))
        keys2 = set(list(feature2.keys()))
        if keys1 != keys2:
            return False
        # 再判断几个特定的特征是否相同
        if "code" in keys1 and "code" in keys2:
            if not __has_intersection_set(feature1["code"],feature2["code"]):
                return False


        if "Server" in keys1 and "Server" in keys2:
            if not __has_intersection_set(feature1["Server"],feature2["Server"]):
                return False

        if "Content-Type" in keys1 and "Content-Type" in keys2:
            if not __has_intersection_set(feature1["Content-Type"],feature2["Content-Type"]):
                return False
        return True

    else:
        return True


"""
@Type function
@Author xjp
@CreateDate 2025-04-19_15:10:25
@Description 判断特征是否相似 
@Param 
@Return 
"""
def __isSimFeature(feature_type:str, feature1, feature2):
    if feature_type == "str":
        for feat1 in feature1:
            for feat2 in feature2:
                if calcSim.simToken2(feat1,feat2):
                    return True
        return False
    elif feature_type == "bytes":
        # 提取每个字节的前8位
        list1 = [t[:8] for t in feature1]
        list2 = [t[:8] for t in feature2]
        return __has_intersection_set(list1, list2)
    elif feature_type == "json":
        # 判断json格式的key是否相同
        keys1 = set(list(feature1.keys()))
        keys2 = set(list(feature2.keys()))
        if keys1 == keys2:
            return True
        return False
    elif feature_type == "http-req":
        # 先判断key是否相同
        keys1 = set(list(feature1.keys()))
        keys2 = set(list(feature2.keys()))
        if keys1 != keys2:
            return False
        # 比较几个特定特征
        if "method" in keys1 and "method" in keys2:
            if not __has_intersection_set(feature1["method"],feature2["method"]):
                return False
        # 比较参数类型
        if "params" in keys1 and "params" in keys2:
            if not __has_intersection_set(list(feature1["params"].keys()),list(feature2["params"].keys())):
                return False
        # 比较uri
        if "uri" in keys1 and "uri" in keys2:
            for feat1 in feature1["uri"]:
                for feat2 in feature2["uri"]:
                    if calcSim.simToken2(feat1,feat2):
                        return True
            return False
        return True


    elif feature_type == "http-res":
        # 先判断key是否相同
        keys1 = set(list(feature1.keys()))
        keys2 = set(list(feature2.keys()))
        if keys1 != keys2:
            return False
        # 再判断几个特定的特征是否相同
        if "code" in keys1 and "code" in keys2:
            if not __has_intersection_set(feature1["code"],feature2["code"]):
                return False


        if "Server" in keys1 and "Server" in keys2:
            if not __has_intersection_set(feature1["Server"],feature2["Server"]):
                return False

        if "Content-Type" in keys1 and "Content-Type" in keys2:
            if not __has_intersection_set(feature1["Content-Type"],feature2["Content-Type"]):
                return False
        return True

    else:
        return True




"""
@Type function
@Author xjp
@CreateDate 2025-04-15_15:23:15
@Description 判断两个列表是否有交集 
@Param 
@Return 
"""
def __has_intersection_set(list1, list2)->bool:
    set1 = set(list1)
    set2 = set(list2)
    return bool(set1.intersection(set2))




"""
@Type function
@Author xjp
@CreateDate 2025-04-16_19:52:41
@Description 提取一个特征矩阵包含另一个特征矩阵的最长子序列 
@Param 
@Return 
"""
def extractMaxFeatureSubSeq2(matrix1, matrix2, features1, features2):
    if len(matrix1) < len(matrix2):
        return []
    res = []

    index = 0
    # 不考虑只有一个特征完全匹配的情况
    while index < len(matrix2)-1:
        # 从前部剔除index个元素构成特征矩阵子集
        matrix2_temp = matrix2[index:]
        match_loc = __findAllSubSeq(matrix1, matrix2_temp)
        # 判断从头部删减是否有效
        for loc in match_loc:
            if loc == 0:
                continue
            left = loc
            right = 0
            flag = True
            while left < len(matrix1) and right < len(matrix2_temp):
                if not __isSameFeature(matrix1[left],features1[left],features2[right + index]):
                    flag = False
                    break
                left += 1
                right += 1
            if flag:
                # 此时位置判断有效
                # 子序列起始位置,子序列终止位置,主序列起始位置
                res.append([index,len(matrix2),loc])
                return res
        # 从尾部剔除index个元素构成特征矩阵子集
        matrix2_temp = matrix2[:len(matrix2)-index]
        match_loc = __findAllSubSeq(matrix1, matrix2_temp)
        # 判断从尾部删减是否有效
        for loc in match_loc:
            if loc == 0:
                continue
            left = loc
            right = 0
            flag = True
            while left < len(matrix1) and right < len(matrix2_temp):
                if not __isSameFeature(matrix1[left],features1[left],features2[right]):
                    flag = False
                    break
                left += 1
                right += 1
            if flag:
                # 此时位置判断有效
                # 子序列起始位置,子序列终止位置,主序列起始位置
                res.append([0,len(matrix2_temp),loc])
                return res
        index +=1
    return res


"""
@Type function
@Author xjp
@CreateDate 2025-06-03_20:36:49
@Description 包含只有一个特征相同的情况 
@Param 
@Return 
"""
def extractMaxFeatureSubSeq3(matrix1, matrix2, features1, features2):
    if len(matrix1) < len(matrix2):
        return []
    res = []

    index = 0
    # 不考虑只有一个特征完全匹配的情况
    while index < len(matrix2):
        # 从前部剔除index个元素构成特征矩阵子集
        matrix2_temp = matrix2[index:]
        match_loc = __findAllSubSeq(matrix1, matrix2_temp)
        # 判断从头部删减是否有效
        for loc in match_loc:
            if loc == 0:
                continue
            left = loc
            right = 0
            flag = True
            while left < len(matrix1) and right < len(matrix2_temp):
                if not __isSameFeature(matrix1[left],features1[left],features2[right + index]):
                    flag = False
                    break
                left += 1
                right += 1
            if flag:
                # 此时位置判断有效
                # 子序列起始位置,子序列终止位置,主序列起始位置
                res.append([index,len(matrix2),loc])
                return res
        # 从尾部剔除index个元素构成特征矩阵子集
        matrix2_temp = matrix2[:len(matrix2)-index]
        match_loc = __findAllSubSeq(matrix1, matrix2_temp)
        # 判断从尾部删减是否有效
        for loc in match_loc:
            if loc == 0:
                continue
            left = loc
            right = 0
            flag = True
            while left < len(matrix1) and right < len(matrix2_temp):
                if not __isSameFeature(matrix1[left],features1[left],features2[right]):
                    flag = False
                    break
                left += 1
                right += 1
            if flag:
                # 此时位置判断有效
                # 子序列起始位置,子序列终止位置,主序列起始位置
                res.append([0,len(matrix2_temp),loc])
                return res
        index +=1
    return res