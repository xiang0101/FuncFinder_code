"""
@Type doc
@Author xjp
@CreateDate 2025-03-25_11:11:14
@Description 构造流量序列
@Version v1.0
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

"""
@Type doc
@Author xjp
@CreateDate 2025-03-19_20:40:46
@Description 构建恶意流量的流量序列
@Version v1.0
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import sys
sys.path.append("../../")

import json
from collections import Counter
import random
from typing import List
import math
import copy
from mytools.calcSim import simToken
import os



"""
@Type function
@Author xjp
@CreateDate 2025-03-28_18:40:29
@Description 
@Param 
@Return 
"""
def buildFlowSeq3(data:dict)->dict:
    data_temp = copy.deepcopy(data)
    data_res = {}
    for key in data_temp.keys():
        temp = __buildSeq3(data_temp[key])
        data_res[key] = temp
    return data_res

"""
@Type function
@Author xjp
@CreateDate 2025-03-25_11:13:09
@Description 构造流量序列 
@Param 
@Return 
"""
def buildFlowSeq(data:dict)->dict:
    # 获取全部数据数量
    data_count = {}
    for key in data.keys():
        data_count[key] = len(data[key])

    data_temp = copy.deepcopy(data)
    data_res = {}
    for key in data_temp.keys():
        temp = __buildSeq2(data_temp[key])
        data_res [key] = temp

    thre1 = 0.7
    thre2 = 0.3
    # 过滤数据
    for key in data_res.keys():
        for i in range(len(data_res[key])):
            temp = []
            for flow in data_res[key][i]:
                if flow["freq"]/data_count[key] > thre1:
                    temp.append(flow)
                elif flow["freq"]/data_count[key] > thre2:
                    flow["flag"] = 0
                    temp.append(flow)
            data_res[key][i] = temp
    res = {}
    for key in data_res.keys():
        res[key] = __mergeSameSeq(data_res[key])
    
    return res



"""
@Type function
@Author xjp
@CreateDate 2025-03-26_20:29:24
@Description 比较两个流量序列是否相同 
@Param 
@Return 
"""
def __compTwoSeq(flows1:List[dict], flows2:List[dict])->bool:
    if len(flows1) != len(flows2):
        return False
    for i in range(len(flows1)):
        if not __compareTwoFlow(flows1[i],flows2[i]):
            return False
    return True


"""
@Type function
@Author xjp
@CreateDate 2025-03-26_20:24:19
@Description 合并相同的流量序列 
@Param 
@Return 
"""
def __mergeSameSeq(flows_list:List[List[dict]])->List[List[dict]]:
    res = []
    left = 0
    right = 1
    remove_list = []
    while left <len(flows_list):
        if left in remove_list:
            left += 1
            right = left + 1
            continue
        if right >= len(flows_list):
            left +=1
            right = left +1
            continue
        # 比较left指向的内容和right指向的内容
        if __compTwoSeq(flows_list[left],flows_list[right]):
            remove_list.append(right)
        right += 1
    # 填充结果
    index = 0
    while index < len(flows_list):
        if index not in remove_list:
            res.append(flows_list[index])
        index += 1
    return res

        




"""
@Type function
@Author xjp
@CreateDate 2025-03-19_20:46:39
@Description 比较两条流量是否相似 
@Param 
@Return 
"""
def __compareTwoFlow(flow1:dict, flow2:dict)->bool:
    if flow1["sport"] != flow2["sport"]:
        return False
    if flow1["dport"] != flow2["dport"]:
        return False
    if flow1["proto"] != flow2["proto"]:
        return False
    if flow1["direction"] != flow2["direction"]:
        return False
    if not simToken(flow1["payload"],flow2["payload"]):
        return False
    return True

"""
@Type function
@Author xjp
@CreateDate 2025-03-19_20:49:20
@Description 向下比较流量 
@Param 
@Return 
"""
def __compDown(start, std, flows)->int:
    start += 1
    while start < len(flows):
        if flows[start]["matched"] == False:
            if __compareTwoFlow(std,flows[start]):
                return start
        start +=1
    return -1


"""
@Type function
@Author xjp
@CreateDate 2025-03-19_20:50:10
@Description 构造流量序列 
@Param 
@Return 
"""
def __buildSeq(flow_all:List[List[dict]])->List[dict]:
    # 如果只有一个流量序列的话,则不需要合并流量序列
    if len(flow_all) == 1:
        for flow_list in flow_all:
            for flow in flow_list:
                flow["freq"] = 1
                flow["flag"] = 1
                flow["matched"] = False
        res = flow_all
        return res

    # 给所有流量添加3个属性 freq、flag、matched
    for flow_list in flow_all:
        for flow in flow_list:
            flow["freq"] = 0
            flow["flag"] = 1
            flow["matched"] = False
    
    # 随机抽选一个作为标准(重复3次,对比最终结果是否一致)
    # 直接随机抽取3个不同的值
    choice_res = []
    # 随机3个不重复的数
    ns = []
    n_max = min(3, len(flow_all))
    while True:
        if len(ns) == n_max:
            break
        n = random.randint(0,len(flow_all)-1)
        if n not in ns:
            ns.append(n)
    # 提取数据
    for n in ns:
        choice_res.append(flow_all[n])

    # 开始构造流量序列
    # 存储最终构造结果
    res = []
    # 对于每一个抽取出的结果分类构造流量序列
    for choice_n in choice_res:
        # 存储每回合变化的标准流量序列
        temp_std =  copy.deepcopy(choice_n)
        # 循环判断每一组流量
        for flow in flow_all:
            # 更新标准流量序列
            cycle_std = copy.deepcopy(temp_std)
            temp_std = []
            # 创建队首游标
            c_s = 0 # 标准流量序列游标
            c_f = 0 # 待比较流量序列游标
            # 过滤c_s 和 c_f
        
            # 循环比对流量
            while c_s < len(cycle_std) and c_f < len(flow):
                # 找到第一个matched标志为False的标准流量
                while c_s < len(cycle_std):
                    if cycle_std[c_s]["matched"] == False:
                        break
                    # 为True则是已经比较过的流量,直接加入到结果集中
                    f = copy.deepcopy(cycle_std[c_s])
                    f["freq"] += 1
                    f["matched"] = False
                    temp_std.append(f)
                    c_s += 1
                # 超出范围
                if c_s == len(cycle_std):
                    break

                # 找到第一个matched标志为False的待比较流量
                while c_f < len(flow):
                    if flow[c_f]["matched"] == False:
                        break
                    c_f += 1
                # 超出范围
                if c_f == len(flow):
                    break 

                # 开始比较流量
                if __compareTwoFlow(cycle_std[c_s], flow[c_f]):
                    # 两条流量相同
                    f = copy.deepcopy(cycle_std[c_s])
                
                    f["freq"] += 1
                    f["matched"] = False
                    temp_std.append(f)
                    c_s += 1
                    c_f += 1
                    continue
            
                # 接下来是流量不同的判断
                # 将c_s和c_f之后的流量比较
                cursor = __compDown(c_f,cycle_std[c_s],flow)
                if cursor != -1:
                    # 在c_f之后找到和c_s相似的流量
                    flow[cursor]["matched"] = True
                    f = copy.deepcopy(cycle_std[c_s])
                    f["freq"] += 1
                    f["matched"] = False
                    temp_std.append(f)
                
                    c_s += 1
                else:
                    # 未找到则直接加入到结果集中
                    f = copy.deepcopy(cycle_std[c_s])
                    f["matched"] = False
                    temp_std.append(f)
                
                    c_s += 1
                # 将c_f和c_s之后的流量相比较
                cursor = __compDown(c_s-1,flow[c_f],cycle_std)
                if cursor != -1:
                    # 在c_s之后找到和c_f相似的流量
                    cycle_std[cursor]["matched"] = True
                    c_f += 1
                else:
                    f = copy.deepcopy(flow[c_f])
                    f["freq"] = 1
                    f["matched"] = False
                    temp_std.append(f)
                    c_f += 1

            # 处理剩余的流量
            if c_s == len(cycle_std) and c_f == len(flow):
                continue
            elif c_s != len(cycle_std):
                while c_s < len(cycle_std):
                    f = copy.deepcopy(cycle_std[c_s])
                    if f["matched"] == True:
                        f["freq"] += 1
                    f["matched"] = False
                    temp_std.append(f)
                    c_s +=1
            elif c_f < len(flow):
                while c_f < len(flow):
                    if flow[c_f]["matched"] == True:
                        c_f += 1
                        continue
                    f = copy.deepcopy(flow[c_f])
                    f["freq"] = 1
                    f["matched"] = False
                    temp_std.append(f)
                    c_f += 1
        res.append(temp_std)
                
    return res



"""
@Type function
@Author xjp
@CreateDate 2025-03-26_20:03:20
@Description 挑选作为标准流量的流量序列 
@Param 
@Return 
"""
def __chooseFlows(flow_all:List[List[dict]])->List[List[dict]]:
    # 直接随机抽取3个不同的值
    choice_res = []
    # 确认需要挑选的数量
    n_max = min(3, len(flow_all))
    # 按照流量序列中的流量数量分组数据
    group_by_num = {}
    keys = []
    for flows in flow_all:
        key = str(len(flows))
        if key not in group_by_num.keys():
            keys.append(int(key))
            group_by_num[key] = []
        group_by_num[key].append(flows)
    keys.sort(reverse=True)
    flag = False
    while True:
        for key in keys:
            flows_list = group_by_num[str(key)]
            for flows in flows_list:
                choice_res.append(flows)
                n_max -= 1
                if n_max ==0:
                    flag = True
                    break
            if flag:
                break
        if flag:
            break

    return choice_res

"""
@Type function
@Author xjp
@CreateDate 2025-03-26_19:11:51
@Description 构造流量序列(2.0),修正流量顺序问题 
@Param 
@Return 
"""
def __buildSeq2(flow_all:List[List[dict]])->List[dict]:
    # 如果只有一个流量序列的话,则不需要合并流量序列
    if len(flow_all) == 1:
        for flow_list in flow_all:
            for flow in flow_list:
                flow["freq"] = 1
                flow["flag"] = 1
                flow["matched"] = False
        res = flow_all
        return res

    # 给所有流量添加3个属性 freq、flag、matched
    for flow_list in flow_all:
        for flow in flow_list:
            flow["freq"] = 0
            flow["flag"] = 1
            flow["matched"] = False
    
    # 随机抽选一个作为标准(重复3次,对比最终结果是否一致)
    # 直接随机抽取3个不同的值
    choice_res = __chooseFlows(flow_all)

    # 开始构造流量序列
    # 存储最终构造结果
    res = []
    # 对于每一个抽取出的结果分类构造流量序列
    for choice_n in choice_res:
        # 存储每回合变化的标准流量序列
        temp_std =  copy.deepcopy(choice_n)
        # 循环判断每一组流量
        for flow in flow_all:
            # 更新标准流量序列
            cycle_std = copy.deepcopy(temp_std)
            temp_std = []
            # 创建队首游标
            c_s = 0 # 标准流量序列游标
            c_f = 0 # 待比较流量序列游标
            # 过滤c_s 和 c_f
        
            # 循环比对流量
            while c_s < len(cycle_std) and c_f < len(flow):
                # 找到第一个matched标志为False的标准流量
                while c_s < len(cycle_std):
                    if cycle_std[c_s]["matched"] == False:
                        break
                    # 为True则是已经比较过的流量,直接加入到结果集中
                    f = copy.deepcopy(cycle_std[c_s])
                    f["freq"] += 1
                    f["matched"] = False
                    temp_std.append(f)
                    c_s += 1
                # 超出范围
                if c_s == len(cycle_std):
                    break

                # 找到第一个matched标志为False的待比较流量
                while c_f < len(flow):
                    if flow[c_f]["matched"] == False:
                        break
                    c_f += 1
                # 超出范围
                if c_f == len(flow):
                    break 

                # 开始比较流量
                if __compareTwoFlow(cycle_std[c_s], flow[c_f]):
                    # 两条流量相同
                    f = copy.deepcopy(cycle_std[c_s])
                
                    f["freq"] += 1
                    f["matched"] = False
                    temp_std.append(f)
                    c_s += 1
                    c_f += 1
                    continue
            
                # 接下来是流量不同的判断
                #flag_cs = False # 表示在c_f后是否可以找到c_s
                #flag_cf = False # 表示在c_s后是否可以找到c_f
                # 将c_s和c_f之后的流量比较
                cursor = __compDown(c_f,cycle_std[c_s],flow)
                if cursor != -1:
                    # 在c_f之后找到和c_s相似的流量
                    flow[cursor]["matched"] = True
                    f = copy.deepcopy(cycle_std[c_s])
                    f["freq"] += 1
                    f["matched"] = False
                    temp_std.append(f)
                
                    c_s += 1
                else:
                    # 未找到则直接加入到结果集中
                    f = copy.deepcopy(cycle_std[c_s])
                    f["matched"] = False
                    temp_std.append(f)
                
                    c_s += 1
                # 将c_f和c_s之后的流量相比较
                cursor = __compDown(c_s-1,flow[c_f],cycle_std)
                if cursor != -1:
                    # 在c_s之后找到和c_f相似的流量
                    cycle_std[cursor]["matched"] = True
                    c_f += 1
                else:
                    f = copy.deepcopy(flow[c_f])
                    f["freq"] = 1
                    f["matched"] = False
                    temp_std.append(f)
                    c_f += 1

            # 处理剩余的流量
            if c_s == len(cycle_std) and c_f == len(flow):
                continue
            elif c_s != len(cycle_std):
                while c_s < len(cycle_std):
                    f = copy.deepcopy(cycle_std[c_s])
                    if f["matched"] == True:
                        f["freq"] += 1
                    f["matched"] = False
                    temp_std.append(f)
                    c_s +=1
            elif c_f < len(flow):
                while c_f < len(flow):
                    if flow[c_f]["matched"] == True:
                        c_f += 1
                        continue
                    f = copy.deepcopy(flow[c_f])
                    f["freq"] = 1
                    f["matched"] = False
                    temp_std.append(f)
                    c_f += 1
        res.append(temp_std)
                
    return res



"""
@Type function
@Author xjp
@CreateDate 2025-03-28_16:02:41
@Description 根据给定的统计结果,计算最终的流量结构关系
@Param 
@Return 
"""
def __calcFinalSeq(flow_loc:dict)->dict:

    # 1.统计每一项,每个位置出现的次数
    flow_loc_count = {}
    for key in flow_loc.keys():
        flow_loc_count[key] = {}
        for loc in flow_loc[key]["loc"]:
            if str(loc) not in flow_loc_count[key].keys():
                flow_loc_count[key][str(loc)] = 0
            flow_loc_count[key][str(loc)] += 1
    # 所有的位置数量
    all_loc_count = len(flow_loc_count.keys())
    # 2.统计流量序列总数
    total = 0
    for key1 in flow_loc_count.keys():
        count = 0
        for key2 in flow_loc_count[key1].keys():
            count +=  flow_loc_count[key1][key2]
        total = max(total,count)
    thre = int(total / 10)
    # (新加入)每个必出现的项只保留出现次数做多的位置
    # 先统计每项会在哪个位置出现
    
    flow_key_to_loc_res = {}
    for key1 in flow_loc_count.keys():
        # key1 为项名称
        flow_key_to_loc_res[key1] = {}
        if len(flow_loc_count[key1].keys()) == 1:
            # 只在一处出现则直接保留
            flow_key_to_loc_res[key1] = flow_loc_count[key1]
        else:
            temp = ["-1",0]
            for key2 in flow_loc_count[key1].keys():
                # key2为位置
                if flow_loc_count[key1][key2] >=thre:
                    # 确认为必出现项
                    if flow_loc_count[key1][key2] > temp[1]:
                        temp[0] = key2
                        temp[1] = flow_loc_count[key1][key2]
            if temp[0] == "-1":
                # 保留原结果 
                flow_key_to_loc_res[key1] = flow_loc_count[key1]
            else:
                flow_key_to_loc_res[key1][temp[0]] = temp[1]
    # 还原结果
    flow_loc_count = flow_key_to_loc_res
    # 3.统计每个位置,每个流量出现的次数
    flow_loc_to_flow = {}
    for key in flow_loc_count.keys():
        for key2 in flow_loc_count[key].keys():
            if key2 not in flow_loc_to_flow.keys():
                flow_loc_to_flow[key2] = {}
            flow_loc_to_flow[key2][key] = flow_loc_count[key][key2]
    index = 1
    while index <= all_loc_count:
        if str(index) not in flow_loc_to_flow.keys():
            flow_loc_to_flow[str(index)] = {}
        index += 1

    # 移除 未出现的项
    if "0" in flow_loc_to_flow.keys():
        flow_loc_to_flow.pop("0")
    
    # 4.统计每个位置一定会出现的元素
    #thre = int(total / 10)
    loc_ele = {}
    index = 1
    while index <= len(flow_loc_to_flow):
        loc_ele[str(index)] = {}
        temp = []
        for key in flow_loc_to_flow[str(index)].keys():
            if flow_loc_to_flow[str(index)][key] >= thre:
                temp.append(key)
        if len(temp) <= 1:
            for t in temp:
                loc_ele[str(index)][t] = 1
        else:
            for t in temp:
                loc_ele[str(index)][t] = 2
        index += 1

    # 5.确认有需要合并的位置序列
    index = 1
    loc_ele_res = {}
    while index + 1 <= len(loc_ele.keys()):
        if len(loc_ele[str(index)].keys()) == 0:
            loc_ele_res[str(index)] = {}
            index += 1
            continue
        pre = loc_ele[str(index)]
        last = loc_ele[str(index+1)]
        # 先判断是否有交集
        loc_ele_res[str(index)] = copy.deepcopy(loc_ele[str(index)])
        flag = __deterIntersection(pre,last)
        if flag:
            # 如果有交集
            for key in last.keys():
                if key not in pre.keys():
                    loc_ele_res[str(index)][key] = 0
                else:
                    loc_ele_res[str(index)][key] = 1
            for key in pre.keys():
                if key not in last.keys():
                    loc_ele_res[str(index)][key] = 0
            loc_ele[str(index+1)] = {}
        else:
            # 无交集,什么都不需要做
            pass
        index += 1
    loc_ele_res[str(index)] = loc_ele[str(index)]

    # 6.找出未出现的项
    # (1)获取所有的项
    all_keys = list(flow_loc_count.keys())
    # (2)找出已经出现的项
    appear_keys = []
    for key in loc_ele_res.keys():
        try:
            for key2 in loc_ele_res[key].keys():
                appear_keys.append(key2)
        except:
            print(1)
    appear_keys = list(set(appear_keys))
    # (3)获取未出现的项
    disappear_keys = []
    for key in all_keys:
        if key not in appear_keys:
            disappear_keys.append(key)
    
    # 7.找出每一个未出现的项最可能出现的位置
    disappear_loc = {}
    for key in disappear_keys:
        
        temp = []
        for loc in flow_loc_to_flow.keys():
            if key in flow_loc_to_flow[loc].keys():
                if len(temp) == 0:
                    temp = [loc,flow_loc_to_flow[loc][key]]
                else:
                    if flow_loc_to_flow[loc][key]>temp[1]:
                        temp = [loc,flow_loc_to_flow[loc][key]]
        disappear_loc[key] = temp[0]
    
    # 8.将其放到相应的位置
    for key in disappear_loc.keys():
        loc_ele_res[disappear_loc[key]][key] = 0

    # 9.获取最终结果
    final_res = {}
    index = len(loc_ele_res.keys())
    while index >1:
        # 判断当前位置索引的流量是否全为0
        flag = True
        for key in loc_ele_res[str(index)].keys():
            if loc_ele_res[str(index)][key] != 0:
                flag = False
                break
        if flag:
            # 合并到上一个
            for key in loc_ele_res[str(index)].keys():
                loc_ele_res[str(index-1)][key] = loc_ele_res[str(index)][key]
            loc_ele_res[str(index)] = {}
        index -= 1
    index = 1
    for key in loc_ele_res.keys():
        if len(loc_ele_res[key].keys()) == 0:
            continue
        for key2 in loc_ele_res[key].keys():
            loc_ele_res[key][key2] = str(loc_ele_res[key][key2])
        final_res[str(index)] = loc_ele_res[key]
        index += 1
    
    # 确认每一项只出现一次

    return final_res

"""
@Type function
@Author xjp
@CreateDate 2025-03-28_16:42:27
@Description 判断两个位置集合是否有交集 
@Param 
@Return 
"""
def __deterIntersection(loc1:dict, loc2:dict)->bool:
    keys1 = loc1.keys()
    keys2 = loc2.keys()

    keys3 = []
    keys3.extend(keys1)
    keys3.extend(keys2)
    keys3 = list(set(keys3))

    if len(keys3) < len(keys1) + len(keys2):
        # 有交集
        return True
    return False 

"""
@Type function
@Author xjp
@CreateDate 2025-03-27_19:29:55
@Description  构造流量序列算法3(改用所处位置来计算流量序列)
@Param 
@Return 
"""
def __buildSeq3(flow_all:List[List[dict]])->List:
    # 如果只有一个流量序列的话,则不需要合并流量序列
    if len(flow_all) == 1:
        index  = 1
        data = {}
        rel  ={}
        for flow in flow_all[0]:
            data[str(index)] = flow
            rel[str(index)] = {str(index):"1"}
            index += 1
            
        res = {
            "0":{
                "data":data,
                "rel":rel
            }
        }
        
        return res

    data_temp = copy.deepcopy(flow_all)
    choice_res = __chooseFlows(data_temp)

    final_res = {}
    index_res = 0
    for choice in choice_res:
        choice = choice_res[0]
        # 生成初始位置结构
        index = 1
        flow_loc = {}
        # 所有key的排序
        key_sort = []
        for flow in choice:
            flow_loc[str(index)] = {
                    "data":flow, # 该条数据
                    "loc":[], # 所处位置集合
                    "matched":False # 当此是否匹配完成
                }
            key_sort.append(str(index))
            index += 1

        flows_list = copy.deepcopy(data_temp)
        # 得到流量序列结果
        for flows in flows_list:
            __matchFlow(key_sort,flow_loc,flows)
        # 计算得到位置关系
        loc_res = __calcFinalSeq(flow_loc)
        data = {}
        for key in flow_loc.keys():
            data[key] = flow_loc[key]["data"]
        # 填充最终结果
        final_res[str(index_res)] = {
            "data":data,
            "rel":loc_res
        }
        index_res += 1
    return final_res


    # 填补零
    """max_length = 0
    for key in flow_loc.keys():
        max_length = max(max_length,len(flow_loc[key]["loc"]))
    for key in flow_loc.keys():
        num = len(flow_loc[key]["loc"])+9
        while num < max_length:
            flow_loc[key]["loc"].append("0")
            num += 1"""
    
    

"""
@Type function
@Author xjp
@CreateDate 2025-03-27_21:21:27
@Description 
@Param 
@Return 
"""
def __matchFlow(keys, flows_std:dict, flows:List)->bool:
    """
    keys = ["1","2","3",...]
    flows_std = {
        "1":{
            "data":{},
            "loc":[],
            "matched":bool
        },...
    }
    flows = [{},{},{},...]
    """

    # 循环匹配每一个流量
    for i in range(len(flows)):
        flag = False
        for key in keys:
            if flows_std[key]["matched"]:
                continue
            # 比较两条流量是否相似
            if __compareTwoFlow(flows[i],flows_std[key]["data"]):
                # 如果相似
                flag = True
                # 更新位置,加入比较流量的当前位置
                flows_std[key]["loc"].append(i+1)
                flows_std[key]["matched"] = True
                # 表示该条流量匹配上哪条流量
                flows[i]["match_key"] = key
                break
        # 未找到匹配项
        if not flag:
            key = str(len(flows_std.keys())+1)
            flows_std[key] = {
                    "data":flows[i],
                    "loc":[i+1],
                    "matched":True
            }
            flows[i]["match_key"] = key
            if i == 0:
                # 将其插入到首位
                keys.insert(0,key)
            else:
                # 插入其上元素的后面
                loc = keys.index(flows[i-1]["match_key"])
                keys.insert(loc+1,key)
    # 回复状态,并给未匹配到的项添加0
    for key in flows_std.keys():
        #if flows_std[key]["matched"] == False:
            #flows_std[key]["loc"].append(0)
        flows_std[key]["matched"] = False
