"""
@Type doc
@Author xjp
@CreateDate 2025-03-26_09:01:38
@Description 构造因果图相关方法
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""


import os
import json
from typing import List
import copy
from graph import graph, drawGraph


"""
@Type function
@Author xjp
@CreateDate 2025-03-19_21:51:29
@Description 还原流量 
@Param 
@Return 
"""
def __restoreFlow(flows:List):
    res = []
    for flow in flows:
        if flow["direction"] == "d":
            f1 = copy.deepcopy(flow)
            f2 = copy.deepcopy(flow)
            f2["sip"] = f1["dip"]
            f2["dip"] = f1["sip"]
            f2["sport"] = f1["dport"]
            f2["dport"] = f1["sport"]
            f2["time"] = f1["time_last"]
            f1["time_last"] = f1["time"]
            f2["time_last"] = f2["time"]
            f1["direction"] = "s"
            f2["direction"] = "s"
            res.append(f1)
            res.append(f2)
        else:
            res.append(flow)
    return res



"""
@Type function
@Author xjp
@CreateDate 2025-03-26_09:16:59
@Description 构造因果图
@Param 
@Return 
"""
def buildCausalGraph(data:dict)->dict:

    """
    data = {
        'data':{"0":[[{},{},{},...],[],[],...],...},
        "seq":{"0":[{},{},...],...},
        "relations":{"pl":[],"in":[]}
    }
    """
    # 存储最终的图结构
    graph_final = {
        "relations":data["relations"],
        "data":data["data"],
        "seq":data["seq"],
        "graph":{}
    }   
    # 2.遍历数据,构造因果图
    for key in data["seq"].keys():
        graph_final["graph"][key] = []
        index = 0
        for flows in data["seq"][key]:
            flows_c = copy.deepcopy(flows)
            # 还原流量
            flows_c = __restoreFlow(flows_c)
            # 构造流量因果图
            myGraph = graph.Graph(flows_c)
            myGraph.title = key + "-" + str(index)
            index += 1
            # 绘制关系图
            #drawGraph.drawByNetworkx(myGraph)
            # 导出图结构
            graph_res = myGraph.outputGraph()
            graph_final["graph"][key].append(graph_res)
    # 3.返回最终结果
    return graph_final