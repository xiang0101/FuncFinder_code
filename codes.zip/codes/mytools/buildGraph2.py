"""
@Type doc
@Author xjp
@CreateDate 2025-04-02_00:13:20
@Description 新的构造图方法
@Version v2.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

