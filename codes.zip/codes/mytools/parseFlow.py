"""
@Type doc
@Author xjp
@CreateDate 2025-03-20_10:45:08
@Description 解析流量的统一方法
@Version v1.0
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

from scapy.all import rdpcap, Packet, Raw
from . import myRegex
regex = myRegex.MyRegex()
from typing import List

"""
@Type function
@Author xjp
@CreateDate 2025-03-20_10:45:46
@Description 解析一个pcap包 
@Param path:输入文件路径
@Return res = [{},{},{},...]
"""
def parseOnePcap(path:str)->List:
    res = []
    try:
        # 读取流量包
        packets = rdpcap(path)
        if packets != None:   
            for p in packets:
                try:
                    temp = {}
                    # 获取时间戳
                    temp["time"] = p.time
                    if p.haslayer("IP"):
                        # 解析源IP
                        temp["sip"] = p["IP"].src
                        # 解析目的IP
                        temp["dip"] = p["IP"].dst
                        # 解析源port
                        temp["sport"] = str(p["IP"].sport)
                        # 解析目的port
                        temp["dport"] = str(p["IP"].dport)
                        # 解析协议
                        temp["proto"] = p["IP"].proto
                        # 解析URL
                        temp["url"] = __parseUrl(p)
                    # 解析Raw层
                    if p.haslayer(Raw):
                        temp["payload"] = p["Raw"].load.decode().replace("\r\n"," ").replace("\n"," ")[:200]
                        temp["raw"] = p["Raw"].load.decode().split("\r\n")
                    else:
                        temp["payload"] = ""
                        temp["raw"] = ""
            
                    # 汇总结果到最终结果集中
                    res.append(temp)
                except Exception as e:
                    print(e)
    except Exception as e:
        print(f"解析流量失败:{e}")
    #删除无效数据 并处理日期格式
    final_res = []
    for r in res:
        if "sip" in r.keys() and r["sip"] != "":
            if r["payload"] != "":
                # 利用正则表达式替换payload中的特定数据
                r["payload"] = regex.replacePayload(r["payload"])
            if r["url"] != "":
                url, params = regex.extractAndReplaceParams(r["url"])
                r["url"] = url
                r["params"] = params
            else:
                r["params"] = {}
            final_res.append(r)

    final_res.sort(key= lambda t:t["time"])

    # 转换时间数据
    for flow in final_res:
        flow["time"] = str(flow["time"])
    res = final_res
    return res





"""
@Type function
@Author xjp
@CreateDate 2025-03-20_10:46:46
@Description 解析流量中的url 
@Param 
@Return 
"""
def __parseUrl(pack:Packet):
    url = ""
    try:
        if pack.haslayer(Raw):
            # 先获取Raw中的内容
            raw = pack["Raw"].load.decode().split("\r\n")
            for r in raw:
                # 分割内容项
                temp = r.split(" ")
                if temp[0].upper() == "GET" or temp[0].upper() == "POST":
                    url = url + temp[1] 
                elif temp[0].upper() == "HOST:":
                    url = temp[1] + url 
    except Exception as e:
        print(f"__parseUrl:出现异常:{e}")
    return url