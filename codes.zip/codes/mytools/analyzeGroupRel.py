"""
@Type doc
@Author xjp
@CreateDate 2025-04-16_14:49:16
@Description 分析各个组之间的关系
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

from typing import List






"""
@Type function
@Author xjp
@CreateDate 2025-04-16_21:34:46
@Description 获取包含组的最终关系 
@Param 
@Return 
"""
def getIncludeRel(includeRel:dict, prefixGroups:List, singleGroups:List):
    # (1)先给已经分好的前缀组一个标志
    prefix_flag = {}
    index = 1
    for temp in prefixGroups:
        prefix_flag[str(index)] = temp
        index +=1
    
    
    # (3)给包含关系分组
    include_group = {}
    for key1 in includeRel.keys():
        include_group[key1] = {}
        for key2 in includeRel[key1].keys():
            # 找到key2所在分组
            if key2 in singleGroups:
                include_group[key1][key2] = [key2]
            else:
                for key3 in prefix_flag.keys():
                    if key2 in prefix_flag[key3]:
                        if key3 not in include_group[key1].keys():
                            include_group[key1][key3] = []
                        include_group[key1][key3].append(key2)
                        break
    # (4)将包含组中的节点划分为在前缀组中的和不在前缀组中的
    no_prefix_group = []
    prefix_group = []
    for key in includeRel.keys():
        if key in singleGroups:
            no_prefix_group.append(key)
        else:
            prefix_group.append(key)


    res_rel = {}
    # (5)先处理在前缀组中的节点
    for key in prefix_group:
        # 获取该节点关联的其他组
        rel_groups = list(include_group[key].keys())
        # 当只包含于一个组时
        if len(rel_groups) == 1:
            # 先获取该组
            temp = rel_groups[0]
            
            if temp in prefix_flag.keys():
                # 情况1 包含于的组和该组属于一个组(直接剔除该组)
                if key in prefix_flag[temp]:
                    # 属于同一组不保存该节点
                    continue
                else:
                    # 情况2 包含于的组不和该组属于一个组,但是包含于的组为前缀组
                    # 如果该组的节点数量大于包含于的组则保留,否则删除
                    length = 0
                    # 先找到该节点属于的组的长度
                    for k,v in prefix_flag.items():
                        if key in v:
                            length = len(v)
                            break
                    if length < len(prefix_flag[temp]):
                        # 保留结果
                        res_rel[key] = [temp]
            else:
                # 情况3 包含于的组不和该组属于一个组,但是包含于的组不为前缀组
                # 此时直接跳过,因为那个组也会包含于该组
                pass
        else:
            
            flag = False
            for rel in rel_groups:
                if rel in no_prefix_group:
                    continue
                else:
                    flag = True
                    break
            if not flag:
                # 情况4 如果其他组全不为前缀组则跳过
                pass
            # 从中提取出前缀组
            prefix_rel = []
            for rel in rel_groups:
                if rel in prefix_flag.keys():
                    prefix_rel.append(rel)
            # 情况5 如果其他组为混合则去除不在前缀组中的部分
            # 情况6 其他组为前缀组的混合
            # 选择最长的组保留,且如果最长的组为自身所在的组则整组放弃
            now_key = ""
            # 先找到该节点属于的组
            for k,v in prefix_flag.items():
                if key in v:
                    now_key = k
                    break
            # 获取最大长度的组
            max_key = ""
            length = 0
            for key2 in prefix_rel:
                if len(prefix_flag[key2]) > length:
                    length = len(prefix_flag[key2])
                    max_key = key2
            if max_key != now_key:
                res_rel[key] = [max_key]

    # (6)再处理不在前缀节点中的内容
    for key in no_prefix_group:
        # 获取该节点关联的其他组
        rel_groups = list(include_group[key].keys())
        # 情况1 只关联到一组 无论是前缀组还是其他组
        if len(rel_groups) == 1:
            res_rel[key] = [rel_groups[0]]
        else:
            
            
            prefix_rel = []
            no_prefix_rel = []
            for rel in rel_groups:
                if rel in no_prefix_group:
                    no_prefix_rel.append(rel)
                else:
                    prefix_rel.append(rel)
            # 情况2 这些组属于不同前缀组(且组之间存在已经确认的包含关系)
            # 合并到最长的前缀组
            if len(no_prefix_rel) == 0:
                length = 0
                max_key = ""
                for rel in rel_groups:
                    if len(prefix_flag[rel]) > length:
                        length = len(prefix_flag[rel])
                        max_key = rel
                res_rel[key] = [max_key]
            elif len(prefix_rel) == 0:
                # 情况3 这些组全部是非前缀组
                # 合并这些非前缀组
                res_rel[key] = no_prefix_rel
            else:
                # 情况4 这些组是前缀组和非前缀组的混合
                # 如果特征都一致,则剔除该组
                # 如果特征不一致,则将其合并到一个最长的前缀组(前缀组和非前缀组的特征不一致)
                feature = []
                flag = False
                for rel in prefix_rel:
                    # 获取关联的节点
                    rel_nodes = include_group[key][rel]
                    for n in rel_nodes:
                        if len(feature) == 0:
                            feature = [includeRel[key][n][0][0],includeRel[key][n][0][1]]
                        else:
                            temp = [includeRel[key][n][0][0],includeRel[key][n][0][1]]
                            if temp != feature:
                                flag  = True
                                break
                if not flag:
                    for rel in no_prefix_rel:
                        # 获取关联的节点
                        rel_nodes = include_group[key][rel]
                        for n in rel_nodes:
                            if len(feature) == 0:
                                feature = [includeRel[key][n][0][0],includeRel[key][n][0][1]]
                            else:
                                temp = [includeRel[key][n][0][0],includeRel[key][n][0][1]]
                                if temp != feature:
                                    flag  = True
                                    break
                if flag:
                    length = 0
                    max_key = ""
                    for rel in prefix_rel:
                        if len(prefix_flag[rel]) > length:
                            length = len(prefix_flag[rel])
                            max_key = rel
                    res_rel[key] = [max_key]
    # (7)获得关系后,保留最长特征的和最前位置的
    final_res = {}
    # 混组关系
    role_res = []
    for key in res_rel.keys():
        if len(res_rel[key]) > 1:
            temp = [key]
            temp.extend(res_rel[key])
            role_res.append(temp)
            continue
        # 获取涉及的组
        group_prefix = res_rel[key][0]
        # 如果该组在非前缀组中
        if group_prefix not in prefix_flag.keys():
            final_res[key] = group_prefix
        else:
            # 前缀组
            # 获取该组包含的所有key
            group_keys = include_group[key][group_prefix]
            # 获取最长的且最靠前的组
            loc = 0
            s_key = ""
            length = 0
            for key2 in group_keys:
                temp = includeRel[key][key2]
                t_l = temp[0][1] - temp[0][0]
                if t_l > length:
                    loc = temp[0][2]
                    s_key = key2
                    length = t_l
                elif t_l == length:
                    if temp[0][2]<loc:
                        loc = temp[0][2]
                        s_key = key2
                        length = t_l
            final_res[key] = s_key
    return final_res, role_res    
       


"""
@Type function
@Author xjp
@CreateDate 2025-04-16_14:49:36
@Description 分析包含组和前缀组之间的关系
@Param coreRel:包含组的对应关系;prefixGroups:所有的前缀组;
@Return 
"""
def getMergeRelBetweenIncludeAndPrefix(coreRel:dict,prefixGroups:List):
    # (1)先给已经分好组的一个标志
    prefix_res_flag = {}
    index = 1
    for temp in prefixGroups:
        prefix_res_flag[str(index)] = temp
        index +=1

    # (2)给包含关系分组
    include_group = {}
    index = len(prefix_res_flag)+1
    for key1 in coreRel.keys():
        include_group[key1] = {}
        for key2 in coreRel[key1].keys():
            # 找到key2所在分组
            flag = False
            for key3 in prefix_res_flag.keys():
                if key2 in prefix_res_flag[key3]:
                    if key3 not in include_group[key1].keys():
                        include_group[key1][key3] = []
                    include_group[key1][key3].append(key2)
                    flag = True
                    break
            if not flag:
                include_group[key1][str(index)] = [key2]
                index +=1
    # (3) 获取一些信息
    # 获取前缀组的所有编号
    prefix_flags = list(prefix_res_flag.keys())
    # 获取前缀组中的所有项
    prefix_groups = []
    for k,v in prefix_res_flag.items():
        prefix_groups.extend(v)
    # 存储包含组要合并到哪个前缀组中
    merge_include_to_prefix_res = {}

    # (4)开始处理
    # 1) 将所有包含组的key划分为在前缀组中的和不在前缀组中的
    no_prefix_groups = []
    for key in include_group.keys():
        if key not in prefix_groups:
            no_prefix_groups.append(key)
    # 2) 优先处理不在前缀组中的项
    for key1 in no_prefix_groups:
        key2s = list(include_group[key1].keys())
        # a.如果key2s中的组全在前缀组中
        # b.如果key2s中的组有的在前缀组中,有的不在前缀组中
        state = -1
        for key2 in key2s:
            if key2 in prefix_flags:
                state = 1
                break
        if state == -1:
            # c.如果key2s中的组全不在前缀组中
            merge_include_to_prefix_res[key1] = key2s
        else:
            temp = []
            for key2 in key2s:
                if key2 in prefix_flags:
                    temp.append(key2)
            merge_include_to_prefix_res[key1] = temp
    # 3)接下来处理在前缀组中的项
    for key1 in include_group.keys():
        if key1 in no_prefix_groups:
            continue
        key2s = list(include_group[key1].keys())
        temp = []
        # 获取key1所在组的大小
        length = 0
        for t in prefixGroups:
            if key1 in t:
                length = len(t)
                break
        for key2 in key2s:
            if key2 in prefix_flags:
                # 比较两个组的大小,少的向多的合并
                if len(include_group[key1][key2]) >= length:
                    temp.append(key2)
        merge_include_to_prefix_res[key1] = temp
    # 过滤数据,对于同时出现的前缀组,保留数量长的
    res = {}
    for key in merge_include_to_prefix_res.keys():
        if len(merge_include_to_prefix_res[key]) == 0:
            continue
        length = 0
        max_key = ""
        temp = []
        for t in merge_include_to_prefix_res[key]:
            if t in prefix_flags:
                # 表示在前缀组中
                # 获取该组长度
                t_length = len(prefix_res_flag[t])
                if t_length > length:
                    length = t_length
                    max_key = t
            else:
                temp.append(t)
        if max_key != "":
            temp.append(max_key)
        res[key] = temp
    return res