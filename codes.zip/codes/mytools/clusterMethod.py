"""
@Type doc
@Author xjp
@CreateDate 2025-04-10_20:20:32
@Description 公用聚类算法
@Version  v1.0
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""


from typing import List
from sklearn.cluster import KMeans
import numpy as np
from sklearn.ensemble import IsolationForest



"""
@Type function
@Author xjp
@CreateDate 2025-04-10_20:21:20
@Description kmean聚类 
@Param data:数据数据;num:最终聚的类;
@Return 
"""
def clusterKmean(data:List, num:int)->List:
    data_temp = np.array(data).reshape(-1, 1)
    kmeans = KMeans(n_clusters=num, random_state=42)
    cluster_labels = kmeans.fit_predict(data_temp)
    # 计算每个簇的均值和数据点数量
    cluster_means = []
    cluster_sizes = []
    for i in range(num):
        cluster_data = data_temp[cluster_labels == i]
        cluster_means.append(np.mean(cluster_data))
        cluster_sizes.append(len(cluster_data))

        # 假设异常点所在的簇数据量相对较少且簇的均值较大
        # 找出可能的异常点簇的索引
        anomaly_cluster_index = np.argmin(cluster_sizes) if cluster_means[np.argmin(cluster_sizes)] > cluster_means[np.argmax(cluster_sizes)] else np.argmax(cluster_sizes)


        # 找出异常点的索引
        anomaly_indices = np.where(cluster_labels == anomaly_cluster_index)[0]
    return anomaly_indices


"""
@Type function
@Author xjp
@CreateDate 2025-04-10_20:32:53
@Description 随机森林聚类 
@Param data:数据;
@Return 
"""
def clusterIsolationForest(data:List)->List:
    data_temp = np.array(data).reshape(-1,1)
    clf = IsolationForest(contamination=0.1)
    clf.fit(data_temp)
    predictions = clf.predict(data_temp)
    res = []
    for i, pred in enumerate(predictions):
        if pred == -1:
            res.append(i)
    return res