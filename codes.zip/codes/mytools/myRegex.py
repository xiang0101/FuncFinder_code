"""
@Type doc
@Author xjp
@CreateDate 2025-03-10_09:35:49
@Description 正则表达式匹配文件
@Version v1.0
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import regex as re
import sqlparse

"""
@Type class
@Author xjp
@CreateDate 2025-03-10_09:37:34
@Description 正则表达式匹配类
"""
class MyRegex:
    def __init__(self):
        self.patterns = []
        # 替换日期
        self.patterns.append((re.compile(r'date: \w{3}, \d{1,2} \w{3} \d{4} \d{2}:\d{2}:\d{2} GMT'),r'date'))
        # 替换http请求标记
        self.patterns.append((re.compile(r'------WebKitFormBoundary([\w]+)'),r'------WebKitFormBoundaryxxx'))
        # 匹配url中的参数
        self.patternUrlParams = ((re.compile(r'\?([^#]*)')," "))
        self.patterns.append(self.patternUrlParams)

        # 用来匹配sql语句的正则表达式
        #self.sqlPattern = r'(SELECT\s.*FROM|INSERT\sINTO|UPDATE\s.*SET|DELETE\sFROM)'

        # 替换sql语句
        self.sqlPattern = re.compile(r"(?i)(?:--.*\n)*((?:SELECT\s+(?:\*|\w+(?:,\s*\w+)*)\s+FROM\s+\w+(?:\s+WHERE\s+[\w\s=<>()'\".,]+)?)" \
          r"|(?:INSERT\s+INTO\s+\w+\s*\([\w,\s]+\)\s+VALUES\s*\([^)]+\)(?:,\s*\([^)]+\))*)" \
          r"|(?:DELETE\s+FROM\s+\w+(?:\s+WHERE\s+[\w\s=<>()'\".,]+)?)" \
          r"|(?:UPDATE\s+\w+\s+SET\s+[\w\s=,']+(?:,\s*[\w\s=,']+)*\s*(?:WHERE\s+[\w\s=<>()'\".,]+)?))")


    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-24_20:59:23
    @Description 替换sql语句 
    @Param 
    @Return 
    """
    def __replaceSql(self, text:str)->str:
        #print(self.sqlPattern)
        matches = re.findall(self.sqlPattern, text.upper())
        res = None
        if len(matches) != 0:
            res = matches[0].strip()
        if res != None:
            # 识别res属于哪种sql
            sqlType = sqlparse.parse(res)[0]
            if sqlType.get_type() == 'SELECT':
                sqlType = " sqlselect "
            elif sqlType.get_type() == 'INSERT':
                sqlType = " sqlinsert "
            elif sqlType.get_type() == 'UPDATE':
                sqlType = " sqlupdate "
            elif sqlType.get_type() == 'DELETE':
                sqlType = " sqldelete "
            else:
                sqlType = " sql-none "
            text = re.sub(self.sqlPattern,sqlType,text.upper())
        return text

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-24_19:37:18
    @Description 匹配并提取sql语句 
    @Param 
    @Return 
    """
    def matchSql(self, text:str)->bool:
        if text == None or text == "":
            return None
        try:
            res = re.search(self.sqlPattern, text)
        except:
            return None
        if res == None:
            return res
        return res[1]
        

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-10_09:48:53
    @Description 替换payload中的特定内容
    @Param 
    @Return 
    """
    def replacePayload(self, text):
        for pattern in self.patterns:
            text = re.sub(pattern[0],pattern[1],text)
        text = self.__replaceSql(text)
        return text
    
    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-15_16:36:15
    @Description 提取并替换url中的参数 
    @Param 
    @Return 
    """
    def extractAndReplaceParams(self, url)->dict:
        param_res = {}
        # 提取参数
        match = re.search(self.patternUrlParams[0], url)
        if match:
            # 获取匹配到的参数部分
            params_str = match.group(1)
            # 分割参数为键值对列表
            params = params_str.split('&')
            param_dict = {}
            for param in params:
                try:
                    # 分割键和值
                    key, value = param.split('=')
                    param_res[key] = value
                except:
                    continue
        # 替换url中的参数
        url = re.sub(self.patternUrlParams[0],self.patternUrlParams[1],url)

        return url,param_res
    

    """
    @Type function
    @Author xjp
    @CreateDate 2025-04-17_21:43:16
    @Description 替换字符串中的特殊字符 
    @Param 
    @Return 
    """
    def replaceStr(text)->str:
        return re.sub(r'[\x00-\x1f]',' ',text)


if __name__ == "__main__":
    obj = MyRegex()
    
    from sentence_transformers import SentenceTransformer
    from sklearn.metrics.pairwise import cosine_similarity

    # 加载预训练的 SBERT 模型
    model = SentenceTransformer(r'D:\doctor\work\catchflow_gitee\catchflow\models\all-MiniLM-L6-v2')

    text1 = "SELECT * FROM users;"
    text2 = "sasasasINSERT INTO inventory (product_id, product_name, quantity, purchase_date, supplier_id) VALUES (1, 'Laptop', 50, '2023-06-01', 101),(2, 'Mouse', 100, '2023-06-05', 102),(3, 'Keyboard', 80, '2023-06-10', 103);sasaqdw"

    text3 = data_split['13']["data"][0]["payload"]
    # 去除空字节
    r = obj.test(text2)

    # 生成句子嵌入向量
     
    
    import re
    a = re.sub(r'[^\x00-\x7F]+', '', data_split['13']["data"][0]["payload"])
    a = data_split['13']["data"][0]["payload"] + "sasa"
    c = data_split['13']["data"][0]["payload"]
    if a == c:
        print("SA")
    
    
    
    
    
    
    
    
    
    
    