"""
@Type doc
@Author xjp
@CreateDate 2025-03-24_21:41:45
@Description 比较流量是否相同的算法
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

from . import calcSim

"""
@Type function
@Author xjp
@CreateDate 2025-03-24_21:42:30
@Description 比较两条流量是否是反向的 
@Param 
@Return 
"""
def compDualFlow(flow1:dict, flow2:dict)->bool:
    # 获取需要比较的属性
    proto1 = flow1["proto"]
    payload1 = flow1["payload_text"]
    sport1 = str(flow1["sport"])
    dport1 = str(flow1["dport"])

    proto2 = flow2["proto"]
    payload2 = flow2["payload_text"]
    sport2 = str(flow2["sport"])
    dport2 = str(flow2["dport"])

    if sport1 == dport2 and dport1 == sport2:
        if proto1 == proto2:
            if calcSim.compSimType(flow1, flow2):
                return True
    return False


"""
@Type function
@Author xjp
@CreateDate 2025-03-24_21:59:35
@Description 比较完全相同的两条流量 
@Param 
@Return 
"""
def compSameFlow(flow1:dict, flow2:dict)->bool:
    # 获取需要比较的属性
    proto1 = flow1["proto"]
    sport1 = str(flow1["sport"])
    dport1 = str(flow1["dport"])

    proto2 = flow2["proto"]
    sport2 = str(flow2["sport"])
    dport2 = str(flow2["dport"])

    if not (sport1 == sport2 and dport1 == dport2):
        return False
    if proto1 != proto2:
        return False
    if not calcSim.compSimType(flow1, flow2):
        return False
    if "direction" in flow1.keys():
        if flow1["direction"] != flow2["direction"]:
            return False
    return True