"""
@Type doc
@Author xjp
@CreateDate 2025-03-25_09:07:34
@Description 读取文件方法
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import json

"""
@Type function
@Author xjp
@CreateDate 2025-03-25_09:08:08
@Description 读取json格式文件 
@Param 
@Return 
"""
def loadJson(path:str)->dict:
    data = None
    with open(path,'r',encoding="utf-8") as fin:
        data = json.load(fin)
    return data



"""
@Type function
@Author xjp
@CreateDate 2025-03-25_09:09:44
@Description 保存为json文件 
@Param 
@Return 
"""
def saveJson(path:str, data:dict)->None:
    with open(path, 'w', encoding="utf-8") as fout:
        json.dump(data, fout)