"""
@Type doc
@Author xjp
@CreateDate 2025-04-09_20:53:00
@Description 分组数据的2.0版本
@Version v2.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""


from typing import List
from . import calcSim

import numpy as np

from scipy.stats import t
from .clusterMethod import clusterKmean, clusterIsolationForest
import copy


class GroupFlow2:
    def __init__(self):
        # 按照特征分组的结果
        self.__group_by_feature = {}
        # 按照特征分组的索引
        self.index_feature = 0
        # 按照特征分组的数量阈值
        self.num_thre = 1


    """
    @Type function
    @Author xjp
    @CreateDate 2025-04-09_20:57:37
    @Description 按照特征划分数据的主程序
    @Param 
    @Return 
    """
    def groupByFeatures(self, flows_list:List[List])->dict:
         # 按照特征分组的结果
        self.__group_by_feature = {}
        # 按照特征分组的索引
        self.index_feature = 0

        # .将包含特征的按照特征分组
        res = self.__groupByFeatures(flows_list)

        # 编组最终分类数据
        final_res = {}
        index = 0
        for flow_list in res:
            final_res[str(index)] = flow_list
            index += 1
        return final_res





    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-18_10:34:12
    @Description 按照顺序提取流量的第n个特征
    @Param flows:流量序列; loc:第n个流量特征;
    @Return 提取到的特征,如果未提取到则返回空列表
    """

    """
    @Type function
    @Author xjp
    @CreateDate 2025-04-09_20:59:25
    @Description 提取流量序列的中第n个包含特征的流量 
    @Param flows:流量序列;loc:第loc个特征
    @Return 
    """
    def __extractFlowByFeatureLoc(self, flows:List, loc:int = 0)->dict:
        index = 0
        res = None
        for flow in flows:
            if flow["payload_type"] != "none":
                if index == loc:
                    res = flow
                    break
                index += 1
        return res
    

    """
    @Type function
    @Author xjp
    @CreateDate 2025-04-09_21:02:51
    @Description 按照相似特征分组数据 
    @Param 
    @Return 
    """
    def __groupByOneFeature(self, flows_list:List[List], loc:int):
        # 流量序列数量小于一定值后停止分组
        if len(flows_list) <= self.num_thre:
            # 直接形成一个分组
            self.__group_by_feature[str(self.index_feature)] = flows_list
            self.index_feature += 1
            return
        # 左分组,表示匹配上特征的分组
        group_left = []
        # 右分组,表示未匹配上特征的分组
        group_right = []
        feature = []
        # 提取特征
        for flows in flows_list:
            feature_flow = self.__extractFlowByFeatureLoc(flows,loc)
            if feature_flow != None:
                break
        # 如果所有流量序列都没有新特征出现,则将当前分组形成一个新分组
        if feature_flow == None:
            # 直接形成一个分组
            self.__group_by_feature[str(self.index_feature)] = flows_list
            self.index_feature += 1
            return
        # 继续分组数据
        for flows in flows_list:
            res = self.__matchFeatures(flows,feature_flow,loc)
            if res:
                group_left.append(flows)
            else:
                group_right.append(flows)
        # 如果全部分到一组

        # 继续向下比对特征
        if len(group_left) != 0:
            self.__groupByOneFeature(group_left, loc + 1)
        if len(group_right) != 0:
            self.__groupByOneFeature(group_right, loc)


    """
    @Type function
    @Author xjp
    @CreateDate 2025-04-14_21:39:28
    @Description 比较两个流量序列是否相似 
    @Param 
    @Return 
    """
    def __matchTwoFlows(self, flows1, flows2)->bool:
        index = 0
        while True:
            feature1 = self.__extractFlowByFeatureLoc(flows1,index)
            feature2 = self.__extractFlowByFeatureLoc(flows2,index)
            if feature1 == None and feature2 != None:
                return False
            elif feature1 != None and feature2 == None:
                return False
            elif feature1 == None and feature2 == None:
                return True
            else:
                if not self.__matchTwoFeature(feature1, feature2):
                    return False
            index += 1

    """
    @Type function
    @Author xjp
    @CreateDate 2025-04-14_21:30:11
    @Description 按照特征匹配的循环版本 
    @Param 
    @Return 
    """
    def __groupByOneFeatureCycle(self, flows_list:List[List], loc:int):
        # 右分组,表示未匹配上特征的分组
        group_right = copy.deepcopy(flows_list)
        while len(group_right) > 1:
            print(len(group_right))
            flows_std = group_right[0]
            group_left = [flows_std] 
            # 如果所有流量序列都没有新特征出现,则将当前分组形成一个新分组
            

            # 继续分组数据
            group_right_temp = []
            for i in range(len(group_right)-1):
                res = self.__matchTwoFlows(flows_std, group_right[i+1])
                if res:
                    group_left.append(group_right[i+1])
                else:
                    group_right_temp.append(group_right[i+1])
            # group_left形成一个新分组
            self.__group_by_feature[str(self.index_feature)] = group_left
            self.index_feature += 1
            group_right = group_right_temp
        self.__group_by_feature[str(self.index_feature)] = group_right
        self.index_feature += 1

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-24_22:47:30
    @Description  按照特征分组数据 
    @Param 
    @Return 
    """
    def __groupByFeatures(self, flows_list:List[List])->List:
        self.__groupByOneFeatureCycle(flows_list,0)
        res = []
        for key in self.__group_by_feature.keys():
            res.append(self.__group_by_feature[key])

        return res
    

    """
    @Type function
    @Author xjp
    @CreateDate 2025-04-09_21:09:12
    @Description 流量特征匹配算法,从流量序列中提取第n个特征并和给定的特征相匹配(修改了相似度比较算法) 
    @Param flows:流量序列; feature_flow:包含特征的流量; loc:第n个用于比对的特征
    @Return 
    """
    def __matchFeatures(self, flows:List[dict], feature_flow:dict, loc:int)->bool:
        # 提取流量序列的第loc个特征
        res_flow = self.__extractFlowByFeatureLoc(flows, loc)
        if res_flow == None:
            return False
        # 开始比对特征
        #if calcSim.compSimType(feature_flow,res_flow):
        if calcSim.compAllType(feature_flow,res_flow):
            return True
        return False
    


    def __matchTwoFeature(self, feature1, feature2):
        if calcSim.compAllType(feature1,feature2):
            return True
        return False
   
    
    """
    @Type function
    @Author xjp
    @CreateDate 2025-04-10_14:58:37
    @Description 按照时间分割数据(加入分割后的合并还原机制) 
    @Param 
    @Return 
    """
    def groupByTimeInterval(self, flows:List, thre = 10)->List:
        if len(flows) <= 2:
            return [flows]
        # 提取时间序列
        # 时间序列
        time_list = []
        # 将时间序列转换为流量
        time_to_flow = {}
        # 存储字符串格式的时间序列
        keys = []
        # 遍历流量
        for flow in flows:
            time_list.append(float(flow["time"]))
            time_to_flow[str(flow["time"])] = flow
            keys.append(str(flow["time"]))
        # 转换时间序列为numpy数组
        timestamps = np.array(time_list)
        
        # 计算时间间隔
        time_diffs = np.diff(timestamps)
        # 对时间间隔进行k-means聚类
        anomaly_indices = clusterKmean(time_diffs, 2)
        #anomaly_indices = clusterIsolationForest(time_diffs)

        # 根据异常时间间隔,找到异常的时间戳
        time_anomaly = []
        for index in anomaly_indices:
            # 20250409 判断该异常变化是正常的还是异常的(大于thre倍的正常时间间隔均值的异常数据将会被保留)
            #if time_diffs[index] > thre * mean:
            time_anomaly.append(timestamps[index+1])
        # 利用时间分割流量
        res = {}
        index = 0
        temp = []
        for key in keys:
            if float(key) not in time_anomaly:
                temp.append(time_to_flow[key])
            else:
                res[str(index)] =  temp
                index += 1
                temp = [time_to_flow[key]]
        res[str(index)] = temp
        temp = res
        # 查看是否有能合并的数据
        keys = list(temp.keys())
        index = 0
        if len(keys) >1:
            while index < len(keys):
                # 获取当前分组
                flows_t = temp[keys[index]]
                # 查看当前分组是否包含payload不为空的特征
                flag = False
                for flow in flows_t:
                    if flow["payload_type"] != "none":
                        flag = True
                        break
                # 全为空则合并到之前或之后的组中
                if not flag:
                    if index == 0:
                        # 合并到之后的组中
                        temp[keys[index + 1]].extend(temp[keys[index]])
                        # 清空之前的数据
                        temp[keys[index]] = []
                        # 按照时间排序数据
                        temp[keys[index + 1]].sort(key = lambda t : float(t["time"]))
                    elif index == len(keys) - 1:
                        # 找到一个有效的前组
                        t = index - 1
                        while t >= 0:
                            if len(temp[keys[t]]) !=0:
                                break
                            t -=1
                        if t != -1:
                            # 合并到之前的组中
                            temp[keys[t]].extend(temp[keys[index]])
                            # 清空之前的数据
                            temp[keys[index]] = []
                            # 按照时间排序数据
                            temp[keys[t]].sort(key = lambda t : float(t["time"]))
                    else:
                        # 找到一个之前有效的组
                        t_p = index - 1
                        while t_p >= 0:
                            if len(temp[keys[t_p]]) != 0:
                                break
                            t_p -= 1

                        # 找到一个之后有效的组
                        t_l = index + 1
                        while t_l < len(keys):
                            if len(temp[keys[t_l]]) != 0:
                                break
                            t_l += 1

                        if t_p <0:
                            # 合并到后组
                            # 合并到后组
                            temp[keys[t_p]].extend(temp[keys[index]])
                            temp[keys[index]] = []
                            temp[keys[t_p]].sort(key = lambda t : float(t["time"]))
                        elif t_l == len(keys):
                            temp[keys[t_l]].extend(temp[keys[index]])
                            temp[keys[index]] = []
                            temp[keys[t_l]].sort(key = lambda t : float(t["time"]))
                        else:
                            # 比较时间间隔
                            try:
                                if (float(temp[keys[index]][0]["time"]) - float(temp[keys[t_p]][-1]["time"])) < (float(temp[keys[t_l]][0]["time"]) - float(temp[keys[index]][-1]["time"])):
                                # 前面的时间间隔更小,合并到前组
                                    temp[keys[t_p]].extend(temp[keys[index]])
                                    temp[keys[index]] = []
                                    temp[keys[t_p]].sort(key = lambda t : float(t["time"]))
                                else:
                                    # 合并到后组
                                    temp[keys[t_l]].extend(temp[keys[index]])
                                    temp[keys[index]] = []
                                    temp[keys[t_l]].sort(key = lambda t : float(t["time"]))
                            except Exception as e:
                                print(e)
                index +=1
        
        res = []
        # 包装最终数据
        for key in temp.keys():
            if len(temp[key]) != 0:
                res.append(temp[key])
        return res
    
