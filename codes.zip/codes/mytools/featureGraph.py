"""
@Type doc
@Author xjp
@CreateDate 2025-04-15_22:06:46
@Description 特征图相关操作
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""


import networkx as nx
import matplotlib.pyplot as plt
from typing import List
import copy

"""
@Type function
@Author xjp
@CreateDate 2025-04-15_22:07:12
@Description 初始化构造特征图 
@Param key:用于生成图的关键组名称;
@Return 
"""
def initFeatureGraph(key,matrix,features,core_right_index):
    # 创建有向图
    g = nx.DiGraph()
    # 图节点标志
    g_flag = 1
    # 创建核心节点
    index = 0
    nodes = []
    while index < core_right_index:
        g.add_node(g_flag,rel = [key], ntype="core",dtype = matrix[index],features= features[index])
        nodes.append(g_flag)
        g_flag +=1
        index +=1
    # 添加普通节点
    while index < len(matrix):
        g.add_node(g_flag,rel = [key], ntype="no",dtype = matrix[index],features= features[index])
        nodes.append(g_flag)
        g_flag +=1
        index +=1
    # 添加边(无属性)
    index = 1
    while index < len(nodes):
        g.add_edge(nodes[index-1],nodes[index])
        index +=1
    return g





"""
@Type function
@Author xjp
@CreateDate 2025-04-17_10:59:51
@Description 按照具体位置添加一个新节点 
@Param key:核心关键字;
@Return 
"""
def addOneToGraphByLoc(g:nx.DiGraph,key,matrix,features,start_core,end_core,start_node,key_rel:List):
    # 新节点标志
    g_flag = g.number_of_nodes() + 1  
    # 获取入度为0的节点,即首节点
    nodes_0 = __getInDegree(g,0)
    # 找到关联的首节点
    node_head = None
    for node in nodes_0:
        attrs = g.nodes[node]
        keys = attrs["rel"]
        if set(key_rel).intersection(set(keys)):
            # 如果有交集则找到了首节点
            node_head = node
            break
    # 寻找到特定的首节点(即主特征矩阵中的起始匹配成功的位置)
    index= 0
    while index < start_node:
        key_node = __getRelNode(g,node_head,key_rel)
        node_head = key_node
        index +=1




    # 创建新的核心节点
    index = 0
    nodes = []
    while index < start_core:
        g.add_node(g_flag, rel = [key], ntype="secore",dtype = matrix[index],features= features[index])
        nodes.append(g_flag)
        g_flag +=1
        index+=1
    
    # 现在node_head就是分界节点
    # 开始添加边
    if len(nodes)>=1:
        for i in range(len(nodes)-1):
            if i <0:
                break
            g.add_edge(nodes[i],nodes[i+1])
    # 添加核心节点到分支节点的边
        g.add_edge(nodes[-1],node_head)
    # 现在开始融合核心节点
    index = start_core
    while index< end_core:
        # 给节点添加新的key
        g.nodes[node_head]["rel"].append(key)
        # 融合特征
        g.nodes[node_head]["features"] = __mergeFeatures(g.nodes[node_head]["dtype"],g.nodes[node_head]["features"],features[index])
        # 更新数据
        index +=1
        if index != end_core:
            node_head = __getRelNode(g,node_head,key_rel)
        
    # 下面开始添加新的节点
    nodes = []
    index = end_core
    while index <len(matrix):
        g.add_node(g_flag, rel = [key], ntype="no",dtype = matrix[index],features= features[index])
        nodes.append(g_flag)
        g_flag +=1
        index+=1
    # 添加边
    if len(nodes)>1:
        for i in range(len(nodes)-1):
            g.add_edge(nodes[i],nodes[i+1])
    # 添加core节点到特定节点的边
    if len(nodes)>=1:
        g.add_edge(node_head,nodes[0])
    return g


"""
@Type function
@Author xjp
@CreateDate 2025-04-15_22:36:54
@Description 融合一个特征矩阵到现有的图 
@Param 
@Return 
"""
def addOneFeatureToGraph(g:nx.DiGraph,key,matrix,features,start_core,end_core,key_rel:List):
    # 新节点标志
    g_flag = g.number_of_nodes() + 1  
    # 获取入度为0的节点,即首节点
    nodes_0 = __getInDegree(g,0)
    # 找到关联的首节点
    node_head = None
    for node in nodes_0:
        attrs = g.nodes[node]
        keys = attrs["rel"]
        if set(key_rel).intersection(set(keys)):
            # 如果有交集则找到了首节点
            node_head = node
            break
    # 创建新的核心节点
    index = 0
    nodes = []
    while index < start_core:
        g.add_node(g_flag, rel = [key], ntype="secore",dtype = matrix[index],features= features[index])
        nodes.append(g_flag)
        g_flag +=1
        index+=1
    # 找到分界节点
    index = 0
    while index < start_core:
        g.nodes[node_head]["ntype"] = "secore"
        key_node = __getRelNode(g,node_head,key_rel)
        
        node_head= key_node
        index +=1
    # 现在node_head就是分界节点
    # 开始添加边
    if len(nodes)>=1:
        for i in range(len(nodes)-1):
            if i <0:
                break
            g.add_edge(nodes[i],nodes[i+1])
    # 添加核心节点到分支节点的边
        g.add_edge(nodes[-1],node_head)
    # 现在开始融合核心节点
    index = start_core
    while index< end_core:
        # 给节点添加新的key
        g.nodes[node_head]["rel"].append(key)
        # 融合特征
        g.nodes[node_head]["features"] = __mergeFeatures(g.nodes[node_head]["dtype"],g.nodes[node_head]["features"],features[index])
        # 更新数据
        index +=1
        if index != end_core:
            node_head = __getRelNode(g,node_head,key_rel)
        
    # 下面开始添加新的节点
    nodes = []
    index = end_core
    while index <len(matrix):
        g.add_node(g_flag, rel = [key], ntype="no",dtype = matrix[index],features= features[index])
        nodes.append(g_flag)
        g_flag +=1
        index+=1
    # 添加边
    if len(nodes)>1:
        for i in range(len(nodes)-1):
            g.add_edge(nodes[i],nodes[i+1])
    # 添加core节点到特定节点的边
    if len(nodes)>=1:
        g.add_edge(node_head,nodes[0])
    return g

"""
@Type function
@Author xjp
@CreateDate 2025-04-15_23:01:21
@Description 获取一个节点相关联的特定节点 
@Param 
@Return 
"""
def __getRelNode(g,node,keys):
    nodes = __getConnectNode(g,node)
    res = None
    for node in nodes:
        attrs = g.nodes[node]
        key_rel = attrs["rel"]
        if set(key_rel).intersection(set(keys)):
            # 如果有交集则找到了首节点
            res = node
            return res
    return res

"""
@Type function
@Author xjp
@CreateDate 2025-04-17_18:51:38
@Description  找到所有和节点node相连的且特征类型为dtype的节点
@Param 
@Return 
"""
def __getRelTypeNode(g,node,dtype)->List:
    nodes = __getConnectNode(g,node)
    res = []
    for node in nodes:
        attrs = g.nodes[node]
        if attrs["dtype"] == dtype:
            res.append(node)
    return res



"""
@Type function
@Author xjp
@CreateDate 2025-04-15_23:21:29
@Description 融合两个特征矩阵 
@Param 
@Return 
"""
def __mergeFeatures(dtype, features1, features2):
    if dtype == "str" or dtype == "bytes":
        features1.extend(features2)
        features1 = list(set(features1))
    elif dtype == "json":
        pass
        #for k,v in features2.items():
            #features1[k].extend(v)
            #features1[k] = list(set(features1[k]))
    elif dtype == "http-req":
        for k,v in features2.items():
            if k == "params":
                for k2, v2 in features2[k].items():
                    features1[k][k2].extend(v2)
                    features1[k][k2] = list(set(features1[k][k2]  ))
            else:
                features1[k].extend(v)
                features1[k] = list(set(features1[k]))
    elif dtype == "http-res":
        for k,v in features2.items():
            features1[k].extend(v)
            features1[k] = list(set(features1[k]))
    else:
        features1.extend(features2)
        features1 = list(set(features1))
    return features1
                      


"""
@Type function
@Author xjp
@CreateDate 2025-04-15_22:40:00
@Description 获取入度为num的节点 
@Param 
@Return 
"""
def __getInDegree(g:nx.DiGraph,num):
    res = []
    for node in g.nodes():
        if g.in_degree(node) == num:
            res.append(node)
    return res


"""
@Type function
@Author xjp
@CreateDate 2025-04-15_22:59:41
@Description 获取一个节点相连的所有节点 
@Param 
@Return 
"""
def __getConnectNode(g, node):
    res = [target for _,target in g.out_edges(node)]
    return res


"""
@Type function
@Author xjp
@CreateDate 2025-04-16_18:42:06
@Description 修改节点数据 
@Param node:如果是None则修改全部节点,否则修改特定节点
@Return 
"""
def updateNodeAttr(g:nx.DiGraph,node=None,key="",value=""):
    try:
        if node == None:
            for _,attr in g.nodes(data=True):
                attr[key] = value
    except:
        return None
    return g


"""
@Type function
@Author xjp
@CreateDate 2025-04-17_18:43:34
@Description 匹配两个特征矩阵合集 
@Param 
@Return 
"""
def __matchTowFeatures(dtype,features1, features2)->bool:
    if dtype == "str":
        t1 = set(features1)
        t2 = set(features2)
        
        if not t1 & t2:
            return False
        return True 
    elif dtype == "bytes":
        test1 = [f[:8] for f in features1]
        test2 = [f[:8] for f in features2]
        if not bool(set(test1).intersection(set(test2))):
            return False
        return True
    elif dtype == "json":
        if set(list(features1.keys()))!= set(list(features2.keys())):
            return False
        return True
    elif dtype == "http-req":
        if set(list(features1.keys()))!= set(list(features2.keys())):
            return False
        
        # 比较几个特定特征
        if "method" in features1.keys() and "method" in features2.keys():
            
            if not bool(set(features1["method"]).intersection(set(features2["method"]))):
                return False
        

        # 比较uri  
        if "uri" in features1.keys() and "uri" in features2.keys():
            
            if not bool(set(features1["uri"]).intersection(set(features2["uri"]))):
                return False
        # 比较参数类型
        if set(features1["params"].keys()) != set(features2["params"].keys()):
            return False
        
        return True 
    elif dtype == "http-res":
        if set(list(features1.keys()))!= set(list(features2.keys())):
            return False
        if "code" in features1.keys() and "code" in features2.keys():
            
            if not bool(set(features1["code"]).intersection(set(features2["code"]))):
                return False
        if "Server" in features1.keys() and "Server" in features2.keys():
            
            if not bool(set(features1["Server"]).intersection(set(features2["Server"]))):
                return False
        if "Content-Type" in features1.keys() and "Content-Type" in features2.keys():
            
            if not bool(set(features1["Content-Type"]).intersection(set(features2["Content-Type"]))):
                return False
        return True
    else:
        if features1 == features2:
            return True
        return False


"""
@Type function
@Author xjp
@CreateDate 2025-04-17_18:41:31
@Description 将特征和图匹配
@Param g:图;matrix:特征矩阵;features:特征合集
@Return 
"""
def matchFeatureAndGraph(g,matrix, features)->int:
    # 存储最终结果
    res = 0
    # 1.找到所有入度为0的节点,即首节点
    nodes_0 = __getInDegree(g,0)
    # 2.匹配找到最长匹配结果
    # 下一个可以匹配的节点集合
    m_nodes = nodes_0
    n_nodes = [] # 下一个匹配的节点
    for i in range(len(matrix)):
        # 当前位置的特征
        m = matrix[i]
        # 遍历节点,找到可以匹配的节点
        for n in m_nodes:
            # 判断节点之间的类型是否相同
            attrs = g.nodes[n]
            dtype = attrs["dtype"]
            if dtype == m:# 类型一致
                # 判断特征是否一致
                feats = attrs["features"]
                if __matchTowFeatures(dtype, feats,features[i]):
                    # 如果匹配成功
                    n_nodes.append(n)
        # 判断是否有匹配成功的节点
        m_nodes = n_nodes
        n_nodes = []
        if len(m_nodes) !=0:
            res +=1
            # 找到接下来相关的节点
            if i +1 != len(matrix):
                for n in m_nodes:
                    t = __getRelTypeNode(g,n,matrix[i+1])
                    n_nodes.extend(t)
        m_nodes = copy.deepcopy(n_nodes)
        n_nodes = []
        if len(m_nodes) ==0:
            break
    return res

"""
@Type function
@Author xjp
@CreateDate 2025-04-18_09:30:14
@Description 将子图的前缀和总图所有位置相匹配,找到最大匹配数量
@Param 
@Return 
"""
def matchSubPrefixToMain(g:nx.DiGraph,matrix,features):
    # 存储最终结果
    res = 0
    # 1.找到所有入度为0的节点,即首节点
    nodes_0 = __getInDegree(g,0)
    # 2.获取子图的首特征和首特征值
    f_m = matrix[0]
    f_f = features[0]
    # 3.找到图中所有和首特征相同的起始节点
    s_nodes = []
    for node,data in g.nodes(data=True):
        if data["dtype"] == f_m:
            if __matchTowFeatures(f_m,data["features"],f_f):
                s_nodes.append(node)
    # 4.从每个匹配上的节点开始,找到每个最长子串
    m_nodes= s_nodes
    s_nodes = []
    index = 1
    while index < len(matrix):
        for m in m_nodes:
            t_nodes = __getRelTypeNode(g,m,matrix[index])
            if len(t_nodes) == 0:
                continue
            for t in t_nodes:
                if __matchTowFeatures(matrix[index],g.nodes[t]["features"],features[index]):
                    s_nodes.append(t)
        if len(s_nodes) == 0:
            break
        res +=1
        m_nodes = s_nodes
        s_nodes= []    
        index +=1
    return res