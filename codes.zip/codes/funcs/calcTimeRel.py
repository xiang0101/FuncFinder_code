"""
@Type doc
@Author xjp
@CreateDate 2025-05-06_15:50:04
@Description 计算各个组之间是否具有时间上的关系
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import copy


"""
@Type function
@Author xjp
@CreateDate 2025-05-06_15:50:55
@Description 计算各个组之间是否具有时间关系 
@Param 
@Return 
"""
def calcTimeRelations(data:dict):
    # 编码组,给每个流量序列组一个特定编号
    data_flag = {}
    for key in data.keys():
        index = 0
        data_flag[key] = {}
        for flows in data[key]:
            data_flag[key][str(index)] = flows
            index +=1

    # 
    time_res  ={}
    for key1 in data_flag.keys():
        time_res[key1] = {}
        for key2 in data_flag.keys():
            if key1 == key2:
                continue
            time_res[key1][key2] = __calcTimeRelations(data_flag[key1], data_flag[key2])



    # 计算所有的合并有效性
    merge_res = {}
    for key1 in time_res.keys():
        merge_res[key1] = {}
        for key2 in time_res[key1].keys():
            if len(time_res[key1][key2]) == 0:
                continue
            merge_res[key1][key2] = []        
            for g in time_res[key1][key2]:
                # 先取出流量序列
                flows1 = data_flag[key1][g[0][2]]
                flows2 = data_flag[key2][g[1][2]]
                # 过滤端口
                ports = [flows1[0]["sport"],flows1[0]["dport"],flows2[0]["sport"],flows2[0]["dport"]]
                ports = list(set(ports))
                if len(ports) == 2:
                    merge_res[key1][key2].append([g[0][2],g[1][2],float(g[1][0])])

    # 保留有效项
    merge_res_temp = {}
    for key1 in merge_res.keys():
        for key2 in merge_res[key1].keys():
            count = len(merge_res[key1][key2])
            if count == 0:
                continue
            total1 = len(data_flag[key1].keys())
            total2 = len(data_flag[key2].keys())
            if count >= total1*0.3 or count >= total2*0.3:
                if key1 not in merge_res_temp.keys():
                    merge_res_temp[key1] = {}
                merge_res_temp[key1][key2] = merge_res[key1][key2]
    merge_res = merge_res_temp
    # 解决冲突
    merge_res_temp = {}
    for key in merge_res.keys():
        merge_res_temp[key] = __solveConflicts(merge_res[key])

    merge_res = merge_res_temp

    import networkx as nx
    # 创建有向无环图
    G = nx.DiGraph()
    edges = []
    for key1 in merge_res.keys():
        for key2 in merge_res[key1].keys():
            edges.append((key1,key2))
    G.add_edges_from(edges)

    try:
        topological_order = list(nx.topological_sort(G))
    except Exception as e:
        print(e)

    data_flag_temp = __mergeDataBySort(data_flag, topological_order, merge_res)
    data = {}
    for key1 in data_flag_temp.keys():
        if len(data_flag_temp[key1].keys()) ==0:
            continue
        temp = []
        for key2 in data_flag_temp[key1].keys():
            temp.append(data_flag_temp[key1][key2])
        data[key1] = temp

    






def __calcTimeRelations(flows_dict1, flows_dict2):
    time_list = []
    
    for key in flows_dict1:
        flows = flows_dict1[key]
        temp = [flows[-1]["time"],'A',key]
        time_list.append(temp)

    for key in flows_dict2:
        flows = flows_dict2[key]
        temp = [flows[0]["time"],'B',key]
        time_list.append(temp)

    

    time_list.sort(key=lambda t : float(t[0]))
    # 统计A后面紧接着B且时间间隔不超过一定阈值的次数
    res  = []
    index = 0
    while index+1 < len(time_list):
        if time_list[index][1] == "A":
            if time_list[index+1][1] == "B":
                if (float(time_list[index+1][0])-float(time_list[index][0])) < 10:
                    res.append([time_list[index],time_list[index+1]])
                    index +=1
        index +=1 
    return res


# 对于有冲突的项,保留时间靠前的项
def __solveConflicts(data:dict)->dict:
    if len(data.keys()) == 1:
        return data
    # 获取每一个流量可以合并的集合
    data_temp = {}
    for key in data.keys():
        for temp in data[key]:
            if temp[0] not in data_temp.keys():
                data_temp[temp[0]] = {}
            data_temp[temp[0]][key] = temp
    data_res = {}
    for key1 in data_temp.keys():
        if len(data_temp[key1].keys()) == 1:
            data_res[key1] = data_temp[key1]
        else:
            max_key = ""
            min_value = 0
            for key2 in data_temp[key1].keys():
                temp = data_temp[key1][key2]
                if max_key == "":
                    max_key = key2
                    min_value = temp[2]
                elif temp[2] < min_value:
                    max_key = key2
                    min_value = temp[2]
            data_res[key1] = {}
            data_res[key1][max_key] = data_temp[key1][max_key]
    # 还原结果
    res = {}
    for key1 in data_res.keys():
        for key2 in data_res[key1].keys():
            if key2 not in res.keys():
                res[key2] = []
            res[key2].append(data_res[key1][key2])

    return res


# 根据拓扑排序结果合并数据
def __mergeDataBySort(group_flag, sort_res, relations):
    group_flag_temp = copy.deepcopy(group_flag)
    for key1 in sort_res:
        if key1 not in relations.keys():
            continue
        for key2 in relations[key1].keys():
            for temp in relations[key1][key2]:
                flows1 = group_flag_temp[key1][temp[0]]
                flows2 = group_flag_temp[key2][temp[1]]
                flows1.extend(flows2)
                group_flag_temp[key2][temp[1]] = flows1
                group_flag_temp[key1].pop(temp[0])
    return group_flag_temp