"""
@Type doc
@Author xjp
@CreateDate 2025-05-12_16:36:39
@Description 各个分组之间的匹配算法
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import sys
sys.path.append("../")
from mytools import featureMatrix, mergeFeatureMatrix, analyzeGroupRel
import copy


"""
@Type function
@Author xjp
@CreateDate 2025-05-14_15:16:45
@Description 匹配各个高组之间的关系 
@Param 
@Return 最大前缀匹配结果和最大包含匹配结果
"""
def matchHighGroups(groups:dict)->dict:
    
    # 1.获取组的最长前缀组
    prefix_group_res = __matchMaxPrefix(groups)
    # 2.获取组之间的最长包含组
    include_group_res = __matchMaxInclude(groups)
    
    
    # 3.获取所有在前缀组中的组,按照前缀数量划分组
    prefixGroups = []
    for key in prefix_group_res.keys():
        temp1 = prefix_group_res[key]
        for temp2 in temp1:
            flag = False
            for i in range(len(prefixGroups)):
                temp = prefixGroups[i]
                if set(temp).intersection(set(temp2)):
                    temp.extend(temp2)
                    prefixGroups[i] = temp
                    flag = True
                    break
            if not flag:
                prefixGroups.append(temp2)
    for i in range(len(prefixGroups)):
        prefixGroups[i] = list(set(prefixGroups[i]))


    # 4.各个部分的节点
    single_nodes = []
    prefix_nodes = []

    # 5.获取所有前缀节点
    for temp in prefixGroups:
        prefix_nodes.extend(temp)

    # 6.找到单图节点
    all_nodes = list(groups.keys())
    for n in all_nodes:
        if n not in prefix_nodes:
            single_nodes.append(n)



    # 7.给节点分组
    include_final_group = analyzeGroupRel.getIncludeRel(include_group_res, prefixGroups, single_nodes)
    """
    include_final_group = {
        "0":{"3":"2"}
        }
    """

    # 8.获取包含关系的最终合并方案
    merge_include_final = {}
    for key in include_final_group[0].keys():
        merge_include_final[key] = [include_final_group[0][key],include_group_res[key][include_final_group[0][key]]]
    """
    merge_include_final = {
        "3":["2",[2,4,2]]
        }
    """
    return prefix_group_res,merge_include_final
    
    


"""
@Type function
@Author xjp
@CreateDate 2025-05-12_16:37:23
@Description 匹配最大前缀
@Param groups = {"1":[[],[],[],[],...],"2":[[],[],[],...],...}
@Return 按照最大前缀数量分组的结果
"""
def __matchMaxPrefix(groups:dict)->dict:
    # 1.提取特征矩阵和特征值
    feature_matrix = featureMatrix.extractCoreFeatureMatrix(groups)
    # 2.找到每一个分组和其他分组的最大匹配前缀,即特征类型和特征全部匹配上，且是最长匹配

    max_prefix = {}
    # 遍历每个组
    for key1 in feature_matrix.keys():
        # 初始化最大前缀矩阵
        max_prefix[key1] = {}
        # 遍历每一个不重复的组
        for key2 in feature_matrix.keys():
            if key1 == key2:
                continue
            # 计算key1指向的组和key2指向的组的最大前缀
            max_prefix[key1][key2] = mergeFeatureMatrix.extractMaxFeaturePrefix(feature_matrix[key1]["core_feature_matrix"], feature_matrix[key2]["core_feature_matrix"], feature_matrix[key1]["features"], feature_matrix[key2]["features"])
    """
    max_prefix = {
        "0":{"1":[最大前缀],2:[]},
        "1":{"0":[],2:[]},
        "2":{"0":[],"1":[]}
        }
    """

    # 3.过滤干扰项,清除不包含前缀的项
    for key1 in max_prefix.keys():
        keys = list(max_prefix[key1].keys())
        for key2 in keys:
            if len(max_prefix[key1][key2]) ==0:
                t = max_prefix[key1].pop(key2)
    
    # 4.清除整体的无效项,清除和其他组都不包含前缀的项
    max_prefix_temp = {}
    for key in max_prefix.keys():
        if len(max_prefix[key].keys()) != 0:
            max_prefix_temp[key] = max_prefix[key]
    max_prefix = max_prefix_temp
    
    # 5.提取每个组的最长前缀组,保留最长的前缀的组
    max_prefix_temp = {}
    for key in max_prefix.keys():
        max_prefix_temp[key] = {}
        # 先统计最大长度
        length = 0
        for key2 in max_prefix[key].keys():
            if len(max_prefix[key][key2])>length:
                length = len(max_prefix[key][key2])
        # 获取最大长度项
        for key2 in max_prefix[key].keys():
            if len(max_prefix[key][key2]) == length:
                max_prefix_temp[key][key2] = max_prefix[key][key2]
    max_prefix = max_prefix_temp
    

    # 6.过滤特征列表
    filter_feature = ["bytes"]
    # 此处需要过滤一些特征长幅度为1的组(已经实现)
    keys = list(max_prefix.keys())
    for key in keys:
        temp = []
        for key2 in max_prefix[key].keys():
            flag = True
            if len(max_prefix[key][key2]) == 1:
                if max_prefix[key][key2][0] in filter_feature:
                    flag = False
            if not flag:
                temp.append(key2)
        for t in temp:
            max_prefix[key].pop(t)
        if len(max_prefix[key].keys()) == 0:
            max_prefix.pop(key)
    
    # 7.按照长度分组前缀组
    prefix_group_by_length = {}
    for key in max_prefix.keys():
        temp = [key]
        length = 0
        for key2 in max_prefix[key].keys():
            temp.append(key2)
            length = len(max_prefix[key][key2])
        if str(length) not in prefix_group_by_length.keys():
            prefix_group_by_length[str(length)] = []
        prefix_group_by_length[str(length)].append(temp)
        
    """
    prefix_group_by_length = {
        "4":[["1","2"],["2","1"]],
        "6":[["3","1"],["1","3"],...],...
        }
    """

    # 8.合并有交叉的组,去除重复组
    prefix_group_res = {}
    for key in prefix_group_by_length.keys():
        prefix_group_res[key] = []
        temp1 = prefix_group_by_length[key]
        count = 0
        while count != len(temp1):
            res = []    
            for i in range(len(temp1)):
                if len(temp1[i]) == 0:
                    continue
                if len(res) == 0:
                    res =temp1[i]
                    temp1[i] = []
                    count +=1
                else:
                    # 判断是否有交集,如果有则合并
                    if len(set(res).intersection(set(temp1[i]))) != 0:
                        res.extend(temp1[i])
                        temp1[i] = []
                        count +=1
            res = list(set(res))
            prefix_group_res[key].append(res)
        """
        prefix_group_by_length = {
            "4":[["1","2"]],
            "6":[["3","1"],...],...
            ]\
            }
        """
    return prefix_group_res
    

"""
@Type function
@Author xjp
@CreateDate 2025-05-13_14:45:08
@Description 计算最大包含关系 
@Param 
@Return 
"""
def __matchMaxInclude(groups:dict)->dict:
    # 1.提取特征矩阵和特征值
    feature_matrix = featureMatrix.extractCoreFeatureMatrix(groups)
    # 2.计算包含关系
    max_include = {}
    for key1 in feature_matrix.keys():
        max_include[key1] = {}
        for key2 in feature_matrix.keys():
            if key1 == key2:
                continue
            # 此处判断了两个特征矩阵的长度,所以结果是单向的而不是双向的
            max_include[key1][key2] = mergeFeatureMatrix.extractMaxFeatureSubSeq2(feature_matrix[key1]["core_feature_matrix"], feature_matrix[key2]["core_feature_matrix"], feature_matrix[key1]["features"], feature_matrix[key2]["features"])
    """
    max_include = {
        "0":{"1":[],"2":[],"3":[]},
        # 1:表示子串的起始位置,3:为子串的终止位置,1:为主串的起始匹配位置
        "1":{"0":[[1,3,1]],"2":[],"3":[]},
        "2":{"0":[],"1":[],"3":[]},
        "3":{"0":[],"1":[],"2":[[2,4,2]]}
        }
    """


    # 3.过滤干扰项,清除不包含的项
    for key1 in max_include.keys():
        keys = list(max_include[key1].keys())
        for key2 in keys:
            if len(max_include[key1][key2]) ==0:
                t = max_include[key1].pop(key2)
    # 4.清除整体的无效项
    max_include_temp = {}
    for key in max_include.keys():
        if len(max_include[key].keys()) != 0:
            max_include_temp[key] = max_include[key]
    max_include = max_include_temp
    max_include_temp = None


    # 5. 提取每个组可能被哪个其他组包含
    include_group_res = {}
    for key1 in max_include.keys():
        for key2 in max_include[key1].keys():
            if key2 not in include_group_res.keys():
                include_group_res[key2] = {}
            include_group_res[key2][key1] = max_include[key1][key2]
            
    
    """ 包含结果
    include_group_res = {
        "1":{"0":[[1,3,1]]},
        "3":{"2":[[2,4,2]]}
        }
    """
    return include_group_res
    
    
    
    
    
    