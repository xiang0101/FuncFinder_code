"""
@Type doc
@Author xjp
@CreateDate 2025-05-19_16:29:56
@Description 生成特征图 
@Version 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""
import sys
sys.path.append("../")

from mytools import featureGraph


"""
@Type class
@Author xjp
@CreateDate 2025-05-19_16:30:31
@Description 特征图类 
"""
class FeatureGraph:
    
    """
    @Type function
    @Author xjp
    @CreateDate 2025-05-19_17:31:00
    @Description 初始化函数 
    @Param matrix:初始化的特征矩阵;features:初始化的特征;
    @Return 
    """
    def __init__(self, key, feature_matrix, core_right):
        self.key = key
        self.feature_matrix = feature_matrix
        self.core_right = core_right
        # 特征图
        self.g = None
        self.__initGraph()
    
    """
    @Type function
    @Author xjp
    @CreateDate 2025-05-19_17:41:58
    @Description 初始化图  
    @Param 
    @Return 
    """
    def __initGraph(self):
        self.g = featureGraph.initFeatureGraph(self.key, matrix = self.feature_matrix["core_feature_matrix"], features=self.feature_matrix["features"], core_right_index=self.core_right)


    """
    @Type function
    @Author xjp
    @CreateDate 2025-05-19_19:20:06
    @Description 合并一个子图到原图上 
    @Param 
    @Return 
    """
    def mergeGraph(self,key, feature_matrix, loc_list, over_nodes):
        self.g = featureGraph.addOneToGraphByLoc(self.g, key, feature_matrix["core_feature_matrix"], feature_matrix["features"], loc_list[0], loc_list[1], loc_list[2], over_nodes)