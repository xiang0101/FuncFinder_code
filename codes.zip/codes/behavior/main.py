"""
@Type doc
@Author xjp
@CreateDate 2025-04-14_23:17:47
@Description 算法主程序
@Version v3.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""


#from evaluation import FMI

# data_group = data_temp
#res = FMI(data_group)
import sys
sys.path.append("../")
from mytools import myFile, groupFlow, mergeFlow, groupFlow2, featureMatrix, mergeFeatureMatrix, featureGraph, analyzeGroupRel, calcSim
from funcs import createFeatureGraph,matchGroups,calcTimeRel

import numpy as np
from collections import Counter
import random
import copy
import os

import shutil

from result.evaluation import FMI,ARI
from typing import List
#import numpy as np
import math

rootPath = "E:/doctor/小论文/流量分析/实验/new_method/dataset/res/SS/"
name = "gitlab1"

inputPath = rootPath + name + ".json" 
outputPath = "./res/" + name + "_mine.json"

# 1.读取数据 myFile.py
data = myFile.loadJson(inputPath)




# 2.基本分组数据 groupFlow.py
group = groupFlow.GroupFlow()

# (1)按照ip分组数据
data_ip = group.groupByIp(data)

# (2).按照端口对划分数据
data_port = []
for data_temp in data_ip:
    data_port_temp = group.groupByPort(data_temp)
    data_port.extend(data_port_temp)
data_ip = None    


# (3).按照时间间隔分割数据
data_time = []
for flows in data_port:
    data_time.extend(group.groupByTimeInterval(flows,10))
data_port = None


# 3.合并相反方向的流量 mergeFlow.py
data_dual = []
for flows in data_time:
    data_dual.append(mergeFlow.mergeDualFlow(flows))
    
      
    
# 4.合并连续的流量 mergeFlow.py
data_same = []
for flows in data_dual:
    data_same.append(mergeFlow.mergeSameFlow(flows))
#data = data_same


# 清除干扰数据(没有payload的流量数据)和流量序列中流量数量小于一定数值的数据

# 后续要考虑一些是否要清除
data_temp = []
for d in data_same:
    if len(d) <=1:
        continue
    flag = False
    # 先判断是否有payload
    for flow in d:
        if flow["payload_type"] != "none":
            flag  =True
            break
    if flag:
        data_temp.append(d)

data_same = data_temp






# 临时加入 还原流量
def __restoreFlow(flows):
    res = []
    for flow in flows:
        if flow["direction"] == "d":
            f1 = copy.deepcopy(flow)
            f2 = copy.deepcopy(flow)
            f2["sip"] = f1["dip"]
            f2["dip"] = f1["sip"]
            f2["sport"] = f1["dport"]
            f2["dport"] = f1["sport"]
            f2["time"] = f1["time_last"]
            f1["time_last"] = f1["time"]
            f2["time_last"] = f2["time"]
            f1["direction"] = "s"
            f2["direction"] = "s"
            res.append(f1)
            res.append(f2)
        else:
            res.append(flow)
    return res


for i in range(len(data_same)):
    data_same[i] = __restoreFlow(data_same[i])

# 5.按照特征分组数据(按照特征完全相同分组)

group2 = groupFlow2.GroupFlow2()
data_feature = group2.groupByFeatures(data_same)


# 划分低组和高组
low_group = {}
high_group = {}
for key in data_feature.keys():
    #if len(data_feature[key]) <=mean:
    if len(data_feature[key]) <=10:
        low_group[key] = data_feature[key]
    else:
        high_group[key] = data_feature[key]

t = ARI(high_group)


#------------------------------------ 时间计算 -------------------------------------------------------
# 6.查看高组之间是否存在时间顺序合并的关系

# 计算每两个组之间的时间关系

calcTimeRel.calcTimeRelations(high_group)

"""




#  打混所有的组重新分组
    all_group = []
    for key in data.keys():
        for temp in data[key]:
            all_group.append(temp)
    for key in low_group.keys():
        for temp in low_group[key]:
            all_group.append(temp)

    data_feature = group2.groupByFeatures                                                                                                                                                            (all_group)
"""

# ---------------------------------------------------------------------------------------
# 7.尝试按照包含关系合并高组














# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!












        
        
        
        

    
    

                
        

# (8)过滤包含关系
# 先获取各个分组包含的内容
# 1)先给已经分好其中前缀组的一个标志






# ************************************************************************************************
# 特征矩阵
feature_matrix = featureMatrix.extractCoreFeatureMatrix(high_group)

# 计算前缀匹配和包含匹配的结果
prefix_group_res, include_group_res = matchGroups.matchHighGroups(high_group)


# 8.构建特征图

# (1)理清图生成顺序

# 1)包含节点图
include_nodes = list(include_group_res.keys())


# 2)前缀节点图
prefixGroups = []
for key in prefix_group_res.keys():
    temp1 = prefix_group_res[key]
    for temp2 in temp1:
        flag = False
        for i in range(len(prefixGroups)):
            temp = prefixGroups[i]
            if set(temp).intersection(set(temp2)):
                temp.extend(temp2)
                prefixGroups[i] = temp
                flag = True
                break
        if not flag:
            prefixGroups.append(temp2)
for i in range(len(prefixGroups)):
    prefixGroups[i] = list(set(prefixGroups[i]))
prefix_nodes = []
for temp in prefixGroups:
    prefix_nodes.extend(temp)
prefix_nodes_temp = []
for p in prefix_nodes:
    if p not in include_nodes:
        prefix_nodes_temp.append(p)
prefix_nodes = prefix_nodes_temp

# 3)单节点图
single_nodes = []
all_nodes = list(high_group.keys())
for a in all_nodes:
    if a not in include_nodes and a not in prefix_nodes:
        single_nodes.append(a)




# (2)开始创建图
# 存储所有图的结构
all_graphs = {}

# 1)创建单节点图
for key in single_nodes:
    g = createFeatureGraph.FeatureGraph(key, feature_matrix[key], 0)
    all_graphs[key] = g


# 2)创建前缀节点图
prefix_rels = copy.deepcopy(prefix_group_res)
# 过滤掉不在前缀图中的节点
prefix_rels_temp = {}
for key in prefix_rels.keys():
    temp1 = []
    for rels in prefix_rels[key]:
        temp2 = []
        for t in rels:
            if t in prefix_nodes:
                temp2.append(t)
        if len(temp2) != 0:
            temp1.append(temp2)
    if len(temp1) != 0:
        prefix_rels_temp[key] = temp1
prefix_rels = prefix_rels_temp

prefix_keys = list(prefix_rels.keys())

prefix_keys.sort(key = lambda t : int(t), reverse=True)

over_nodes= []
for key in prefix_keys:
    for temp in prefix_rels[key]:
        g = None
        s_key = ""
        # 先查找是否有合并标准
        for key2 in all_graphs.keys():
            if bool(set(temp).intersection(set(key2.split("-")))):
                s_key = key2
                g = all_graphs[key2]
                break
        # 需要创建新图
        temp_nodes = []
        if g == None:
            # 存储已经处理过的节点
            key2 = temp[0]
            # 创建图
            g = createFeatureGraph.FeatureGraph(key2, feature_matrix[key2],int(key))
            
            over_nodes.append(key2)
            temp_nodes.append(key2)
        # 循环添加其他节点
        for t in temp:
            if t in over_nodes:
                continue
            g.mergeGraph(t, feature_matrix[t], [0, int(key), 0], temp)
            over_nodes.append(t)
            temp_nodes.append(t)
        if s_key == "":
            all_graphs["-".join(temp_nodes)] = g
        else:
            t = s_key.split("-")
            t.extend(temp_nodes)
            t = list(set(t))
            all_graphs["-".join(t)] = g
            all_graphs.pop(s_key)
    

    
# 开始创建前缀图

    

# 3)创建包含节点图
for key in include_group_res.keys():
    # 合并到的节点key
    key2 = include_group_res[key][0]
    # 合并信息
    temp = include_group_res[key][1][0]
    g_key_temp = None
    # 先找到合并到哪个图
    for g_key in all_graphs.keys():
        if key2 in g_key.split("-"):
            g_key_temp = g_key
            break
    if g_key_temp != None:
        g = all_graphs[g_key_temp]
        all_graphs[g_key_temp] = g.mergeGraph(key, feature_matrix[key], [temp[0], temp[1], temp[2]], [key2])



# (3)融合高组之间的流量

# 1）先融合包含组和前缀组
for key1 in include_group_res.keys():
    key2 = include_group_res[key1][0]
    # 开始融合
    high_group[key2].extend(high_group[key1])
    high_group.pop(key1)

# 2)融合前缀节点




# 开始融合
for temp in prefixGroups:
    key = temp[0]
    index = 1
    while index < len(temp):
        high_group[key].extend(high_group[temp[index]])
        high_group.pop(temp[index])
        index+=1

# 临时 计算准确度

data_group = copy.deepcopy(high_group)
res = FMI(data_group)


# ***********************************************************************************


# 9.匹配低组和高组数据
# (1)获取低组特征
low_feature_matrix = featureMatrix.extractCoreFeatureMatrix(low_group)



# (2)将低组和高组匹配
low_match_res = {}
for key1 in low_feature_matrix.keys():
    temp = []
    matrix = low_feature_matrix[key1]["core_feature_matrix"]
    features = low_feature_matrix[key1]["features"]
    for key2 in all_graphs.keys():
        g = all_graphs[key2]
        t = featureGraph.matchFeatureAndGraph(g, matrix, features)
        temp.append(t)
    low_match_res[key1] = temp
    
# (3)筛选出有效的组和无效的组
vaild_low_group = {}
invaild_low_group = {}


def __isMatchVaild(matchres):
    # 有效的条件 只有一个匹配结果明显大于其他的
    r = 0
    count = 0
    index  =-1
    for i in range(len(matchres)):
        t = matchres[i]
        if t> r:
            r =t
            count = 0
            index = i
        elif t == r:
            count +=1
    if r ==0 or count>0:
        return -1
    return index


for key in low_match_res.keys():
    t =__isMatchVaild(low_match_res[key]) 
    if t == -1:
        invaild_low_group[key] = t
    else:
        vaild_low_group[key] = t
    
        
# (4)确认序号对应的组
all_graph_keys = list(all_graphs.keys())
index = 0
rel_index_to_group = {}
for key1 in all_graph_keys:
    for key2 in high_group.keys():
        if key2 in key1.split("-"):
            rel_index_to_group[index] = key2
            index+=1
            break
    

# (5)将有效的组合并到特定组
for key1 in vaild_low_group.keys():
    key2 = rel_index_to_group[vaild_low_group[key1]]
    high_group[key2].extend(low_group[key1])
    low_group.pop(key1)





# 10.处理未和高组匹配上的低组

# (1)将低组前缀和高组匹配
low_prefix_match = {}
for key1 in invaild_low_group.keys():
    temp = []
    matrix = low_feature_matrix[key1]["core_feature_matrix"]
    features = low_feature_matrix[key1]["features"]
    for key2 in all_graphs.keys():
        g = all_graphs[key2]
        t = featureGraph.matchSubPrefixToMain(g, matrix, features)
        temp.append(t)
    low_prefix_match[key1] = temp

# (2)筛选匹配成功的组和匹配失败的组
vaild_low_group = {}
invaild_low_group = {}

for key in low_prefix_match.keys():
    t =__isMatchVaild(low_prefix_match[key]) 
    if t == -1:
        invaild_low_group[key] = t
    else:
        vaild_low_group[key] = t
# (3)将有效的组合并到高组
for key1 in vaild_low_group.keys():
    key2 = rel_index_to_group[vaild_low_group[key1]]
    high_group[key2].extend(low_group[key1])
    low_group.pop(key1)    









# (4)提取每两个低组之间的最长前缀特征
low_prefix_groups = {}
index1 = 0
keys = list(invaild_low_group.keys())
while index1 < len(keys):
    
    key1 = keys[index1]
    index2 = 0
    low_prefix_groups[key1] = {}
    matrix1 = low_feature_matrix[key1]["core_feature_matrix"]
    features1 = low_feature_matrix[key1]["features"]
    while index2< len(invaild_low_group.keys()):
        if index1 == index2:
            index2 +=1
            continue
        key2 = keys[index2]
        matrix2 = low_feature_matrix[key2]["core_feature_matrix"]
        features2 = low_feature_matrix[key2]["features"]
        temp = mergeFeatureMatrix.extractMaxSimFeaturePrefix(matrix1, matrix2, features1, features2)
        if len(temp) !=0:
            low_prefix_groups[key1][key2] = len(temp)
        index2 += 1
    index1 += 1


# (5)每个组筛选出最长相同前缀组合
low_prefix_max_group = {}
for key1 in low_prefix_groups.keys():
    # 先筛选出最大长度
    temp = []
    for key2 in low_prefix_groups[key1].keys():
        temp.append(low_prefix_groups[key1][key2])
    if len(temp) != 0:
        max_length = max(temp)
        max_key = [k for k,v in low_prefix_groups[key1].items() if v == max_length]
        low_prefix_max_group[key1] = [key1]
        low_prefix_max_group[key1].extend(max_key)
    else:
        low_prefix_max_group[key1]  = []

# (6)提取相同前缀的形成新的组
low_new_group = []
low_no_group = []
for key in low_prefix_max_group.keys():
    temp = low_prefix_max_group[key]
    if len(temp) == 0:
        low_no_group.append(key)
    else:
        temp.sort()
        if temp not in low_new_group:
            low_new_group.append(temp)
# 去除子集
low_new_group.sort(key = lambda t:len(t))
i = 0
while i < len(low_new_group):
    j = i+1
    while j < len(low_new_group):
        if set(low_new_group[i]).issubset(set(low_new_group[j])):
            low_new_group[i] = []
            break
        j +=1
    i +=1

while [] in low_new_group:
    low_new_group.remove([])    


# 形成新组
index= 0
for temp in low_new_group:
    # 获取一个随机key
    while True:
        if str(index) not in low_group.keys():
            break
        else:
            index +=1
    res = []
    for t in temp:
        res.extend(low_group[t])
        low_group.pop(t)
    low_group[str(index)] = res

# 未匹配的合并到一个组
other_group = []
for t in low_no_group:
    other_group.extend(low_group[t])
    low_group.pop(t)
    

# 11.形成最终分组
index = 1
final_res_group = {}
# (1)先融合高组
for key in high_group.keys():
    final_res_group[str(index)] = high_group[key]
    index +=1
# (2)在融合低组
for key in low_group.keys():
    final_res_group[str(index)] = low_group[key]
    index +=1
# (3)最后融合未匹配组
final_res_group[str(index)] = other_group

data_group = final_res_group
res = FMI(data_group)

# *****************************************************************************************




"""
# !!
merge_include_to_prefix_res = analyzeGroupRel.getMergeRelBetweenIncludeAndPrefix(coreRel=high_include_sub, prefixGroups=prefixGroups)

# 将在包含关系中 在前缀关系中的节点移除
for key1 in merge_include_to_prefix_res.keys():
    # 先判断其是否在前缀图中
    for temp1 in high_max_prefix_res:
        temp2 = temp1[0][0]
        if key1 in temp2:
            for t in temp1:
                if key1 in t[0]:
                    t[0].remove(key1)
            break

prefix_rels = []
for temp1 in high_max_prefix_res:
    temp = []
    for temp2 in temp1:
        if len(temp2[0]) != 0:
            temp.append(temp2)
    if len(temp) != 0:
        prefix_rels.append(temp)



# (9)最终获取三种关系
# (1)单图 即一个组形成一个图 此时将全部节点置为次核心节点;
# (2)前缀图 按照一定规则生成;
# (3)包含图 将图合并到前缀图中

# 首先获取在前缀图中的节点
rel_nodes = []
for temp1 in prefix_rels:
    for temp2 in temp1:
        rel_nodes.extend(temp2[0])

# 获取在关系图中的节点
rel_nodes.extend(list(merge_include_to_prefix_res.keys()))
# 去重
rel_nodes = list(set(rel_nodes))

# 找到单图节点
single_nodes = []
# 所有节点
all_nodes=  list(high_group.keys())
for n in all_nodes:
    if n not in rel_nodes:
        single_nodes.append(n)


# 确认包含关系具体合并到哪个节点的哪个位置
index = 1
prefix_flags = {}
for temp in prefixGroups:
    prefix_flags[str(index)] = temp
    index +=1


# 为每个组确认位置最靠前且包含内容最长的


# 8.开始创建各种图
all_graph = {
    "single_graph":{},
    "graphs":{}
    }
# (1)创建单图
for key in single_nodes:
    # 创建图
    g = featureGraph.initFeatureGraph(key, matrix = high_feature_matrix[key]["core_feature_matrix"], features=high_feature_matrix[key]["features"], core_right_index=0)
    # 修改图解节点类型全部为次核心节点
    featureGraph.updateNodeAttr(g,None,"ntype","secore")
    all_graph["single_graph"][key] = g

# (2)创建前缀图
# 先按照前缀特征数量倒序排序
for temp in prefix_rels:
    temp.sort(key = lambda t : t[1], reverse=True)
    
    
    
# 开始创建前缀图
for temp1 in prefix_rels:
    # 存储已经处理过的节点
    over_nodes= []
    # 先创建新图
    temp2 = temp[0]
    key = temp2[0][0]
    m = temp2[1]
    # 创建图
    g = featureGraph.initFeatureGraph(key, matrix = high_feature_matrix[key]["core_feature_matrix"], features=high_feature_matrix[key]["features"], core_right_index=m)
    # 将该节点加入到已经处理过的节点当中
    over_nodes.append(key)
    # 开始循环添加边
    for temp2 in temp1:
        m = temp2[1]
        for key in temp2[0]:
            if key in over_nodes:
                continue
            g = featureGraph.addOneFeatureToGraph(g, key, high_feature_matrix[key]["core_feature_matrix"], high_feature_matrix[key]["features"], 0, m, over_nodes)
            over_nodes.append(key)
    all_graph["graphs"]["-".join(over_nodes)] = g


# (3)融合包含特征图
for key in include_rels:
    temp = include_rels[key]
    # 找到其要融合的图
    g = None
    temp_key2= ""
    for key2 in all_graph["graphs"].keys():
        if temp[0] in key2.split("-"):
            g = all_graph["graphs"][key2]
            temp_key2 = key2
            break
    # 融合图
    g = featureGraph.addOneFeatureToGraph(g, key, high_feature_matrix[key]["core_feature_matrix"], high_feature_matrix[key]["features"], temp[1], temp[1]+len(temp[2])-1, [temp[0]])
    all_graph["graphs"][key2] = g

"""
    