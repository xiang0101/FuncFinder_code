"""
@Type doc
@Author xjp
@CreateDate 2025-06-02_14:49:25
@Description 使用其他聚类算法计算结果 
@Version 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import sys
sys.path.append("../")
from mytools import myFile, groupFlow, mergeFlow, groupFlow2, featureMatrix, mergeFeatureMatrix, featureGraph, analyzeGroupRel, calcSim

import numpy as np
from collections import Counter
import random
import copy
import os

import shutil

from result.evaluation import FMI,ARI
from typing import List
#import numpy as np
import math

from cluster import kmean_seq,OPTICS,spectral,dbscan_seq,gmm_seq,hierarchical_seq

rootPath = "E:/doctor/小论文/流量分析/实验/new_method/dataset/res/SS/"
#name = "gitlab1"
#name = "mysql3"
#name = "postgres3"
#name = "filecodebox"
#name = "es1"
#name = "redis1"
#name = "o2oa_admin_4"
name = "o2oa_user_4"


inputPath = rootPath + name + ".json"

outputPath = "./res/" + name + "_mine.json"

# 1.读取数据 myFile.py
data = myFile.loadJson(inputPath)




# 2.基本分组数据 groupFlow.py
group = groupFlow.GroupFlow()

# (1)按照ip分组数据
data_ip = group.groupByIp(data)

# (2).按照端口对划分数据
data_port = []
for data_temp in data_ip:
    data_port_temp = group.groupByPort(data_temp)
    data_port.extend(data_port_temp)
data_ip = None    


# (3).按照时间间隔分割数据
data_time = []
for flows in data_port:
    data_time.extend(group.groupByTimeInterval(flows,10))
data_port = None
#data_temp = []
#for flows in data_time:
    #data_temp.extend(flows)

#data_time = data_temp
# 3.对于每对端口对,再按照时间分组
"""
data_time = []
for flows in data:
    data_time.extend(group.groupByTimeInterval(flows))
data = data_time
"""


# 3.合并相反方向的流量 mergeFlow.py
data_dual = []
for flows in data_time:
    data_dual.append(mergeFlow.mergeDualFlow(flows))
    
      
    
# 4.合并连续的流量 mergeFlow.py
data_same = []
for flows in data_dual:
    data_same.append(mergeFlow.mergeSameFlow(flows))

data_group = data_same

#data_res = kmean_seq.kmean(data_group)
#data_res = OPTICS.optics(data_group)
#data_res = spectral.sc(data_group)
#data_res = dbscan_seq.dbscan(data_group)
#data_res = gmm_seq.gmm(data_group)
data_res = hierarchical_seq.hierarchical(data_group)
    
# 包装数据
data_final = {}
for key in data_res.keys():
    data_final[key] = [[]]
    for d in data_res[key]:
        t = {"label":d,"direction":"s","count":0}
        data_final[key][0].append(t)
    

res_ARI = ARI(data_final)
res_FMI = FMI(data_final)
print(f"ARI:{res_ARI},FMI:{res_FMI}")