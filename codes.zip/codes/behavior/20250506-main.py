"""
@Type doc
@Author xjp
@CreateDate 2025-04-14_23:17:47
@Description 算法主程序
@Version v3.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""


#from evaluation import FMI

# data_group = data_temp
#res = FMI(data_group)
import sys
sys.path.append("../")
from mytools import myFile, groupFlow, mergeFlow, groupFlow2, featureMatrix, mergeFeatureMatrix, featureGraph, analyzeGroupRel, calcSim

import numpy as np
from collections import Counter
import random
import copy
import os

import shutil

from result.evaluation import FMI,ARI
from typing import List
#import numpy as np
import math

rootPath = "E:/doctor/小论文/流量分析/实验/new_method/dataset/res/SS/"
#name = "gitlab1"
#name = "mysql3"
#name = "postgres3"
name = "o2oa_user_2"
#name = "o2oa_admin_4"
#name = "filecodebox"
#name = "es1"
#name = "redis1"


inputPath = rootPath + name + ".json"

outputPath = "./res/" + name + "_mine.json"





# 1.读取数据 myFile.py
data = myFile.loadJson(inputPath)

t = "E:/doctor/小论文/流量分析/实验/new_method/dataset/res/MS/mysql1+mysql3.json"
data = myFile.loadJson(t)

#for flow in data:
    #flow["label"] = flow["label"].replace("mysql3","mysql")

# 2.基本分组数据 groupFlow.py
group = groupFlow.GroupFlow()

# (1)按照ip分组数据
data_ip = group.groupByIp(data)

# (2).按照端口对划分数据
data_port = []
for data_temp in data_ip:
    data_port_temp = group.groupByPort(data_temp)
    data_port.extend(data_port_temp)
data_ip = None    


# (3).按照时间间隔分割数据
data_time = []
for flows in data_port:
    data_time.extend(group.groupByTimeInterval(flows,10))
data_port = None
#data_temp = []



# 3.合并相反方向的流量 mergeFlow.py
data_dual = []
for flows in data_time:
    data_dual.append(mergeFlow.mergeDualFlow(flows))
    
      
    
# 4.合并连续的流量 mergeFlow.py
data_same = []
for flows in data_dual:
    data_same.append(mergeFlow.mergeSameFlow(flows))
#data = data_same


# 清除干扰数据(没有payload的流量数据)和流量序列中流量数量小于一定数值的数据

# 后续要考虑一些是否要清除
data_temp = []
for d in data_same:
    if len(d) <=1:
        continue
    flag = False
    # 先判断是否有payload
    for flow in d:
        if flow["payload_type"] != "none":
            flag  =True
            break
    if flag:
        data_temp.append(d)

data_same = data_temp






# 临时加入 还原流量
def __restoreFlow(flows):
    res = []
    for flow in flows:
        if flow["direction"] == "d":
            f1 = copy.deepcopy(flow)
            f2 = copy.deepcopy(flow)
            f2["sip"] = f1["dip"]
            f2["dip"] = f1["sip"]
            f2["sport"] = f1["dport"]
            f2["dport"] = f1["sport"]
            f2["time"] = f1["time_last"]
            f1["time_last"] = f1["time"]
            f2["time_last"] = f2["time"]
            f1["direction"] = "s"
            f2["direction"] = "s"
            res.append(f1)
            res.append(f2)
        else:
            res.append(flow)
    return res


for i in range(len(data_same)):
    data_same[i] = __restoreFlow(data_same[i])

# 5.按照特征分组数据
#data_feature = group.groupByFeatures3                                                                                                                                                            (data_same)
#data_feature = group.groupByFeatures2(data_same)

group2 = groupFlow2.GroupFlow2()
data_feature = group2.groupByFeatures                                                                                                                                                            (data_same)



# 划分高组和低组




# 获取每个组的长度
#group_length = [len(v) for k,v in data_feature.items()]
#mean = math.ceil(np.mean(group_length))

# 划分低组和高组
low_group = {}
high_group = {}
for key in data_feature.keys():
    #if len(data_feature[key]) <=mean:
    if len(data_feature[key]) <=10:
        low_group[key] = copy.deepcopy(data_feature[key])
    else:
        high_group[key] = copy.deepcopy(data_feature[key])

# 临时按照端口对将高组和低组划分为多个组
high_group1 = {} # 3306
high_group2 = {} # 5432
for key in high_group.keys():
    temp = high_group[key][0][0]
    if temp["sport"] == "3306" or temp["dport"] == "3306":
        high_group1[key] = copy.deepcopy(high_group[key])
    else:
        high_group2[key] = copy.deepcopy(high_group[key])

low_group1 = {} # 3306
low_group2 = {} # 5432
for key in low_group.keys():
    temp = low_group[key][0][0]
    if temp["sport"] == "3306" or temp["dport"] == "3306":
        low_group1[key] = copy.deepcopy(low_group[key])
    else:
        low_group2[key] = copy.deepcopy(low_group[key])


high_group = high_group2
low_group = low_group2


# 合并组
flag = 1

for k in low_group.keys():
    key = str((-1)*flag)
    high_group[key] = low_group[k]
    flag +=1



#for key in high_group.keys():
    #data_group[key] = high_group[key]


data_group = copy.deepcopy(high_group)

res_FMI = FMI(data_group)
res_ARI = ARI(data_group)
print(f"FMI:{res_FMI},ARI:{res_ARI}")

#------------------------------------ 时间计算 -------------------------------------------------------
# 6.查看高组之间是否存在时间顺序合并的关系

# 计算每两个组之间的时间关系
# 编码高组,给每条流量序列一个特定编号
"""
high_group_flag = {}

for key in high_group.keys():
    index = 0
    high_group_flag[key] = {}
    for flows in high_group[key]:
        high_group_flag[key][str(index)] = flows
        index +=1


def calcTimeRelations(flows_dict1, flows_dict2):
    time_list = []
    
    for key in flows_dict1:
        flows = flows_dict1[key]
        temp = [flows[-1]["time"],'A',key]
        time_list.append(temp)

    for key in flows_dict2:
        flows = flows_dict2[key]
        temp = [flows[0]["time"],'B',key]
        time_list.append(temp)

    

    time_list.sort(key=lambda t : float(t[0]))
    # 统计A后面紧接着B且时间间隔不超过一定阈值的次数
    res  = []
    index = 0
    while index+1 < len(time_list):
        if time_list[index][1] == "A":
            if time_list[index+1][1] == "B":
                if (float(time_list[index+1][0])-float(time_list[index][0])) < 10:
                    res.append([time_list[index],time_list[index+1]])
                    index +=1
        index +=1 
    return res


time_res  ={}
for key1 in high_group_flag.keys():
    print(key1)
    time_res[key1] = {}
    for key2 in high_group_flag.keys():
        if key1 == key2:
            continue
        time_res[key1][key2] = calcTimeRelations(high_group_flag[key1], high_group_flag[key2])



# 计算所有的合并有效性
merge_res = {}
for key1 in time_res.keys():
    merge_res[key1] = {}
    for key2 in time_res[key1].keys():
        if len(time_res[key1][key2]) == 0:
            continue
        merge_res[key1][key2] = []        
        for g in time_res[key1][key2]:
            # 先取出流量序列
            flows1 = high_group_flag[key1][g[0][2]]
            flows2 = high_group_flag[key2][g[1][2]]
            # 过滤端口
            ports = [flows1[0]["sport"],flows1[0]["dport"],flows2[0]["sport"],flows2[0]["dport"]]
            ports = list(set(ports))
            if len(ports) == 2:
                merge_res[key1][key2].append([g[0][2],g[1][2],float(g[1][0])])

# 保留有效项
merge_res_temp = {}
for key1 in merge_res.keys():
    for key2 in merge_res[key1].keys():
        count = len(merge_res[key1][key2])
        if count == 0:
            continue
        total1 = len(high_group_flag[key1].keys())
        total2 = len(high_group_flag[key2].keys())
        if count >= total1*0.3 or count >= total2*0.3:
            if key1 not in merge_res_temp.keys():
                merge_res_temp[key1] = {}
            merge_res_temp[key1][key2] = merge_res[key1][key2]
merge_res = merge_res_temp

# 对于有冲突的项,保留时间靠前的项
def solveConflicts(data:dict)->dict:
    if len(data.keys()) == 1:
        return data
    # 获取每一个流量可以合并的集合
    data_temp = {}
    for key in data.keys():
        for temp in data[key]:
            if temp[0] not in data_temp.keys():
                data_temp[temp[0]] = {}
            data_temp[temp[0]][key] = temp
    data_res = {}
    for key1 in data_temp.keys():
        if len(data_temp[key1].keys()) == 1:
            data_res[key1] = data_temp[key1]
        else:
            max_key = ""
            min_value = 0
            for key2 in data_temp[key1].keys():
                temp = data_temp[key1][key2]
                if max_key == "":
                    max_key = key2
                    min_value = temp[2]
                elif temp[2] < min_value:
                    max_key = key2
                    min_value = temp[2]
            data_res[key1] = {}
            data_res[key1][max_key] = data_temp[key1][max_key]
    # 还原结果
    res = {}
    for key1 in data_res.keys():
        for key2 in data_res[key1].keys():
            if key2 not in res.keys():
                res[key2] = []
            res[key2].append(data_res[key1][key2])

    return res

# 解决冲突
merge_res_temp = {}
for key in merge_res.keys():
    merge_res_temp[key] = solveConflicts(merge_res[key])

merge_res = merge_res_temp

import networkx as nx
# 创建有向无环图
G = nx.DiGraph()
edges = []
for key1 in merge_res.keys():
    for key2 in merge_res[key1].keys():
        edges.append((key1,key2))
G.add_edges_from(edges)

try:
    topological_order = list(nx.topological_sort(G))
except Exception as e:
    print(e)

# 根据拓扑排序结果合并数据
def mergeDataBySort(group_flag, sort_res, relations):
    group_flag_temp = copy.deepcopy(group_flag)
    for key1 in sort_res:
        if key1 not in relations.keys():
            continue
        for key2 in relations[key1].keys():
            for temp in relations[key1][key2]:
                flows1 = group_flag_temp[key1][temp[0]]
                flows2 = group_flag_temp[key2][temp[1]]
                flows1.extend(flows2)
                group_flag_temp[key2][temp[1]] = flows1
                group_flag_temp[key1].pop(temp[0])
    return group_flag_temp

high_group_flag_temp =mergeDataBySort(high_group_flag, topological_order, merge_res)
high_group = {}
for key1 in high_group_flag_temp.keys():
    if len(high_group_flag_temp[key1].keys()) ==0:
        continue
    temp = []
    for key2 in high_group_flag_temp[key1].keys():
        temp.append(high_group_flag_temp[key1][key2])
    high_group[key1] = temp

#  打混所有的组重新分组
all_group = []
for key in high_group.keys():
    for temp in high_group[key]:
        all_group.append(temp)
for key in low_group.keys():
    for temp in low_group[key]:
        all_group.append(temp)

data_feature = group2.groupByFeatures                                                                                                                                                            (all_group)

"""

# ---------------------------------------------------------------------------------------
# 7.尝试按照包含关系合并高组

# (1)先提取特征矩阵和特征
high_feature_matrix = featureMatrix.extractCoreFeatureMatrix(high_group)

# (2)找到每一个分组和其他分组的最大匹配前缀,即特征类型和特征全部匹配上，且是最长匹配

high_max_matrix = {}
for key1 in high_feature_matrix.keys():
    high_max_matrix[key1] = {}
    for key2 in high_feature_matrix.keys():
        if key1 == key2:
            continue
        high_max_matrix[key1][key2] = mergeFeatureMatrix.extractMaxFeaturePrefix(high_feature_matrix[key1]["core_feature_matrix"], high_feature_matrix[key2]["core_feature_matrix"], high_feature_matrix[key1]["features"], high_feature_matrix[key2]["features"])

# (3)过滤干扰项
for key1 in high_max_matrix.keys():
    keys = list(high_max_matrix[key1].keys())
    for key2 in keys:
        if len(high_max_matrix[key1][key2]) ==0:
            t = high_max_matrix[key1].pop(key2)
# 清除整体的无效项
high_max_matrix_temp = {}
for key in high_max_matrix.keys():
    if len(high_max_matrix[key].keys()) != 0:
        high_max_matrix_temp[key] = high_max_matrix[key]
high_max_matrix = high_max_matrix_temp
high_max_matrix_temp = None










# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

# (4)计算包含关系
high_max_include = {}
for key1 in high_feature_matrix.keys():
    high_max_include[key1] = {}
    for key2 in high_feature_matrix.keys():
        if key1 == key2:
            continue
        high_max_include[key1][key2] = mergeFeatureMatrix.extractMaxFeatureSubSeq2(high_feature_matrix[key1]["core_feature_matrix"], high_feature_matrix[key2]["core_feature_matrix"], high_feature_matrix[key1]["features"], high_feature_matrix[key2]["features"])




for key1 in high_max_include.keys():
    keys = list(high_max_include[key1].keys())
    for key2 in keys:
        if len(high_max_include[key1][key2]) ==0:
            t = high_max_include[key1].pop(key2)
# 清除整体的无效项
high_max_include_temp = {}
for key in high_max_include.keys():
    if len(high_max_include[key].keys()) != 0:
        high_max_include_temp[key] = high_max_include[key]
high_max_include = high_max_include_temp
high_max_include_temp = None











# (5)提取每个组的最长前缀组
high_max_matrix_temp = {}
for key in high_max_matrix.keys():
    high_max_matrix_temp[key] = {}
    # 先统计最大长度
    l = 0
    for key2 in high_max_matrix[key].keys():
        if len(high_max_matrix[key][key2])>l:
            l = len(high_max_matrix[key][key2])
    # 获取最大长度项
    for key2 in high_max_matrix[key].keys():
        if len(high_max_matrix[key][key2]) == l:
            high_max_matrix_temp[key][key2] = high_max_matrix[key][key2]
high_max_matrix = high_max_matrix_temp
high_max_matrix_temp = None


# 过滤特征列表
filter_feature = ["bytes"]
# 此处需要过滤一些特征长幅度为1的组(已经实现)
keys = list(high_max_matrix.keys())
for key in keys:
    
    temp = []
    for key2 in high_max_matrix[key].keys():
        flag = True
        if len(high_max_matrix[key][key2]) == 1:
            if high_max_matrix[key][key2][0] in filter_feature:
                flag = False
        if not flag:
            temp.append(key2)
    for t in temp:
        high_max_matrix[key].pop(t)
    if len(high_max_matrix[key].keys()) == 0:
        high_max_matrix.pop(key)



# (6)提取每个组可能被哪个其他组包含
high_include_sub = {}
for key1 in high_max_include.keys():
    for key2 in high_max_include[key1].keys():
        if key2 not in high_include_sub.keys():
            high_include_sub[key2] = {}
        high_include_sub[key2][key1] = high_max_include[key1][key2]
        
        
        
        
# (7) 修改方法:提取相关联的前缀组
# 1)先按照特征长度分组
prefix_group_by_length = {}
for key in high_max_matrix.keys():
    temp = [key]
    length = 0
    for key2 in high_max_matrix[key].keys():
        temp.append(key2)
        length = len(high_max_matrix[key][key2])
    if str(length) not in prefix_group_by_length.keys():
        prefix_group_by_length[str(length)] = []
    prefix_group_by_length[str(length)].append(temp)
    
    
# 2)合并有交叉的组
prefix_group_res = {}
for key in prefix_group_by_length.keys():
    prefix_group_res[key] = []
    temp1 = prefix_group_by_length[key]
    count = 0
    while count != len(temp1):
        res = []    
        for i in range(len(temp1)):
            if len(temp1[i]) == 0:
                continue
            if len(res) == 0:
                res =temp1[i]
                temp1[i] = []
                count +=1
            else:
                # 判断是否有交集,如果有则合并
                if len(set(res).intersection(set(temp1[i]))) != 0:
                    res.extend(temp1[i])
                    temp1[i] = []
                    count +=1
        res = list(set(res))
        prefix_group_res[key].append(res)
                
        
"""
# (7)提取前缀有关联的组
# 1)提取前缀关联组
high_prefix_core = {}
for key1 in high_max_matrix.keys():
    temp = [key1]
    length = 0
    for key2 in high_max_matrix[key1].keys():
        length = len(high_max_matrix[key1][key2])
        if length not in high_prefix_core.keys():
            high_prefix_core[length] = []
        temp.append(key2)
    temp.sort()
    if temp not in high_prefix_core[length]:
        high_prefix_core[length].append(temp)

# 2)寻找相关联的组和核心节点
keys = list(high_prefix_core.keys())
keys.sort()


def isSubSet(mainList:List,subList:List)->bool:
    return set(subList).issubset((set(mainList)))
    
    

# 遍历每个序列,向上寻找是否有其子集的序列,如果有则清空子集序列,最小前缀为核心节点
high_max_prefix_res = []
for key in keys:
    temp = []
    for g in high_prefix_core[key]:
        if len(g) == 0:
            continue
        temp = [(g,key)]
    
        for key2 in keys:
            if key2 <= key:
                continue
            for i in range(len(high_prefix_core[key2])):
                temp2 = high_prefix_core[key2][i]
                if len(temp2) == 0:
                    continue
                if isSubSet(temp[0][0], temp2):
                    temp.append((high_prefix_core[key2][i],key2))
                    high_prefix_core[key2][i] = []
        high_max_prefix_res.append(temp)
"""

"""
# 测试初始化图
g = featureGraph.initFeatureGraph("132", matrix = high_feature_matrix["132"]["core_feature_matrix"], features=high_feature_matrix["132"]["features"], core_right_index=10)

g = featureGraph.addOneFeatureToGraph(g, "71", high_feature_matrix["71"]["core_feature_matrix"], high_feature_matrix["71"]["features"], 0, 10, ["132"])

g = featureGraph.addOneFeatureToGraph(g, "16", high_feature_matrix["16"]["core_feature_matrix"], high_feature_matrix["16"]["features"], 0, 8, ["132","71"])

g = featureGraph.addOneFeatureToGraph(g, "93", high_feature_matrix["93"]["core_feature_matrix"], high_feature_matrix["93"]["features"], 1, 5, ["132","71","16"])



plt.rcParams["figure.dpi"] = 800
#pos = nx.spring_layout(G)
#pos = nx.kamada_kawai_layout(g)
pos = nx.circular_layout(g)
nx.draw_networkx_nodes(g, pos, node_size=100)
nx.draw_networkx_edges(g, pos)

# 显示图形
plt.title("test")
plt.axis("off")
plt.show()
"""








"""
# 3)生成前缀特征图
import networkx as nx
import matplotlib.pyplot as plt
prefix_graphs = {}
for key in high_max_prefix_res.keys():
    
    for temp in high_max_prefix_res[key]:
        g_index = 1
        # 创建图
        g = nx.DiGraph()
        # 拼接key
        core_key = "-".join(temp)
        edge_index = 1
        # 随机获取一个特征矩阵,生成核心节点
        for t in temp:
            m = high_feature_matrix[t]["core_feature_matrix"]
            # 生成核心
            index = 0
            while index < key:
                g.add_node(g_index, importance = [core_key], ntype = m[index],features= [])
                g_index +=1
                index +=1
            
            # 添加核心节点之间的边
            while edge_index<g_index-1:
                g.add_edge(edge_index,edge_index+1,etype="core",egroup="")
                edge_index +=1
            break
            # 如此edge_index就变成核心节点的最后一个节点
        # 开始添加其他节点和边
        for t in temp:
            m = high_feature_matrix[t]["core_feature_matrix"]
            # 从这个位置开始加入节点
            index = key
            # 所有节点标志,用于添加边
            nodes = []
            while index <len(m):
                g.add_node(g_index, importance = [t], ntype = m[index],features = [])
                nodes.append(g_index)
                g_index +=1
                index +=1
                
            if len(nodes)!=0:
                # 添加核心节点的最后一个节点到分支的节点
                g.add_edge(edge_index,nodes[0],etype="no",egroup=[t])
                # 添加边
                for i in range(len(nodes)-1):
                    g.add_edge(nodes[i],nodes[i+1],etype="no",egroup=[t])
        prefix_graphs[core_key] = g
                

G = prefix_graphs["r"]
plt.rcParams["figure.dpi"] = 800
# pos = nx.spring_layout(G)
pos = nx.kamada_kawai_layout(G)
nx.draw_networkx_nodes(G, pos)
nx.draw_networkx_edges(G, pos)

# 显示图形
plt.title("test")
plt.axis("off")
plt.show()


"""

# (8)过滤包含关系
# 先获取各个分组包含的内容
# 1)先给已经分好其中前缀组的一个标志

# 将所欲有交集的组合并为一个组
prefix_group_res_temp = copy.deepcopy(prefix_group_res)
prefixGroups = []
for key in prefix_group_res_temp.keys():
    temp1 = prefix_group_res_temp[key]
    for temp2 in temp1:
        flag = False
        for i in range(len(prefixGroups)):
            temp = prefixGroups[i]
            if set(temp).intersection(set(temp2)):
                temp.extend(temp2)
                prefixGroups[i] = temp
                flag = True
                break
        if not flag:
            prefixGroups.append(temp2)
for i in range(len(prefixGroups)):
    prefixGroups[i] = list(set(prefixGroups[i]))



# 各个部分的节点
single_nodes = []
prefix_nodes = []
incluid_nodes = []

# 获取所有前缀节点
for temp in prefixGroups:
    prefix_nodes.extend(temp)

# 找到单图节点
# 所有节点
all_nodes=  list(high_group.keys())
for n in all_nodes:
    if n not in prefix_nodes:
        single_nodes.append(n)

# 获得所有包含节点
include_nodes = list(high_include_sub.keys())




# 2)给节点分组
include_final_group = analyzeGroupRel.getIncludeRel(high_include_sub, prefixGroups, single_nodes)

# --------------此处临时手动处理一下------------------------
merge_include_final = {}
keys = list(high_include_sub.keys())
key0 = keys[0]
keys = keys[1:]
merge_include_final[key0] = [key0,[1,3,1]]
for key in keys:
    merge_include_final[key] = [key0,[[1,3,1]]]


# 3)获取包含关系的最终合并方案
merge_include_final = {}
for key in include_final_group[0].keys():
    merge_include_final[key] = [include_final_group[0][key],high_include_sub[key][include_final_group[0][key]]]



# ************************************************************************************************

# 8.构建特征图

# (1)理清图生成顺序

# 1)包含节点图
include_nodes = list(merge_include_final.keys())


# 2)前缀节点图
prefix_nodes = []
for temp in prefixGroups:
    prefix_nodes.extend(temp)
prefix_nodes_temp = []
for p in prefix_nodes:
    if p not in include_nodes:
        prefix_nodes_temp.append(p)
prefix_nodes = prefix_nodes_temp

# 3)单节点图
single_nodes = []
all_nodes = list(high_group.keys())
for a in all_nodes:
    if a not in include_nodes and a not in prefix_nodes:
        single_nodes.append(a)




# (2)开始创建图
# 存储所有图的结构
all_graphs = {}

# 1)创建单节点图
for key in single_nodes:
    g = featureGraph.initFeatureGraph(key, matrix = high_feature_matrix[key]["core_feature_matrix"], features=high_feature_matrix[key]["features"], core_right_index=0)
    all_graphs[key] = g


# 2)创建前缀节点图
prefix_rels = copy.deepcopy(prefix_group_res)
# 过滤掉不在前缀图中的节点
prefix_rels_temp = {}
for key in prefix_rels.keys():
    temp1 = []
    for rels in prefix_rels[key]:
        temp2 = []
        for t in rels:
            if t in prefix_nodes:
                temp2.append(t)
        if len(temp2) != 0:
            temp1.append(temp2)
    if len(temp1) != 0:
        prefix_rels_temp[key] = temp1
prefix_rels = prefix_rels_temp

prefix_keys = list(prefix_rels.keys())

prefix_keys.sort(key = lambda t : int(t), reverse=True)

over_nodes= []
for key in prefix_keys:
    for temp in prefix_rels[key]:
        g = None
        s_key = ""
        # 先查找是否有合并标准
        for key2 in all_graphs.keys():
            if bool(set(temp).intersection(set(key2.split("-")))):
                s_key = key2
                g = all_graphs[key2]
                break
        # 需要创建新图
        temp_nodes = []
        if g == None:
            # 存储已经处理过的节点
            key2 = temp[0]
            # 创建图
            g = featureGraph.initFeatureGraph(key2, matrix = high_feature_matrix[key2]["core_feature_matrix"], features=high_feature_matrix[key2]["features"], core_right_index=int(key))
            over_nodes.append(key2)
            temp_nodes.append(key2)
        # 循环添加其他节点
        for t in temp:
            if t in over_nodes:
                continue
            g = featureGraph.addOneToGraphByLoc(g, t, high_feature_matrix[t]["core_feature_matrix"], high_feature_matrix[t]["features"], 0, int(key), 0, temp)
            over_nodes.append(t)
            temp_nodes.append(t)
        if s_key == "":
            all_graphs["-".join(temp_nodes)] = g
        else:
            t = s_key.split("-")
            t.extend(temp_nodes)
            t = list(set(t))
            all_graphs["-".join(t)] = g
            all_graphs.pop(s_key)
    

    
# 开始创建前缀图

    

# 3)创建包含节点图
for key in merge_include_final.keys():
    # 合并到的节点key
    key2 = merge_include_final[key][0]
    if key == key2:
        continue
    # 合并信息
    temp = merge_include_final[key][1][0]
    g = None
    # 先找到合并到哪个图
    for g_key in all_graphs.keys():
        if key2 in g_key.split("-"):
            g =all_graphs[g_key]
            break
    if g != None:
        g = featureGraph.addOneToGraphByLoc(g, key, high_feature_matrix[key]["core_feature_matrix"], high_feature_matrix[key]["features"], temp[0], temp[1], temp[2], [key2])
    else:
        # 先创建图,再融合图
        g = featureGraph.initFeatureGraph(key2, matrix = high_feature_matrix[key2]["core_feature_matrix"], features=high_feature_matrix[key2]["features"], core_right_index=0)
        all_graphs[key2] = g
        g = featureGraph.addOneToGraphByLoc(g, key, high_feature_matrix[key]["core_feature_matrix"], high_feature_matrix[key]["features"], temp[0], temp[1], temp[2], [key2])
        all_graphs[key2] = g



# (3)融合高组之间的流量

# 1）先融合包含组和前缀组
for key1 in merge_include_final.keys():
    key2 = merge_include_final[key1][0]
    if key1 == key2:
        continue
    # 开始融合
    high_group[key2].extend(high_group[key1])
    high_group.pop(key1)

#high_group["8"].extend(high_group["6"])
# t =high_group.pop("6")


# 2)融合前缀节点

"""
# 测试
data_temp = {}
for temp in prefixGroups:
    key = temp[0]
    data_temp[key] = high_group[key]
    index = 1
    while index < len(temp):
        data_temp[key].extend(high_group[temp[index]])
        index+=1

"""


# !!! 此处需要注意融合冲突
# 开始融合
for temp in prefixGroups:
    t = 0
    key = temp[t]
    
    while key not in high_group.keys():
        t +=1
        key = temp[t]
    index = 1
    while index < len(temp):
        if temp[index] in high_group.keys():
            high_group[key].extend(high_group[temp[index]])
            high_group.pop(temp[index])
        index+=1

# 临时 计算准确度


data_group2 = copy.deepcopy(high_group)
res_FMI = FMI(data_group2)
res_ARI = ARI(data_group2)
print(f"FMI:{res_FMI},ARI:{res_ARI}")

# ***********************************************************************************

low_group_temp = copy.deepcopy(low_group)
high_group_temp = copy.deepcopy(high_group)

high_group = copy.deepcopy(high_group_temp)
low_group = copy.deepcopy(low_group_temp)

# 9.匹配低组和高组数据
# (1)获取低组特征
low_feature_matrix = featureMatrix.extractCoreFeatureMatrix(low_group)



# (2)将低组和高组匹配(有问题)
low_match_res = {}
for key1 in low_feature_matrix.keys():
    temp = []
    matrix = low_feature_matrix[key1]["core_feature_matrix"]
    features = low_feature_matrix[key1]["features"]
    for key2 in all_graphs.keys():
        g = all_graphs[key2]
        t = featureGraph.matchFeatureAndGraph(g, matrix, features)
        temp.append(t)
    low_match_res[key1] = temp
    
# (3)筛选出有效的组和无效的组
vaild_low_group = {}
invaild_low_group = {}


def __isMatchVaild(matchres):
    # 有效的条件 只有一个匹配结果明显大于其他的
    r = 0
    count = 0
    index  =-1
    for i in range(len(matchres)):
        t = matchres[i]
        if t> r:
            r =t
            count = 0
            index = i
        elif t == r:
            count +=1
    if r ==0 or count>0:
        return -1
    return index


for key in low_match_res.keys():
    t =__isMatchVaild(low_match_res[key]) 
    if t == -1:
        invaild_low_group[key] = t
    else:
        vaild_low_group[key] = t
    
        
# (4)确认序号对应的组
all_graph_keys = list(all_graphs.keys())
index = 0
rel_index_to_group = {}
for key1 in all_graph_keys:
    for key2 in high_group.keys():
        if key2 in key1.split("-"):
            rel_index_to_group[str(index)] = key2
            index+=1
            break
    

# (5)将有效的组合并到特定组
for key1 in vaild_low_group.keys():
    key2 = rel_index_to_group[str(vaild_low_group[key1])]
    high_group[key2].extend(low_group[key1])
    low_group.pop(key1)





# 10.处理未和高组匹配上的低组

# (1)将低组前缀和高组匹配
low_prefix_match = {}
for key1 in invaild_low_group.keys():
    temp = []
    matrix = low_feature_matrix[key1]["core_feature_matrix"]
    features = low_feature_matrix[key1]["features"]
    for key2 in all_graphs.keys():
        g = all_graphs[key2]
        t = featureGraph.matchSubPrefixToMain(g, matrix, features)
        temp.append(t)
    low_prefix_match[key1] = temp

# (2)筛选匹配成功的组和匹配失败的组
vaild_low_group = {}
invaild_low_group = {}

for key in low_prefix_match.keys():
    t =__isMatchVaild(low_prefix_match[key]) 
    if t == -1:
        invaild_low_group[key] = t
    else:
        vaild_low_group[key] = t
# (3)将有效的组合并到高组
for key1 in vaild_low_group.keys():
    key2 = rel_index_to_group[vaild_low_group[key1]]
    high_group[key2].extend(low_group[key1])
    low_group.pop(key1)    



# ----- 新的低组匹配高组前缀------


low_to_high_max_prefix  = {}
for key1 in low_group.keys():
    low_to_high_max_prefix[key1] = {}
    matrix1 = low_feature_matrix[key1]["core_feature_matrix"]
    features1 = low_feature_matrix[key1]["features"]
    for key2 in high_group.keys():
        matrix2 = high_feature_matrix[key2]["core_feature_matrix"]
        features2 = high_feature_matrix[key2]["features"]
        
        low_to_high_max_prefix[key1][key2] = mergeFeatureMatrix.extractMaxFeaturePrefix(matrix1, matrix2, features1, features2)
# 清理无效项

for key1 in low_to_high_max_prefix.keys():
    keys = list(low_to_high_max_prefix[key1].keys())
    for key2 in keys:
        if len(low_to_high_max_prefix[key1][key2]) ==0:
            t = low_to_high_max_prefix[key1].pop(key2)
# 清除整体的无效项
low_to_high_max_prefix_temp = {}
for key in low_to_high_max_prefix.keys():
    if len(low_to_high_max_prefix[key].keys()) != 0:
        low_to_high_max_prefix_temp[key] = low_to_high_max_prefix[key]
low_to_high_max_prefix = low_to_high_max_prefix_temp
low_to_high_max_prefix_temp = None

"""
for key in low_to_high_max_prefix.keys():
    if "16" in low_to_high_max_prefix[key].keys():
        t = low_to_high_max_prefix[key].pop("16")
"""
# 合并low_to_high
for key1 in low_to_high_max_prefix.keys():
    for key2 in low_to_high_max_prefix[key1].keys():
        high_group[key2].extend(low_group[key1])
        t = low_group.pop(key1)



# --------------------------------------



# 新加入 包含匹配!!!!!!!!!----------------
# 包含匹配每一个低组和高组

low_include_match_res = {}
for key_low in low_group.keys():
    low_include_match_res[key_low] = {}
    low_matrix = low_feature_matrix[key_low]["core_feature_matrix"]
    low_features = low_feature_matrix[key_low]["features"]
    for key_high in high_group.keys(): 
        high_matrix = high_feature_matrix[key_high]["core_feature_matrix"]
        high_features = high_feature_matrix[key_high]["features"]
        low_include_match_res[key_low][key_high] = mergeFeatureMatrix.extractMaxFeatureSubSeq2(high_matrix, low_matrix, high_features, low_features)
# 保留有效项
for key1 in low_include_match_res.keys():
    keys = list(low_include_match_res[key1].keys())
    for key2 in keys:
        if len(low_include_match_res[key1][key2]) ==0:
            t = low_include_match_res[key1].pop(key2)
# 清除整体的无效项
low_include_match_res_temp = {}
for key in low_include_match_res.keys():
    if len(low_include_match_res[key].keys()) != 0:
        low_include_match_res_temp[key] = low_include_match_res[key]
low_include_match_res = low_include_match_res_temp
low_include_match_res_temp = None

# 确认最终的合并结果
low_include_match_final_res={}
for key1 in low_include_match_res.keys():
    for key2 in low_include_match_res[key1].keys():
        if key2 in high_group.keys():
            low_include_match_final_res[key1] = [key2,low_include_match_res[key1][key2][0]]
            break

"""
for key in low_include_match_res.keys():
    if len(low_include_match_res[key].keys()) == 1:
        continue
    if "5" in low_include_match_res[key].keys():
        t = low_include_match_res[key].pop("5")
    if "16" in low_include_match_res[key].keys():
        t = low_include_match_res[key].pop("16")
"""
# 合并组并移除组
for key in low_include_match_final_res.keys():
    key2 = low_include_match_final_res[key][0]
    high_group[key2].extend(low_group[key])
    t = low_group.pop(key)

invaild_low_group = low_group

# ----------------------------------






# (4)提取每两个低组之间的最长前缀特征
low_prefix_groups = {}
index1 = 0
keys = list(invaild_low_group.keys())
while index1 < len(keys):
    print(index1)
    key1 = keys[index1]
    index2 = 0
    low_prefix_groups[key1] = {}
    matrix1 = low_feature_matrix[key1]["core_feature_matrix"]
    features1 = low_feature_matrix[key1]["features"]
    while index2< len(invaild_low_group.keys()):
        if index1 == index2:
            index2 +=1
            continue
        key2 = keys[index2]
        matrix2 = low_feature_matrix[key2]["core_feature_matrix"]
        features2 = low_feature_matrix[key2]["features"]
        temp = mergeFeatureMatrix.extractMaxSimFeaturePrefix(matrix1, matrix2, features1, features2)
        if len(temp) !=0:
            low_prefix_groups[key1][key2] = len(temp)
        index2 += 1
    index1 += 1


# (5)每个组筛选出最长相同前缀组合
low_prefix_max_group = {}
for key1 in low_prefix_groups.keys():
    # 先筛选出最大长度
    temp = []
    for key2 in low_prefix_groups[key1].keys():
        temp.append(low_prefix_groups[key1][key2])
    if len(temp) != 0:
        max_length = max(temp)
        max_key = [k for k,v in low_prefix_groups[key1].items() if v == max_length]
        low_prefix_max_group[key1] = [key1]
        low_prefix_max_group[key1].extend(max_key)
    else:
        low_prefix_max_group[key1]  = []

# (6)提取相同前缀的形成新的组
low_new_group = []
low_no_group = []
for key in low_prefix_max_group.keys():
    temp = low_prefix_max_group[key]
    if len(temp) == 0:
        low_no_group.append(key)
    else:
        temp.sort()
        if temp not in low_new_group:
            low_new_group.append(temp)
# 去除子集
low_new_group.sort(key = lambda t:len(t))
i = 0
while i < len(low_new_group):
    j = i+1
    while j < len(low_new_group):
        if set(low_new_group[i]).issubset(set(low_new_group[j])):
            low_new_group[i] = []
            break
        j +=1
    i +=1

while [] in low_new_group:
    low_new_group.remove([])    

# 合并low组
for temp in low_new_group:
    index = 1
    key = temp[0]
    while index < len(temp):
        low_group[key].extend(low_group[temp[index]])
        t = low_group.pop(temp[index])
        index +=1


"""
# 形成新组
index= 0
for temp in low_new_group:
    # 获取一个随机key
    while True:
        if str(index) not in low_group.keys():
            break
        else:
            index +=1
    res = []
    for t in temp:
        res.extend(low_group[t])
        low_group.pop(t)
    low_group[str(index)] = res
"""



# 新加入----------------------------
# 低组之间前缀匹配


low_to_low_max_prefix  = {}
for key1 in low_group.keys():
    low_to_low_max_prefix[key1] = {}
    matrix1 = low_feature_matrix[key1]["core_feature_matrix"]
    features1 = low_feature_matrix[key1]["features"]
    for key2 in low_group.keys():
        if key1 == key2:
            continue
        matrix2 = low_feature_matrix[key2]["core_feature_matrix"]
        features2 = low_feature_matrix[key2]["features"]
        
        low_to_low_max_prefix[key1][key2] = mergeFeatureMatrix.extractMaxFeaturePrefix(matrix1, matrix2, features1, features2)
# 清理无效项

for key1 in low_to_low_max_prefix.keys():
    keys = list(low_to_low_max_prefix[key1].keys())
    for key2 in keys:
        if len(low_to_low_max_prefix[key1][key2]) ==0:
            t = low_to_low_max_prefix[key1].pop(key2)
# 清除整体的无效项
low_to_low_max_prefix_temp = {}
for key in low_to_low_max_prefix.keys():
    if len(low_to_low_max_prefix[key].keys()) != 0:
        low_to_low_max_prefix_temp[key] = low_to_low_max_prefix[key]
low_to_low_max_prefix = low_to_low_max_prefix_temp
low_to_low_max_prefix_temp = None


# 确认合并项
low_to_low_max_prefix_merge = []
for key1 in low_to_low_max_prefix.keys():
    temp = [key1]
    for key2 in low_to_low_max_prefix[key1].keys():
        temp.append(key2)
    temp.sort()
    low_to_low_max_prefix_merge.append(temp)
# 清除重复项
low_to_low_max_prefix_merge_temp = set(tuple(temp) for temp in low_to_low_max_prefix_merge)

low_to_low_max_prefix_merge = [list(temp) for temp in  low_to_low_max_prefix_merge_temp]

# 合并有交叉的组
index1 = 0
index2 = 1
while index1 < len(low_to_low_max_prefix_merge)-1:
    index2 = index1 + 1
    while index2 < len(low_to_low_max_prefix_merge):
        for t in low_to_low_max_prefix_merge[index1]:
            if t in low_to_low_max_prefix_merge[index2]:
                
                # 有交集
                low_to_low_max_prefix_merge[index1].extend(low_to_low_max_prefix_merge[index2])
                low_to_low_max_prefix_merge[index2] = []
                break
        index2 +=1
    index1 +=1
    

# 清除空的并去重
low_to_low_max_prefix_merge_temp = []
for temp in low_to_low_max_prefix_merge:
    if len(temp) != 0:
        temp = list(set(temp))
        low_to_low_max_prefix_merge_temp.append(temp)
# 合并为新的组
new_group = {}
index = 1
for temp in low_to_low_max_prefix_merge_temp:
    t = []
    key = str((-1)*index)
    index +=1
    new_group[key]= []
    for k in temp:
        new_group[key].extend(low_group[k])
        s = low_group.pop(k)


# 新的组加入high_group
for key in new_group.keys():
    high_group[key] = new_group[key]

#high_group["-101"] = new_group["-2"]

# -------------------------------------



# !!!!新加入 --------------------------------------
# 低组之间包含匹配
# (可选)
#low_feature_matrix = featureMatrix.extractCoreFeatureMatrix(low_group)


low_to_low_include_match_res = {}

for key1 in low_group.keys():
    low_to_low_include_match_res[key1] = {}
    
    low_matrix1 = low_feature_matrix[key1]["core_feature_matrix"]
    low_features1 = low_feature_matrix[key1]["features"]
    for key2 in low_group.keys():
        if key1 == key2:
            continue
        low_matrix2 = low_feature_matrix[key2]["core_feature_matrix"]
        low_features2 = low_feature_matrix[key2]["features"]
        low_to_low_include_match_res[key1][key2] = mergeFeatureMatrix.extractMaxFeatureSubSeq2(low_matrix1, low_matrix2, low_features1, low_features2)
        
        
# 保留有效项
for key1 in low_to_low_include_match_res.keys():
    keys = list(low_to_low_include_match_res[key1].keys())
    for key2 in keys:
        if len(low_to_low_include_match_res[key1][key2]) ==0:
            t = low_to_low_include_match_res[key1].pop(key2)
# 清除整体的无效项
low_to_low_include_match_res_temp = {}
for key in low_to_low_include_match_res.keys():
    if len(low_to_low_include_match_res[key].keys()) != 0:
        low_to_low_include_match_res_temp[key] = low_to_low_include_match_res[key]
low_to_low_include_match_res = low_to_low_include_match_res_temp
low_to_low_include_match_res_temp = None



# 合并包含项

# es *********************

# 获取合并项
low_include_merge_res = {}
for key1 in low_to_low_include_match_res.keys():
    key_temp = str(len(list(low_to_low_include_match_res[key1].keys())))
    if key_temp not in low_include_merge_res.keys():
        low_include_merge_res[key_temp] = []
    low_include_merge_res[key_temp].append(key1)
    low_include_merge_res[key_temp].extend(list(low_to_low_include_match_res[key1].keys()))

for key in low_include_merge_res.keys():
    low_include_merge_res[key] = list(set(low_include_merge_res[key]))

# 合并低组
new_group = {}
index = 1
for key1 in low_include_merge_res.keys():
    temp = str((-1)*index)
    new_group[temp] = []
    for key2 in low_include_merge_res[key1]:
        if key2 not in low_group.keys():
            continue
        new_group[temp].extend(low_group[key2])
        t = low_group.pop(key2)
    index +=1




# 将新组合并到高组
for key in new_group.keys():
    high_group[key] = new_group[key]

data_group = high_group
# ************************






# 新加入模糊包含匹配*********************************

low_one_include_match_res = {}

for key1 in low_group.keys():
    low_one_include_match_res[key1] = {}
    
    low_matrix1 = low_feature_matrix[key1]["core_feature_matrix"]
    low_features1 = low_feature_matrix[key1]["features"]
    for key2 in low_group.keys():
        if key1 == key2:
            continue
        low_matrix2 = low_feature_matrix[key2]["core_feature_matrix"]
        low_features2 = low_feature_matrix[key2]["features"]
        low_one_include_match_res[key1][key2] = mergeFeatureMatrix.extractMaxFeatureSubSeq3(low_matrix1, low_matrix2, low_features1, low_features2)


# 保留有效项
for key1 in low_one_include_match_res.keys():
    keys = list(low_one_include_match_res[key1].keys())
    for key2 in keys:
        if len(low_one_include_match_res[key1][key2]) ==0:
            t = low_one_include_match_res[key1].pop(key2)
# 清除整体的无效项
low_one_include_match_res_temp = {}
for key in low_one_include_match_res.keys():
    if len(low_one_include_match_res[key].keys()) != 0:
        low_one_include_match_res_temp[key] = low_one_include_match_res[key]
low_one_include_match_res = low_one_include_match_res_temp
low_one_include_match_res_temp = None

# 先判断一项可能属于多少个组
low_one_to_groups = {}
for key1 in low_one_include_match_res.keys():
    temp_dict = {}
    for key2 in low_one_include_match_res[key1].keys():
        temp = low_one_include_match_res[key1][key2][0]
        t = "-".join(str(x) for x in temp)
        if t not in temp_dict.keys():
            temp_dict[t] = []
        temp_dict[t].append(key2)
    low_one_to_groups[key1] = []
    for t in temp_dict.keys():
        low_one_to_groups[key1].append(temp_dict[t])

# 筛选出结果为1的和结果为其他的
low_res_one = {}
low_res_other = {}
for key in low_one_to_groups.keys():
    if len(low_one_to_groups[key]) == 1:
        low_res_one[key] = low_one_to_groups[key][0]
    else:
        low_res_other[key] = low_one_to_groups[key]


# 对于有冲突的则判断特征矩阵来确认最终结果
low_res_other_final = []
for key in low_res_other.keys():
    matrix = low_feature_matrix[key]["core_feature_matrix"]
    for otherlist in low_res_other[key]:
        key2 = otherlist[0]
        matrix2 = low_feature_matrix[key2]["core_feature_matrix"]
        # 目前只判断完全相同的
        if matrix == matrix2:
            temp = [key]
            temp.extend(otherlist)
            low_res_other_final.append(temp)
            break
# 去重
for temp in low_res_other_final:
    temp.sort()
low_res_other_final = [low_res_other_final[0]]
# 其他项
low_res_one_final = []
temp = ["2"]
temp.extend(low_res_one["2"])
low_res_one_final.append(temp)

temp = ["5"]
temp.extend(low_res_one["5"])
low_res_one_final.append(temp)
temp = ["149"]
temp.extend(low_res_one["149"])
low_res_one_final.append(temp)


# 判断是否有交叉元素
for t in low_res_other_final[0]:
    if t in low_res_one_final[0]:
        print(t)
        break

# 合并组
new_group = {}
temp = str((-1)*index)
index +=1
new_group[temp] = []
for key in low_res_other_final[0]:
    new_group[temp].extend(low_group[key])
    low_group.pop(key)
    
for listo in low_res_one_final:
    temp = str((-1)*index)
    index +=1
    new_group[temp] = []
    for key in listo:
        new_group[temp].extend(low_group[key])
        low_group.pop(key)

for key in new_group.keys():
    high_group[key] = new_group[key]

data_group = high_group


"""


low_include_merge_res = {}
for key1 in low_one_include_match_res.keys():
    key_temp = str(len(list(low_one_include_match_res[key1].keys())))
    if key_temp not in low_include_merge_res.keys():
        low_include_merge_res[key_temp] = []
    low_include_merge_res[key_temp].append(key1)
    low_include_merge_res[key_temp].extend(list(low_one_include_match_res[key1].keys()))

for key in low_include_merge_res.keys():
    low_include_merge_res[key] = list(set(low_include_merge_res[key]))

# 合并低组
new_group = {}
for key1 in low_include_merge_res.keys():
    temp = str((-1)*index)
    new_group[temp] = []
    for key2 in low_include_merge_res[key1]:
        new_group[temp].extend(low_group[key2])
        t = low_group.pop(key2)
    index +=1
"""


#******************************************












# 剩下的合并到一个组
temp = []
for key in low_group.keys():
    temp.extend(low_group[key])
data_group[str((-1)*index)] = temp





# -------------------------------------------------

# filecodebox临时
high_group["0"] = []
for key in low_group.keys():
    high_group["0"].extend(low_group[key])





# 未匹配的合并到一个组
other_group = []
for t in low_no_group:
    other_group.extend(low_group[t])
    low_group.pop(t)
    

# 11.形成最终分组
index = 1
final_res_group = {}
# (1)先融合高组
for key in high_group.keys():
    final_res_group[str(index)] = high_group[key]
    index +=1
# (2)在融合低组
for key in low_group.keys():
    final_res_group[str(index)] = low_group[key]
    index +=1
# (3)最后融合未匹配组
final_res_group[str(index)] = other_group

data_group = final_res_group
res = FMI(data_group)
res_ari = ARI(data_group)

print(f"ARI:{res_ari},FMI:{res}")
# *****************************************************************************************




"""
# !!
merge_include_to_prefix_res = analyzeGroupRel.getMergeRelBetweenIncludeAndPrefix(coreRel=high_include_sub, prefixGroups=prefixGroups)

# 将在包含关系中 在前缀关系中的节点移除
for key1 in merge_include_to_prefix_res.keys():
    # 先判断其是否在前缀图中
    for temp1 in high_max_prefix_res:
        temp2 = temp1[0][0]
        if key1 in temp2:
            for t in temp1:
                if key1 in t[0]:
                    t[0].remove(key1)
            break

prefix_rels = []
for temp1 in high_max_prefix_res:
    temp = []
    for temp2 in temp1:
        if len(temp2[0]) != 0:
            temp.append(temp2)
    if len(temp) != 0:
        prefix_rels.append(temp)



# (9)最终获取三种关系
# (1)单图 即一个组形成一个图 此时将全部节点置为次核心节点;
# (2)前缀图 按照一定规则生成;
# (3)包含图 将图合并到前缀图中

# 首先获取在前缀图中的节点
rel_nodes = []
for temp1 in prefix_rels:
    for temp2 in temp1:
        rel_nodes.extend(temp2[0])

# 获取在关系图中的节点
rel_nodes.extend(list(merge_include_to_prefix_res.keys()))
# 去重
rel_nodes = list(set(rel_nodes))

# 找到单图节点
single_nodes = []
# 所有节点
all_nodes=  list(high_group.keys())
for n in all_nodes:
    if n not in rel_nodes:
        single_nodes.append(n)


# 确认包含关系具体合并到哪个节点的哪个位置
index = 1
prefix_flags = {}
for temp in prefixGroups:
    prefix_flags[str(index)] = temp
    index +=1


# 为每个组确认位置最靠前且包含内容最长的


# 8.开始创建各种图
all_graph = {
    "single_graph":{},
    "graphs":{}
    }
# (1)创建单图
for key in single_nodes:
    # 创建图
    g = featureGraph.initFeatureGraph(key, matrix = high_feature_matrix[key]["core_feature_matrix"], features=high_feature_matrix[key]["features"], core_right_index=0)
    # 修改图解节点类型全部为次核心节点
    featureGraph.updateNodeAttr(g,None,"ntype","secore")
    all_graph["single_graph"][key] = g

# (2)创建前缀图
# 先按照前缀特征数量倒序排序
for temp in prefix_rels:
    temp.sort(key = lambda t : t[1], reverse=True)
    
    
    
# 开始创建前缀图
for temp1 in prefix_rels:
    # 存储已经处理过的节点
    over_nodes= []
    # 先创建新图
    temp2 = temp[0]
    key = temp2[0][0]
    m = temp2[1]
    # 创建图
    g = featureGraph.initFeatureGraph(key, matrix = high_feature_matrix[key]["core_feature_matrix"], features=high_feature_matrix[key]["features"], core_right_index=m)
    # 将该节点加入到已经处理过的节点当中
    over_nodes.append(key)
    # 开始循环添加边
    for temp2 in temp1:
        m = temp2[1]
        for key in temp2[0]:
            if key in over_nodes:
                continue
            g = featureGraph.addOneFeatureToGraph(g, key, high_feature_matrix[key]["core_feature_matrix"], high_feature_matrix[key]["features"], 0, m, over_nodes)
            over_nodes.append(key)
    all_graph["graphs"]["-".join(over_nodes)] = g


# (3)融合包含特征图
for key in include_rels:
    temp = include_rels[key]
    # 找到其要融合的图
    g = None
    temp_key2= ""
    for key2 in all_graph["graphs"].keys():
        if temp[0] in key2.split("-"):
            g = all_graph["graphs"][key2]
            temp_key2 = key2
            break
    # 融合图
    g = featureGraph.addOneFeatureToGraph(g, key, high_feature_matrix[key]["core_feature_matrix"], high_feature_matrix[key]["features"], temp[1], temp[1]+len(temp[2])-1, [temp[0]])
    all_graph["graphs"][key2] = g

"""
    