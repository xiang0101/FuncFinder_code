"""
@Type doc
@Author xjp
@CreateDate 2025-03-31_20:15:20
@Description 生成数据集
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import json
from mixData import replaceIpSS, replaceIpSM, replaceIpMS,replaceIpMM, mixData


"""
@Type function
@Author xjp
@CreateDate 2025-03-31_20:16:58
@Description 生成单用户单应用数据集 
@Param 
@Return 
"""
def generateSS(name):
    
    inputPath = "./res/" + name + ".json"
    outputPath = "./res/SS/" + name + ".json"
    with open(inputPath,'r',encoding="utf-8") as fin:
        data = json.load(fin)
    res = replaceIpSS(data)
    with open(outputPath,'w',encoding="utf-8") as fout:
        json.dump(res,fout)

def generateSM(names):
    datas = []
    for i in range(len(names)):
        if i == 0:
            continue
        inputPath = "./res/" + names[i] + ".json"
        with open(inputPath,'r',encoding="utf-8") as fin:
            data = json.load(fin)
        datas.append(data)
    outputPath = "./res/SM/" + names[0] + ".json"
    
    datas = replaceIpSM(datas)

    res = mixData(datas)
    with open(outputPath,'w',encoding="utf-8") as fout:
        json.dump(res,fout)
        
        
def generateMS(names):
    datas = []
    for i in range(len(names)):
        if i == 0:
            continue
        inputPath = "./res/" + names[i] + ".json"
        with open(inputPath,'r',encoding="utf-8") as fin:
            data = json.load(fin)
        datas.append(data)
    outputPath = "./res/MS/" + names[0] + ".json"
    
    datas = replaceIpMS(datas)

    res = mixData(datas)
    with open(outputPath,'w',encoding="utf-8") as fout:
        json.dump(res,fout)

#name = "gitlab1"
#name = "o2oa_user_2"
#name = "postgres3"
#name = "filecodebox"
#name = "es1"
#name = "redis1"
#name = "o2oa_admin_4"
#generateSS(name)

#names = ["mysql1+mysql3","mysql1","mysql3"]
#names = ["postgres2+postgres3","postgres2","postgres3"]
#names = ["postgres3+mysql3","postgres3","mysql3"]
names = ["gitlab1+mysql3","gitlab1","mysql3"]
generateSM(names)

#generateMS(names)

#names = ["mysql2+postgres2","mysql2","postgres2"]
#generateSM(names)
