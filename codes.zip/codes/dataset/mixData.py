"""
@Type doc
@Author xjp
@CreateDate 2025-03-31_19:44:08
@Description 混合数据集(将一个或多个数据集混合在一起)
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

from typing import List





def replaceIpSS(datas:List)->List:
    userIp = __getRandomIp(1,2)[0]
    appIp = __getRandomIp(1,100)[0]
    for flow in datas:
        if flow["sip"] == "userip":
            flow["sip"] = userIp
            flow["dip"] = appIp
        else:
            flow["sip"] = appIp
            flow["dip"] = userIp
    return datas

"""
@Type function
@Author xjp
@CreateDate 2025-03-31_19:53:19
@Description 按照单用户多应用方式替换ip
@Param 
@Return 
"""
def replaceIpSM(datas:List)->List:
    userIp = __getRandomIp(1,2)[0]
    appIps = __getRandomIp(len(datas),100)
    index = 0
    for flows in datas:
        for flow in flows:
            if flow["sip"] == "userip":
                flow["sip"] = userIp
                flow["dip"] = appIps[index]
            else:
                flow["sip"] = appIps[index]
                flow["dip"] = userIp
        index +=1
    return datas

def replaceIpMS(datas:List)->List:
    userIps = __getRandomIp(len(datas),2)
    appIp = __getRandomIp(1,100)[0]
    
    index = 0
    for flows in datas:
        for flow in flows:
            if flow["sip"] == "userip":
                flow["sip"] = userIps[index]
                flow["dip"] = appIp
            else:
                flow["sip"] = appIp
                flow["dip"] = userIps[index]
        index +=1
    return datas

def replaceIpMM(datas:List)->List:
    userIps = __getRandomIp(len(datas),2)
    appIps = __getRandomIp(len(datas),100)
    index = 0
    for flows in datas:
        for flow in flows:
            if flow["sip"] == "userip":
                flow["sip"] = userIps[index]
                flow["dip"] = appIps[index]
            else:
                flow["sip"] = appIps[index]
                flow["dip"] = userIps[index]
        index +=1
    return datas

"""
@Type function
@Author xjp
@CreateDate 2025-03-31_19:56:23
@Description 随机生成一定数量的ip 
@Param 
@Return 
"""
def __getRandomIp(count:int, start:int)->List:
    prefix = "192.168.0."
    res = []
    for i in range(count):
        res.append(prefix+str(start))
        start += 1
    return res

"""
@Type function
@Author xjp
@CreateDate 2025-03-31_19:52:34
@Description 混合数据 
@Param 
@Return 
"""
def mixData(datas:List)->List:
    res = []
    for data in datas:
        data.sort(key = lambda t : float(t["time"]))
        pre_time = float(data[0]["time"])
        for flow in data:
            flow["time"] = str(float(flow["time"]) - pre_time)
            res.append(flow)
    res.sort(key = lambda t : float(t["time"]))
    return res