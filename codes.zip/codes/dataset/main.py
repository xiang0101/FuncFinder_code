"""
@Type doc
@Author xjp
@CreateDate 2025-04-07_10:18:38
@Description 处理数据集主程序
@Version v2.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""


from parseFlow import parseOnePcap
from splitData import splitMain2
import json
import copy

#name = "gitlab1"
#name = "o2oa_user_2"
name = "postgres2"
#name = "filecodebox"
#name = "es1"
#name = "redis1"
#name = "mysql1"
#name = "o2oa_admin_4"

#main_flag = "gitlab"
#main_flag="o2oa_user"
#main_flag = "postgres"
#main_flag= "filecodebox"
#main_flag = "es"
#main_flag = "redis"
#main_flag= "o2oa"
main_flag = "mysql"

inputPath = "./pcap/" + name + ".pcap"
otuputPath = "./res/" + name + ".json"





# 1.解析数据
data = parseOnePcap(inputPath)

# redis裁剪一部分数据
data = data[:14087]


# 配置项
# 替换ip列表
userIp = "userip"
appIp = "appip"
dstIp = "172.17.0.2"

# 处理es标志
for d in data:
    if d["dport"] == "10000" or d["sport"] == "10000":
        d["payload_text"] = d["payload_text"].replace("es-","")
        d["payload_text"] = d["payload_text"].replace("selectby","select")
        d["payload_text"] = d["payload_text"].replace("insertonedata","insert")
        d["payload_text"] = d["payload_text"].replace("insertmanydata","insert")

# 测试用输出分割符
t = []
for d in data:
    if d["dport"] == "10000" or d["sport"] == "10000":
        t.append(d["payload_text"])
t = list(set(t))

# 临时 按照payload类型分组数据
dict_payload = {}
for flow in data:
    key = flow["payload_type"]
    if key not in dict_payload.keys():
        dict_payload[key] = []
    dict_payload[key].append(flow)


# 替换o2oa_admin标签
for d in data:
    if d["dport"] == "10000" or d["sport"] == "10000":
        d["payload_text"] = d["payload_text"].replace("o2oa_lookorgan","common")
        d["payload_text"] = d["payload_text"].replace("o2oa_lookrole","common")
        d["payload_text"] = d["payload_text"].replace("o2oa_lookperson","common")
        d["payload_text"] = d["payload_text"].replace("o2oa_lookgroup","common")
# 替换o2oa_user标签
for d in data:
    if d["dport"] == "10000" or d["sport"] == "10000":
        d["payload_text"] = d["payload_text"].replace("o2oa_lookorgan","common")
        d["payload_text"] = d["payload_text"].replace("o2oa_userlookconf","common")
        d["payload_text"] = d["payload_text"].replace("o2oa_lookperson","common")
        d["payload_text"] = d["payload_text"].replace("o2oa_lookgroup","common")
        d["payload_text"] = d["payload_text"].replace("o2oa_userlookpublish","common")
       


# 临时处理一下标记数据
# 处理gitlab数据

for flow in data:
    if flow["dip"] == dstIp and flow["dport"] == "10000" and flow["payload_text"]!="":
        payload = flow["payload_text"]
        t = payload.split("-")
        flow["payload_text"] = t[0] + "-" + t[2]

# 处理o2oa数据,处理掉通向数据库的流量
"""
data_temp = []
for flow in data:
    if flow["sip"] == "172.17.0.2" or flow["dip"] == "172.17.0.2":
        pass
    else:
        data_temp.append(flow)
data = data_temp
"""
"""
with open("./test.txt",'w', encoding="utf-8") as fout:
    res = ""
    for d in data:
        res = d["time"] + " " + d["sport"] + " " + d["dport"] + " " + str(d["tcp_ack"]) + " " + str(d["tcp_seq"]) +" " + str(d["payload"])
        fout.write(res)
        fout.write("\n")
"""
port = "10000"
data_temp = []
for flow in data:
    if flow["sip"] == dstIp and flow["sport"] == port and flow["payload_type"] == "none":
        pass
    elif flow["dip"] == dstIp and flow["dport"] == port and flow["payload_type"] == "none":
        pass
    else:
        # 修改一下标注
        if flow["payload_text"] == "start-insertone" or flow["payload_text"] == "end-insertone" or flow["payload_text"] == "start-insertmany" or flow["payload_text"] == "end-insertmany":
            flow["payload_text"] = flow["payload_text"].split("-")[0] + "-" + "insert"
        data_temp.append(flow)


data = data_temp# 复制一份数据


# 此处替换ip
srcIp = ""
for flow in data:
    if flow["sip"] == dstIp:
        flow["dip"] = userIp
        flow["sip"] = appIp
    elif flow["dip"] == dstIp:
        flow["dip"] = appIp
        flow["sip"] = userIp

data_split = splitMain2(data)  


# 修改filecodebox标签
data_temp = {}
index = 1
for key in data_split.keys():
    if str(key).startswith("up"):
        for flow in data_split[key]:
            if flow["payload_type"] == "http-req" and "/share/file/" == flow["payload_text"]["uri"]:
                data_temp["upfile-" + str(index)] = data_split[key]
                index +=1
                break
            elif flow["payload_type"] == "http-req" and "/share/text/" == flow["payload_text"]["uri"]:
                data_temp["uptext-" + str(index)] = data_split[key]
                index +=1
                break
    else:
        data_temp[str(key).split("-")[0] + "-" + str(index)] = data_split[key]
        index+=1
data_split = data_temp

"""
# 找到名称对应关系
data_num_to_name = {}
for key in data_split.keys():
    num = key.split("-")[1]
    data_num_to_name[num] = key


# 处理交叉数据


def groupByPort(data)->dict:
    res = {}
    for flow in data:
        key1 = flow["sport"] + "_" + flow["dport"]
        key2 = flow["dport"] + "_" + flow["sport"]
        key = key1
        if key1 in res.keys():
            key = key1
        elif key2 in res.keys():
            key = key2
        else:
            res[key1] = []
        res[key].append(flow)
    #res_temp = []
    #for key in res.keys():
       # res_temp.append(res[key])
    #res = res_temp
    return res


def __dealCrossData(flows1, flows2):
    # 每组内的数据先按照端口分组
    port_group1 = groupByPort(flows1)
    port_group2 = groupByPort(flows2)
    # 需要向对方合并的数据
    if len(port_group1.keys()) == 1 or len(port_group2.keys()) == 1:
        return flows1, flows2
        # 不需要合并
        return
    flows1_to_flows2 = []
    flows2_to_flows1 = []
    for key1 in port_group1.keys():
        if key1 in port_group2.keys():
            if len(port_group1[key1]) > len(port_group2[key1]):
                flows2_to_flows1.append(key1)
            else:
                flows1_to_flows2.append(key1)
    for key in flows1_to_flows2:
        port_group2[key].extend(port_group1[key])
        port_group1.pop(key)

    for key in flows2_to_flows1:
        port_group1[key].extend(port_group2[key])
        port_group2.pop(key)
    flows1_temp = []
    for key in port_group1.keys():
        flows1_temp.extend(port_group1[key])
    flows2_temp = []
    for key in port_group2.keys():
        flows2_temp.extend(port_group2[key])
    return flows1_temp, flows2_temp


data_temp = copy.deepcopy(data_split)
index = 0
while index < len(data_temp) - 1:
    flows2 = data_temp[data_num_to_name[str(index+1)]]
    flows1 = data_temp[data_num_to_name[str(index)]]
    flows1, flows2 =  __dealCrossData(flows1, flows2)
    index +=1

data = data_temp
"""

data_group = {}
for key in data_split.keys():
    name = key.split("-")[0]
    if name not in data_group.keys():
        data_group[name] = []
    if len(data_split[key]) != 0:
        data_group[name].append(data_split[key])



# 人工查看标注的数据
# 找出可能存在异常的数据组
# 1.数量异常
# 2.payload数量和其他的不同
# 3.

"""
from groupFlow import GroupFlow

group = GroupFlow()

data_temp = {}
for key in data_group.keys():    
    data_temp[key] = group.groupByFeatures(data_group[key], train_or_test="test")

# 合并数据
data_group = {}
for key in data_temp.keys():
    data_group[key] = []
    for d in data_temp[key]:
        data_group[key].extend(data_temp[key][d])
"""

# 4.标记数据
data_label = []
for key in data_group.keys():
    flag = main_flag + "_"+ key
    datas = data_group[key]
    for flows in datas:
        for flow in flows:
            flow["label"] = flag
    data_label.append(datas)
    
# 修改所有的clone标记为pull标记
for flow_list in data_label:
    for flows in flow_list:
        for flow in flows:
            if flow["label"] == "gitlab_clone":
                flow["label"] = "gitlab_pull"

    
# 6.排序并保存标记完成的数据
# 每组内按照时间排序数据

# 混和所有数据并按照时间排序
data_res = []
for datas in data_label:
    for data in datas:
        data_res.extend(data)
data_res.sort(key=lambda t: float(t["time"]))

with open(otuputPath, 'w', encoding = "utf-8") as fout:
    json.dump(data_res,fout)