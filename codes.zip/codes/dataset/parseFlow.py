"""
@Type doc
@Author xjp
@CreateDate 2025-04-09_10:25:48
@Description 解析流量3.0版 细化payload类型 
@Version 3.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""


from scapy.all import rdpcap, Packet, Raw
import myRegex
regex = myRegex.MyRegex()
from typing import List
import json

from bs4 import BeautifulSoup
import xml.etree.ElementTree as ET

import yaml
import configparser
import ast
import regex as re
import binascii

def parseOnePcap(path:str)->List:
    res = []
    try:
        # 读取流量包
        packets = rdpcap(path)
        if packets != None:   
            for p in packets:
                try:
                    temp = {}
                    # 获取时间戳
                    temp["time"] = str(p.time)
                    temp["length"] = len(p)
                    if p.haslayer("IP"):
                        # 解析源IP
                        temp["sip"] = p["IP"].src
                        # 解析目的IP
                        temp["dip"] = p["IP"].dst
                        # 解析源port
                        temp["sport"] = str(p["IP"].sport)
                        # 解析目的port
                        temp["dport"] = str(p["IP"].dport)
                        # 解析协议
                        temp["proto"] = p["IP"].proto
                        # IP版本
                        temp["version"] = p["IP"].version
                        # IP首部长度
                        temp["headlength"] = p["IP"].ihl
                        # 服务类型
                        temp["tos"] = p["IP"].tos
                        # IP包长度
                        temp["length_ip"] = p["IP"].len
                        # ip包标识
                        temp["ip_id"] = p["IP"].id
                        # 标志位
                        #temp["ip_flags"] = p["IP"].flags
                        # 片偏移
                        temp["ip_frag"] = p["IP"].frag
                        # 生存时间
                        temp["ttl"] = p["IP"].ttl
                        # uri
                        temp["uri"] = ""
                        # url参数
                        temp["params"] = {}
                    if p.haslayer("TCP"):
                        # 序列号
                        temp["tcp_seq"] = p["TCP"].seq
                        # 确认号
                        temp["tcp_ack"] = p["TCP"].ack
                        # 首部长度
                        temp["tcp_dataofs"] = p["TCP"].dataofs
                        # 标志位
                        #temp["tcp_flags"] = p["TCP"].flags
                        # 窗口大小
                        temp["tcp_window"] = p["TCP"].window
                        # 校验和
                        temp["tcp_chksum"] = p["TCP"].chksum
                    # 解析Raw层
                    try:
                        if p.haslayer(Raw):
                            #temp["raw"] = p["Raw"].load.decode().split("\r\n")
                            temp["raw"] = p["Raw"].load
                            temp["payload"] = p["Raw"].load.decode().replace("\r\n"," ").replace("\n"," ")
                            """
                            if type(temp["raw"]) == str:
                                temp["payload"] = p["Raw"].load.decode().replace("\r\n"," ").replace("\n"," ")
                            elif type(temp["raw"]) == list:
                                t = ""
                                for r in temp["raw"]:
                                    t += r + " "
                                t = t[:-1]
                                temp["payload"] = t
                            else:
                                print(type(temp["raw"]))
                            """
                        else:
                            temp["payload"] = ""
                            temp["raw"] = ""

                    except:
                        #temp["payload"] = ""
                        #temp["raw"] = ""
                        pass
            
                    # 汇总结果到最终结果集中
                    res.append(temp)
                except Exception as e:
                    print(e)
    except Exception as e:
        print(f"解析流量失败:{e}")
    # 清除无效数据
    res_temp = []
    for r in res:
        if "sip" not in r.keys() or "dip" not in r.keys():
            pass
        else:
            res_temp.append(r)
    res = res_temp


    for r in res:
        t = __parsePayload(r["raw"])
        r["payload_type"] = t[0]
        r["payload_text"] = t[1]
        r["raw"] = ""
        # 特定格式需要解析特定的内容
        if t[0] == "http-req":
            # 处理http请求
            # 解析uri   
            r["payload_text"] = __parseHttpReq(t[1])
        elif t[0] == "http-res":
            # 处理http响应
            r["payload_text"] = __parseHttpRes(r["payload_text"])
        elif t[0] == "bytes":
            r["payload_text"] = binascii.hexlify(r["payload_text"]).decode("utf-8")

        # 正则表达式替换数据
        r["payload_text"] = regex.replacePayloadText(r["payload_text"])
    return res



"""
@Type function
@Author xjp
@CreateDate 2025-04-09_10:37:39
@Description 解析payload数据
@Param payload:字节数据
@Return List(数据类型,具体的值)
"""
def __parsePayload(payload)->List:
    res = []
    try:
        if type(payload) != str:
            text = payload.decode()
        else:
            text = payload
        # payload数据为空
        if text == "":
            res = ["none", text]
            return res
        # 识别是否为http请求
        if __judgeHttpReq(text):
            res = ["http-req",text]
            return res
        # 识别是否为http响应
        if __judgeHttpRes(text):
            res = ["http-res",text]
            return res
        # 判断是否为数字
        if __judgeNum(text):
            res = ["num", text]
            return res
        # 判断是否为json格式
        if __judgeJson(text):
            t = json.loads(text)
            res = ["json", t]
            return res
        # 判断是否为html格式
        if __judgeHtml(text):
            res = ["html",text]
            return res
        # 判断是否为xml格式
        if __judgeXml(text):
            res = ["xml", text]
            return res
        # 判断是否为yaml格式
        #if __judgeYaml(text):
            #res = ["yaml", text]
            #return res
        # 判断是否为ini格式
        #if __judgeIni(text):
            #res = ["ini",text]
            #return res
        
        # 判断是否为列表
        t = __judgeList(text)
        if t != None:
            res = ["list",t]
            return res  
        # 处理特殊字符
        try:
            text = regex.replaceStr(text)      
        except Exception as e:
            print(e)
        res = ["str", text]
    except:
        res = ["bytes", payload]
    return res


# 判断是否是http请求
def __judgeHttpReq(text)->bool:
    if text.startswith(("GET","POST","PUT","DELETE")):
        return True
    return False


# 判断是否是http响应
def __judgeHttpRes(text)->bool:
    pattern = re.compile(r"HTTP/[1-2]\.[0-9] \d{3} [^\r\n]+(\r\n|\n)")
    if re.search(pattern, text):
        return True
    return False


# 判断是否为json格式
def __judgeJson(text)->bool:
    try:
        t = json.loads(text)
        return True
    except:
        return None
# 判断是否为html格式
def __judgeHtml(text)->bool:
    try:
        r = BeautifulSoup(text,'html.parser')
        if r.html:
            return True
    except:
        pass
    return False


# 判断是否为xml格式
def __judgeXml(text)->bool:
    try:
        r = ET.fromstring(text)
        return True
    except:
        pass
    return False

# 判断是否为YAML格式
def __judgeYaml(text)->bool:
    try:
        yaml.safe_load(text)
        print(text)
        return True
    except:
        pass
    return False

# 判断是否为ini格式
def __judgeIni(text)->bool:
    config = configparser.ConfigParser()
    try:
        config.read_string(text)
        if config.sections():
            return True
    except:
        pass
    return False


# 判断是否是列表数据
def __judgeList(text)->List:
    try:
        data = ast.literal_eval(text)
        if isinstance(data, list):
            return data
    except:
        pass
    return None

# 判断是数值数据
def __judgeNum(text)->bool:
    if __judgeFloat(text) or __judgeInt(text):
        return True
    return False

def __judgeFloat(text)->bool:
    try:
        float(text.strip())
        return True
    except:
        pass
    return False

def __judgeInt(text)->bool:
    try:
        int(text.strip())
        return True
    except:
        pass
    return False

# 解析获得uri
def __parseUri(text):
    uri = ""
    try:
        uri = text.split(" ")[1]
    except Exception as e:
        #print(f"__parseUrl:出现异常:{e}")
        pass
    return uri


def __extractUriParams(url)->dict:
    param_res = {}
    # 提取参数
    pattern = re.compile(r'\?([^#]*)')
    match = re.search(pattern, url)
    if match:
        # 获取匹配到的参数部分
        params_str = match.group(1)
        # 分割参数为键值对列表
        params = params_str.split('&')
        param_dict = {}
        for param in params:
            # 分割键和值
            try:
                key, value = param.split('=')
                param_res[key] = value
            except:
                continue
        # 替换url中的参数
        url = re.sub(pattern,"-params",url)
    return url,param_res


"""
@Type function
@Author xjp
@CreateDate 2025-04-10_10:24:07
@Description 解析http响应 
@Param 
@Return 
"""
def __parseHttpRes(text:str)->dict:
    res = {}
    try:
        # 先分割文本
        # 先分割文本
        lines = text.splitlines()
        # 提取状态行
        status_line = lines[0]
        # 提取状态码
        parts = status_line.split()
        if len(parts) >=2 :
            try:
                status_code = int(parts[1])
                res["code"] = status_code
            except:
                res["code"] = 0
        # 提取响应头
        headers = {}
        index = 1
        while index < len(lines):
            line = lines[index]
            if not line.strip():
                break
            parts = line.split(":", 1)
            if len(parts) == 2:
                key = parts[0].strip()
                value = parts[1].strip()
                headers[key] = value
            index += 1
        for k,v in headers.items():
            res[k] = v
        
        # 提取响应体
        body = '\n'.join(lines[index+1:])
        res["body"] = body
    except Exception as e:
        print(f"解析http响应出现异常:{e}")
    return res


"""
@Type function
@Author xjp
@CreateDate 2025-04-11_09:38:17
@Description 解析http请求体 
@Param 
@Return 
"""
def __parseHttpReq(text:str)->dict:
    res = {}
    try:
        # 先分割文本
        # 先分割文本
        lines = text.splitlines()
        # 提取状态行
        status_line = lines[0]
        # 提取请求方法
        parts = status_line.split()
        if len(parts) >=2 :
            try:
                res["method"] = parts[0]
                res["uri"] = parts[1]
            except:
                res["method"] = ""
                res["uri"] = ""
        # 解析参数
        if res["uri"] != "":
            res["uri"],res["params"] = __extractUriParams(res["uri"])
        else:
            res["params"] = {}
        # 提取请求头
        headers = {}
        index = 1
        while index < len(lines):
            line = lines[index]
            if not line.strip():
                break
            parts = line.split(":", 1)
            if len(parts) == 2:
                key = parts[0].strip()
                value = parts[1].strip()
                headers[key] = value
            index += 1
        for k,v in headers.items():
            res[k] = v
    except Exception as e:
        print(f"解析http响应出现异常:{e}")
    return res