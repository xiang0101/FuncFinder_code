"""
@Type function
@Author xjp
@CreateDate 2025-03-24_18:29:49
@Description 流量分组算法 
@Param 
@Return 
"""

from typing import List
#from . import calcSim
import copy

# 计算k-mean聚类需要
from sklearn.cluster import KMeans
import numpy as np


"""
@Type class
@Author xjp
@CreateDate 2025-03-24_22:41:04
@Description 流量分组类 
"""
class GroupFlow:
    def __init__(self):
        # 按照特征分组的结果
        self.__group_by_feature = {}
        # 按照特征分组的索引
        self.index_feature = 0
        # 按照特征分组的数量阈值
        self.num_thre = 1


    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-24_22:08:39
    @Description 
    @Param 
    @Return 
    """
    def groupByIp(self,flows:List)->List:
        res = {}
        for flow in flows:
            key1 = flow["sip"] + "_" + flow["dip"]
            key2 = flow["dip"] + "_" + flow["sip"]
            if key1 in res.keys():
                res[key1].append(flow)
            elif key2 in res.keys():
                res[key2].append(flow)
            else:
                res[key1] = [flow]
        res_temp = []
        for key in res.keys():
            res_temp.extend([res[key]])
        res = res_temp
        return res    

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-24_22:14:39
    @Description 按照端口对分组
    @Param flows:流量序列;time_thre:时间阈值
    @Return res = [[{},{},{},...],[],[],...]
    """
    def groupByPort(self, flows:List, time_thre:float = 10)->List:
        res = []
        group_temp = {}
        index = 0
        for flow in flows:
            key = None
            key1 = str(flow["sport"]) + "_" + str(flow["dport"])
            key2 = str(flow["dport"]) + "_" + str(flow["sport"])
            if key1 in group_temp.keys():
                key = key1
            elif key2 in group_temp.keys():
                key = key2
            else:
                key = key1
                group_temp[key] = []
            group_temp[key].append(flow)
            # 需要移除的端口对列表
            port_remove = []
            for port in group_temp.keys():
                if port != key:
                    # 判断时间是否超过阈值
                    time_last = float(flow["time"])
                    time_pre = float(group_temp[port][-1]["time"])
                    if (time_last - time_pre) >= time_thre:
                        port_remove.append(port)
            for port in port_remove:
                res.append(group_temp[port])
                group_temp.pop(port)
                index+=1
        # 跳出循环后,处理临时分组中剩余的内容
        for key in group_temp.keys():
            res.append(group_temp[key])
            index +=1

        return res

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-25_16:05:43
    @Description 按照时间间隔异常划分数据
    @Param 
    @Return 
    """
    def groupByTimeInterval(self, flows:List)->List:
        if len(flows) <= 2:
            return [flows]
        # 提取时间序列
        # 时间序列
        time_list = []
        # 将时间序列转换为流量
        time_to_flow = {}
        # 存储字符串格式的时间序列
        keys = []
        # 遍历流量
        for flow in flows:
            time_list.append(float(flow["time"]))
            time_to_flow[str(flow["time"])] = flow
            keys.append(str(flow["time"]))
        # 转换时间序列为numpy数组
        timestamps = np.array(time_list)
        
        # 计算时间间隔
        time_diffs = np.diff(timestamps)
        # 对时间间隔进行k-means聚类
        # 聚类为2类,一类正常,一类异常
        n_clusters = 2
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        cluster_labels = kmeans.fit_predict(time_diffs.reshape(-1, 1))
        # 计算每个簇的均值和数据点数量
        cluster_means = []
        cluster_sizes = []
        for i in range(n_clusters):
            cluster_data = time_diffs[cluster_labels == i]
            cluster_means.append(np.mean(cluster_data))
            cluster_sizes.append(len(cluster_data))

        # 假设异常点所在的簇数据量相对较少且簇的均值较大
        # 找出可能的异常点簇的索引
        anomaly_cluster_index = np.argmin(cluster_sizes) if cluster_means[np.argmin(cluster_sizes)] > cluster_means[np.argmax(cluster_sizes)] else np.argmax(cluster_sizes)
        # 找出异常点的索引
        anomaly_indices = np.where(cluster_labels == anomaly_cluster_index)[0]

        # 根据异常时间间隔,找到异常的时间戳
        time_anomaly = []
        for index in anomaly_indices:
            time_anomaly.append(timestamps[index+1])
        # 利用时间分割流量
        res = {}
        index = 0
        temp = []
        for key in keys:
            if float(key) not in time_anomaly:
                temp.append(time_to_flow[key])
            else:
                res[str(index)] =  temp
                index += 1
                temp = [time_to_flow[key]]
        res[str(index)] = temp
        temp = res
        res = []
        # 包装最终数据
        for key in temp.keys():
            res.append(temp[key])
        return res

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-18_10:34:12
    @Description 按照顺序提取流量的第n个特征
    @Param flows:流量序列; loc:第n个流量特征;
    @Return 提取到的特征,如果未提取到则返回空列表
    """
    def __extractFeatureByLoc(self, flows:List, loc:int = 0)->List:
        index = 0
        res = []
        for flow in flows:
            if flow["payload"] != "":
                if index == loc:
                    res = [flow["payload"]]
                    break
                index += 1
        return res


    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-19_15:10:50
    @Description 流量特征匹配算法,从流量序列中提取第n个特征并和给定的特征相匹配(修改了相似度比较算法)
    @Param flows:流量序列; features:特征列表; loc:第n个用于比对的特征
    @Return 
    """
    def __matchFeatures(self, flows:List[dict], features:List[str], loc:int)->bool:
        # 提取流量序列的第loc个特征
        res = self.__extractFeatureByLoc(flows, loc)
        if len(res) == 0:
            return False
        # 开始比对特征
        #if calcSim.simToken(res[0], features[0]):
            #return True
        # 20250407 修改为完全匹配
        if res[0] == features[0]:
            return True
        return False
        

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-20_19:04:21
    @Description 按照符号特征分组数据 
    @Param 
    @Return 
    """
    def __groupByOneFeature(self, flows_list:List[List], loc:int):
        # 流量序列数量小于一定值后停止分组
        if len(flows_list) <= self.num_thre:
            # 直接形成一个分组
            self.__group_by_feature[str(self.index_feature)] = flows_list
            self.index_feature += 1
            return
        # 左分组,表示匹配上特征的分组
        group_left = []
        # 右分组,表示未匹配上特征的分组
        group_right = []
        feature = []
        # 提取特征
        for flows in flows_list:
            feature = self.__extractFeatureByLoc(flows,loc)
            if len(feature) != 0:
                break
        # 如果所有流量序列都没有新特征出现,则将当前分组形成一个新分组
        if len(feature) == 0:
            # 直接形成一个分组
            self.__group_by_feature[str(self.index_feature)] = flows_list
            self.index_feature += 1
            return
        # 继续分组数据
        for flows in flows_list:
            res = self.__matchFeatures(flows,feature,loc)
            if res:
                group_left.append(flows)
            else:
                group_right.append(flows)
        # 如果全部分到一组

        # 继续向下比对特征
        if len(group_left) != 0:
            self.__groupByOneFeature(group_left, loc + 1)
        if len(group_right) != 0:
            self.__groupByOneFeature(group_right, loc)


    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-24_22:47:30
    @Description  按照特征分组数据 
    @Param 
    @Return 
    """
    def __groupByFeatures(self, flows_list:List[List])->List:
        self.__groupByOneFeature(flows_list,0)
        res = []
        for key in self.__group_by_feature.keys():
            res.append(self.__group_by_feature[key])

        return res





    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-21_10:58:36
    @Description 比较两组流量的结构特征(协议,流量方向,固定端口方位) 
    @Param 
    @Return 
    """
    def __matchByStructure(self, flow1:List, flow2:List)->bool:
        if len(flow1) != len(flow2):
            return False
        # 循环比对特征
        index = 0
        while index < len(flow1):
            if flow1[index]["proto"] != flow2[index]["proto"]:
                return False
            #if flow1[index]["direction"] != flow2[index]["direction"]:
                #return False
            if flow1[index]["sport"] == flow2[index]["dport"] and flow1[index]["dport"] == flow2[index]["sport"] and flow1[index]["sport"] != flow2[index]["sport"]:
                return False
            index += 1
        return True
            

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-21_10:50:01
    @Description 按照流量结构分组(协议,流量方向,固定端口方位) 
    @Param flows = [[{},{},...],[],[],...]
    @Return 
    """
    def __groupByStructure(self, flow_list:List, groups:List)->None:
        if len(flow_list)== 1:
            # 该组只剩下一个流量序列,直接分为1组
            groups.append(flow_list)
            return
        # 选中第一组的流量,以它为参考对比其他组流量
        flow_std = flow_list[0]
        group_left = [flow_std]
        group_right = []
        index = 1
        while index < len(flow_list):
            if self.__matchByStructure(flow_std, flow_list[index]):
                # 匹配成功加入分组
                group_left.append(flow_list[index])
            else:
                group_right.append(flow_list[index])
            index +=1
        # 形成新分组
        if len(group_left) != 0:
            groups.append(group_left)
        # 还能继续分组
        if len(group_right) != 0:
            self.__groupByStructure(group_right, groups)



    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-24_22:56:59
    @Description 分组不包含特征的数据
    @Param flows_list:不包含流量特征的数据;train_or_test:表示是训练数据还是测试数据,处理方式略有不同
    @Return 
    """
    def __groupNoneFeatureData(self, flows_list:List[List],train_or_test:str = "train")->List:
        res = {"0":copy.deepcopy(flows_list)}
        # 0.先按照编号划分数据
        if train_or_test == "train":
            res_temp = {}
            index = 0
            for key in res.keys():
                dataFlag = {}
                for flows in res[key]:
                    if flows[0]["label"] not in dataFlag.keys():
                        dataFlag[flows[0]["label"]] = []
                    dataFlag[flows[0]["label"]].append(flows)
                
                # 填充数据
                for label in dataFlag.keys():
                    res_temp[str(index)] = dataFlag[label]
                    index += 1
            res = res_temp
        # 1.按照端口划分数据
        res_temp = {}
        index = 0
        
        
        for key in res.keys():
            portCount = {}
            dataPort = {}
            dataPort["no"] = []
            # (1)先统计每对端口出现的次数
            for flows in res[key]:
                sport = str(flows[0]["sport"])
                dport = str(flows[0]["dport"])
                if sport not in portCount.keys():
                    portCount[sport] = 0
                if dport not in portCount.keys():
                    portCount[dport] = 0
                portCount[sport] += 1
                portCount[dport] += 1
            # (2)按照端口划分数据
            for flows in res[key]:
                sport = str(flows[0]["sport"])
                dport = str(flows[0]["dport"])
                if portCount[sport] > portCount[dport] and portCount[sport] > 1:
                    if sport not in dataPort.keys():
                        dataPort[sport] = []
                    dataPort[sport].append(flows)
                elif portCount[dport] > portCount[sport] and portCount[dport] > 1:
                    if dport not in dataPort.keys():
                        dataPort[dport] = []
                    dataPort[dport].append(flows)
                else:
                    dataPort["no"].append(flows)
            # (3)填充分组数据
            for port in dataPort.keys():
                res_temp[str(index)] = dataPort[port]
                index += 1
        res = res_temp
        

        # 2.按照数量分组
        res_temp = {}
        index = 0
        for key in res.keys():
            group = {}
            for flows in res[key]:
                length = str(len(flows))
                if length not in group.keys():
                    group[length] = []
                group[length].append(flows)
            for length in group.keys():
                res_temp[str(index)] = group[length]
                index +=1
        res = res_temp

        # 3.按照流量结构分组
        res_temp = []
        index = 0
        groups = []

        for key in res.keys():
            groups = []
            self.__groupByStructure(res[key],groups)
            res_temp.extend(groups) 
        
        # 4.填充最终数据
        res = res_temp
        """
        for key in res_temp.keys():
            res.append(res_temp[key])
        """
        return res

    
    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-24_23:04:13
    @Description 将不包含特征的数据和包含特征的数据分割开
    @Param 
    @Return 
    """
    def __extractNoneFeatureData(self, flows_list:List[List]):
        data_none = []
        data_have = []
        for flows in flows_list:
            res = self.__extractFeatureByLoc(flows)
            if len(res) == 0:
                data_none.append(flows)
            else:
                data_have.append(flows)
        return data_none, data_have


    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-24_22:57:52
    @Description 按照特征划分数据的主程序
    @Param 
    @Return 
    """
    def groupByFeatures(self, flows_list:List[List], train_or_test = "train")->dict:
         # 按照特征分组的结果
        self.__group_by_feature = {}
        # 按照特征分组的索引
        self.index_feature = 0
        # 1.将不包含特征的数据和包含特征的数据分割开
        flows_none, flows_have = self.__extractNoneFeatureData(flows_list)
        # 2.将包含特征的按照特征分组
        res_have = self.__groupByFeatures(flows_have)
        # 3.将不包含特征的数据分组
        res_none = self.__groupNoneFeatureData(flows_none,train_or_test=train_or_test)
        # 4.合并数据
        res = []
        res.extend(res_have)
        res.extend(res_none)
        # 编组最终分类数据
        final_res = {}
        index = 0
        for flow_list in res:
            final_res[str(index)] = flow_list
            index += 1
        return final_res
    

    # 比较两条流量是否相似
    def __matchTwoFlow(self,flow1, flow2):
        # 先判断方向
        if flow1["direction"] != flow2["direction"]:
            return False
        # 先判断结构是否相同
        if not (flow1["sport"] == flow2["sport"] or flow1["dport"] == flow2["dport"]):
            return False
        # 最后判断payload
        if not calcSim.simToken(flow1["payload"],flow2["payload"]):
            return False
        return True
        

    # 比较两个流量序列的相似度
    def __matchTwoFlows(self,flows1, flows2,thre=0.6):
        max_count = max(len(flows1),len(flows2))
        flows2_temp = copy.deepcopy(flows2)
        count  = 0
        for flow in flows1:
            index = 0
            while index < len(flows2_temp):
                if self.__matchTwoFlow(flow,flows2_temp[index]):
                    break
                index +=1
            if index != len(flows2_temp):
                count += 1
                flows2_temp.pop(index)
            
        # 计算阈值
        if count/max_count > thre:
            return True
        return False


    def __groupByOneFeature3(self, flow_list:List)->None:
        #print(len(flow_list))
        if len(flow_list)== 1:
            # 该组只剩下一个流量序列,直接分为1组
            self.__group_by_feature[str(self.index_feature)]=flow_list
            self.index_feature += 1
            return
        # 选中第一组的流量,以它为参考对比其他组流量
        flow_std = flow_list[0]
        group_left = [flow_std]
        group_right = []
        index = 1
        while index < len(flow_list):
            if self.__matchTwoFlows(flow_std, flow_list[index]):
                group_left.append(flow_list[index])
            else:
                group_right.append(flow_list[index])
            index +=1
        # 形成新分组
        self.__group_by_feature[str(self.index_feature)]=group_left
        self.index_feature += 1
        # 还能继续分组
        if len(group_right) != 0:
            self.__groupByOneFeature3(group_right)

    def __groupByFeatures3(self, flows_list:List[List])->List:
        self.__groupByOneFeature3(flows_list)
        res = []
        for key in self.__group_by_feature.keys():
            res.append(self.__group_by_feature[key])

        return res


    # 加入包含机制
    def groupByFeatures3(self, flows_list:List[List], train_or_test = "train")->dict:
        # 1.将不包含特征的数据和包含特征的数据分割开
        flows_none, flows_have = self.__extractNoneFeatureData(flows_list)
        # 2.将包含特征的按照特征分组
        res_have = self.__groupByFeatures3(flows_have)
        # 3.将不包含特征的数据分组
        res_none = self.__groupNoneFeatureData(flows_none,train_or_test=train_or_test)
        # 4.合并数据
        res = []
        res.extend(res_have)
        res.extend(res_none)
        # 编组最终分类数据
        final_res = {}
        index = 0
        for flow_list in res:
            final_res[str(index)] = flow_list
            index += 1
        return final_res

    """
    @Type function
    @Author xjp
    @CreateDate 2025-03-31_17:24:50
    @Description 比较两个流量序列是否包含全部相同的payload,不考虑顺序 
    @Param 
    @Return 
    """
    def __compTwoFlowAllFeature(self, flows1:List, flows2:List):
        flows1_payload = []
        flows2_payload = []
        for flow in flows1:
            if flow["payload"] != "":
                flows1_payload.append(flow["payload"])
        for flow in flows2:
            if flow["payload"] != "":
                flows2_payload.append(flow["payload"])
        for payload1 in flows1_payload:
            flag = False
            temp = ""
            for payload2 in flows2_payload:
                if calcSim.simToken(payload1, payload2):
                    flag = True
                    temp = payload2
                    break
            if flag:
                flows2_payload.remove(temp)
            else:
                return False
        if len(flows2_payload) == 0:
            return True
        return False


    def __groupByFeatures2(self, flows_list:List[List])->List:
        self.__groupByOneFeature2(flows_list)
        res = []
        for key in self.__group_by_feature.keys():
            res.append(self.__group_by_feature[key])

        return res


    def __groupByOneFeature2(self, flow_list:List)->None:
        print(len(flow_list))
        if len(flow_list)== 1:
            # 该组只剩下一个流量序列,直接分为1组
            self.__group_by_feature[str(self.index_feature)]=flow_list
            self.index_feature += 1
            return
        # 选中第一组的流量,以它为参考对比其他组流量
        flow_std = flow_list[0]
        group_left = [flow_std]
        group_right = []
        index = 1
        while index < len(flow_list):
            if self.__compTwoFlowAllFeature(flow_std, flow_list[index]):
                group_left.append(flow_list[index])
            else:
                group_right.append(flow_list[index])
            index +=1
        # 形成新分组
        self.__group_by_feature[str(self.index_feature)]=group_left
        self.index_feature += 1
        # 还能继续分组
        if len(group_right) != 0:
            self.__groupByOneFeature2(group_right)





    # 解决顺序错乱问题
    def groupByFeatures2(self, flows_list:List[List], train_or_test = "train")->dict:
        # 1.将不包含特征的数据和包含特征的数据分割开
        flows_none, flows_have = self.__extractNoneFeatureData(flows_list)
        # 2.将包含特征的按照特征分组
        res_have = self.__groupByFeatures2(flows_have)
        # 3.将不包含特征的数据分组
        res_none = self.__groupNoneFeatureData(flows_none,train_or_test=train_or_test)
        # 4.合并数据
        res = []
        res.extend(res_have)
        res.extend(res_none)
        # 编组最终分类数据
        final_res = {}
        index = 0
        for flow_list in res:
            final_res[str(index)] = flow_list
            index += 1
        return final_res