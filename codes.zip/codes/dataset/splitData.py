"""
@Type doc
@Author xjp
@CreateDate 2025-03-25_18:59:58
@Description 按照标记分割数据
@Version v2.0
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

from typing import List
import copy
# 计算k-mean聚类需要
from sklearn.cluster import KMeans
import numpy as np


"""
@Type function
@Author xjp
@CreateDate 2025-03-25_19:55:29
@Description 按照标志分割数据的主程序 
@Param 
@Return 
"""
def splitMain(data:List)->dict:
    # 复制一份数据
    data_temp = copy.deepcopy(data)
    # 编号数据
    index = 0
    data_num = {}
    for flow in data_temp:
        data_num[str(index)] = flow
        index += 1
    # 按照标志分组数据
    data_group = __splitDataByFlag(data_num)
    # 找到交叉数据
    #data_cross = __findCrossData(data_group)
    # 填充数据
    # 填充数据
    data_res = {}
    index = 0
    for key in data_group.keys():
        if data_group[key]["isvaild"] == False:
            continue
        flag = data_group[key]["flag"] + "-" + str(index) 
        index +=1
        data_res[flag] = []
        start = int(data_group[key]["start"])
        end = int(data_group[key]["end"])
        while start <= end:
            data_res[flag].append(data_num[str(start)])
            start += 1
    # 清除干扰数据,即目的端口为10000,且payload以start-或end-开头的流量
    for key in data_res.keys():
        temp = []
        for flow in data_res[key]:
            if str(flow["dport"]) == "10000" and (str(flow["payload_text"]).startswith("start-") or str(flow["payload_text"]).startswith("end-")):
                pass
            else:
                temp.append(flow)
        data_res[key] = temp
    return data_res





    # 按照有效数据填充结果
    data_fill = {}
    index = 0
    for key in data_cross.keys():
        if data_cross[key]["isvaild"] == True:
            data_fill[data_cross[key]["flag"] + "-" + str(index)] = []
            start = int(data_cross[key]["start"])
            end = int(data_cross[key]["end"])
            while start <= end:
                data_fill[data_cross[key]["flag"] + "-" + str(index)].append(data_num[str(start)])
                start += 1
            index += 1
            

def splitMain2(data:List)->dict:
    # 复制一份数据
    data_temp = copy.deepcopy(data)
    # 编号数据
    index = 0
    data_num = {}
    for flow in data_temp:
        data_num[str(index)] = flow
        index += 1
    # 按照标志分组数据
    data_group = __splitDataByFlag2(data_num)
    # 包装数据
    data_res = {}
    index = 1
    for key in data_group.keys():
        temp = data_group[key]["flag"] + "-" + str(index)
        data_res[temp] = data_group[key]["data"]
        index +=1
    return data_res





"""
@Type function
@Author xjp
@CreateDate 2025-03-25_21:06:20
@Description 处理交叉数据 
@Param 
@Return 
"""
def __dealCrossData(data_group:dict, data_num:dict)->dict:
    # 填充数据
    data_temp = {}
    for key in data_group.keys():
        data_temp[key] = copy.deepcopy(data_group[key])
        data_temp[key]["data"] = []
        start = int(data_temp[key]["start"])
        end = int(data_temp[key]["end"])
        while start <= end:
            data_temp[key]["data"].append(data_num[start])
            start += 1
    # 清除干扰数据,即目的端口为10000,且payload以start-或end-开头的流量
    for key in data_temp.keys():
        temp = []
        for flow in data_temp[key]["data"]:
            if str(flow["dport"]) == "10000" and (str(flow["payload"]).startswith("start-") or str(flow["payload"]).startswith("end-")):
                pass
            else:
                temp.append(flow)
        data_temp[key]["data"] = temp

    # 获取所有的起始标志
    keys = list(data_group.keys())
    keys.sort()
    index = 0
    while index < len(keys) - 1:
        if index -1 >=0:
            pre = data_temp[keys[index-1]]["data"]
        else:
            pre = None
        mid = data_temp[keys[index]]["data"]
        if index + 1 < len(keys):
            last = data_temp[keys[index+1]]["data"]
        else:
            last = None
        # 计算向前交叉
        if pre != None:
            data_all = []
            data_all.extend(pre)
            data_all.extend(mid)
            data_all = __groupByTimeInterval(data_all)
            if len(data_all) == 1:
                pre = data_all[0]
                mid = []
            else:
                pre = data_all[0]
                mid = []
                for i in range(len(data_all)):
                    if i == 0:
                        continue
                    mid.extend(data_all[i])
        # 计算向后交叉
        if last != None and len(mid) != 0:
            data_all = []
            data_all.extend(mid)
            data_all.extend(last)
            data_all = __groupByTimeInterval(data_all)
            if len(data_all) == 1:
                mid = data_all[0]
                last = []
            else:
                mid = data_all[0]
                last = []
                for i in range(len(data_all)):
                    if i == 0:
                        continue
                    last.extend(data_all[i])
        if pre != None:
            data_temp[keys[index-1]]["data"] = pre
        if mid != None:
            data_temp[keys[index]]["data"] = mid
        if last != None:
            data_temp[keys[index+1]]["data"] = last
        index += 1
    return data_temp


"""
@Type function
@Author xjp
@CreateDate 2025-03-25_21:03:36
@Description 按照时间间隔分组数据 
@Param 
@Return 
"""
def __groupByTimeInterval(flows:List)->List:
    if len(flows) <= 2:
        return [[flows]]
    # 提取时间序列
    # 时间序列
    time_list = []
    # 将时间序列转换为流量
    time_to_flow = {}
    # 存储字符串格式的时间序列
    keys = []
    # 遍历流量
    for flow in flows:
        time_list.append(float(flow["time"]))
        time_to_flow[str(flow["time"])] = flow
        keys.append(str(flow["time"]))
    # 转换时间序列为numpy数组
    timestamps = np.array(time_list)
    # 计算时间间隔
    time_diffs = np.diff(timestamps)
    # 对时间间隔进行k-means聚类
    # 聚类为2类,一类正常,一类异常
    n_clusters = 2
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    cluster_labels = kmeans.fit_predict(time_diffs.reshape(-1, 1))
    # 计算每个簇的均值和数据点数量
    cluster_means = []
    cluster_sizes = []
    for i in range(n_clusters):
        cluster_data = time_diffs[cluster_labels == i]
        cluster_means.append(np.mean(cluster_data))
        cluster_sizes.append(len(cluster_data))

    # 假设异常点所在的簇数据量相对较少且簇的均值较大
    # 找出可能的异常点簇的索引
    anomaly_cluster_index = np.argmin(cluster_sizes) if cluster_means[np.argmin(cluster_sizes)] > cluster_means[np.argmax(cluster_sizes)] else np.argmax(cluster_sizes)
    # 找出异常点的索引
    anomaly_indices = np.where(cluster_labels == anomaly_cluster_index)[0]

    # 根据异常时间间隔,找到异常的时间戳
    time_anomaly = []
    for index in anomaly_indices:
        time_anomaly.append(timestamps[index+1])
    # 利用时间分割流量
    res = {}
    index = 0
    temp = []
    for key in keys:
        if float(key) not in time_anomaly:
            temp.append(time_to_flow[key])
        else:
            res[str(index)] =  temp
            index += 1
            temp = []
    res[str(index)] = temp
    temp = res
    res = []
    # 包装最终数据
    for key in temp.keys():
        res.append(temp[key])
    return res        

"""
@Type function
@Author xjp
@CreateDate 2025-03-25_19:03:54
@Description 按照标志分割数据 (3.0)
@Param data:[{},{},{},...],流量数据
@Return 
"""
def __splitDataByFlag(data_num:List[dict])->dict:
    flag = "" 
    data_group = {}
    index = 0
    start = 0
    state = ""
    while index < len(data_num.keys()):
        flow = data_num[str(index)]
        if flow["payload_type"] !="str":
            index += 1
            continue
        if flow["payload_text"] == "":
            # 普通流量
            index += 1
            continue
        if str(flow["payload_text"]).startswith("start-"):
            if state == "":
                # 此时可以保留数据为common
                data_group[str(start)] = {
                    "flag":"common",
                    "isvaild":True,
                    "start":int(start),
                    "end":int(index-1)
                }
                start = index
                state = "start"
                index += 1
                flag = str(flow["payload_text"]).split("-")[1]
            elif state == "start" or state == "end":
                # 前面已经有一个start,弃置这部分数据
                data_group[str(start)] = {
                    "flag":"no",
                    "isvaild":False,
                    "start":int(start),
                    "end":int(index-1)
                }
                start = index
                state = "start"
                index += 1
                flag = str(flow["payload_text"]).split("-")[1]
            continue

        if str(flow["payload_text"]).startswith("end-"):
            if state == "" or state == "end":
                state = "end"
                index += 1
            elif state == "start":
                # 判断标志是否相同
                if flag == str(flow["payload_text"]).split("-")[1]:
                    # 标志相同,结束统计
                    data_group[str(start)]={
                        "flag":flag,
                        "isvaild":True,
                        "start":str(start),
                        "end":str(index)
                    }
                    start = index + 1
                    state = ""
                    index += 1
                else:
                    state = "end"
                    index +=1
            continue
        index += 1
    return data_group





"""
@Type function
@Author xjp
@CreateDate 2025-04-19_11:14:33
@Description 新版本分割数据 
@Param 
@Return 
"""
def __splitDataByFlag2(data_num:List[dict])->dict:
    flag = "" 
    data_group = {}
    index = 0
    temp = [] # 存储数据
    state = 0 # 初始化状态,寻找一个新的start
    while index <len(data_num):
        # 先获取流量
        flow = data_num[str(index)]
        # 先判断流量是否包含信息
        if flow["payload_type"] != "str":
            temp.append(flow)
            index +=1
            continue
        # 按照不同情况讨论
        if str(flow["payload_text"]).startswith("start-"):# 起始标志
            if state == 0: # 找寻一个起始标记的状态
                flag = flow["payload_text"].split("-")[1]
                state =1 # 找寻起始状态对应的终止状态
                # 之间数据加入common
                if len(temp) != 0:
                    data_group[str(index)] = {
                        "flag":"common",
                        "data":temp
                    }
                # 清空temp
                temp = []
            elif state == 1 or state == 2: # 已经找到一个起始状态,此时又出现一个起始状态
                # 更新flag为新状态,并且抛弃新的起始状态到遇到其终止状态的流量
                flag = flow["payload_text"].split("-")[1]
                state =2 # 抛弃到其终止状态的状态
            elif state == 3:
                flag = flow["payload_text"].split("-")[1]
                temp = []
                state = 1
        elif str(flow["payload_text"]).startswith("end-"):
            if state == 0:
                # 抛弃数据
                temp = []
                state = 3 # 找到下一个起始标志,并抛弃之间的数据
            elif state == 1:
                # 判断标志是否相同
                flag_t = flow["payload_text"].split("-")[1]
                if flag_t == flag:
                    if len(temp) != 0:
                        data_group[str(index)] = {
                        "flag":flag,
                        "data":temp
                        }
                    state = 0
                    flag = ""
                else:
                    # 抛弃找到直到下一个start之间的数据
                    state = 3
                # 清空temp
                temp = []
            elif state == 2:
                flag_t = flow["payload_text"].split("-")[1]
                if flag_t == flag:
                    # 如果找到终止了,状态置为3 找下一个start
                    state = 3
                else:
                    state = 2
            elif state == 3:
                state =3 
        else:
            temp.append(flow)
        index +=1
    return data_group



"""
@Type function
@Author xjp
@CreateDate 2025-03-25_19:35:20
@Description 查找存在交叉的数据 (修改处理方式后没有交叉数据)
@Param 
@Return 
"""
def __findCrossData(data:dict)->dict:
    data_temp = copy.deepcopy(data)
    for key in data_temp.keys():
        s1 = int(data_temp[key]["start"])
        e1 = int(data_temp[key]["end"])
        # 循环查找
        index = e1 - 1
        while index >0:
            if index == s1:
                index -= 1
                continue
            if str(index) in data_temp.keys():
                s2 = int(data_temp[str(index)]["start"])
                e2 = int(data_temp[str(index)]["end"])
                if s1 > e2 or e1 < s2:
                    pass
                else:
                    data_temp[key]["isvaild"] = False
                    data_temp[str(index)]["isvaild"] = False
            index -= 1
    return data_temp



"""
@Type function
@Author xjp
@CreateDate 2025-03-25_19:03:54
@Description 按照标志分割数据 
@Param data:[{},{},{},...],流量数据(2.0,旧版)
@Return 
def __splitDataByFlag(data_num:List[dict])->dict:
    flag = ""
    data_group = {}
    index = 0
    start = 0
    # 存储在两对起始和终止之间出现的start的位置
    start_2 = -1
    while index < len(data_num.keys()):
        flow = data_num[str(index)]
        if flow["payload"] == "":
            # 普通流量
            index += 1
            continue
        if str(flow["payload"]).startswith("start-"):
            if flag == "":
                if start != index:
                    # 未统计起始,此时为common
                    # 移除数据
                    data_group[str(start)] = {
                        "flag":"common",
                        "isvaild":True,
                        "start":str(start),
                        "end":str(index-1)
                    }
                # 设置flag标志
                flag = str(flow["payload"]).split("-")[1]
                start = index
                index +=1
            else:
                # 在已经统计一个的时候出现另一个起始标志,如果第一次出现start,记录该start位置,下一次从其开始统计
                if start_2 != -1:
                    start_2 = index
                index += 1
            continue
        if str(flow["payload"]).startswith("end-"):
            # 出现结束标志
            if flag == "":
                # 没有统计起始,跳过该标志
                index += 1
            else:
                # 判断标志是否相同
                if flag == str(flow["payload"]).split("-")[1]:
                    # 标志相同,结束统计
                    data_group[str(start)]={
                        "flag":flag,
                        "isvaild":True,
                        "start":str(start),
                        "end":str(index)
                    }
                    if start_2 != -1:
                        start = index
                        index = start
                        start_2 = -1
                        flag = ""
                    else:
                        start = index + 1
                        flag = ""
                        index +=1
                else:
                    index +=1
            continue
        index += 1
    return data_group
"""