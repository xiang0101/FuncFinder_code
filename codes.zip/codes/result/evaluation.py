"""
@Type doc
@Author xjp
@CreateDate 2025-04-05_14:53:59
@Description 评估标准
@Version v1.0
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import threading
from typing import List, Tuple
import queue
import math

from sklearn.metrics import adjusted_rand_score


"""
@Type function
@Author xjp
@CreateDate 2025-06-02_13:34:14
@Description ARI评估方法 
@Param 
@Return 
"""
def ARI(flow_group:dict):
    # 真实标签
    true_label = []
    # 预测标签
    pre_label = []
    # 标签索引
    index = 0
    # 标签和索引的对应字典
    dict_label_to_flag = {}

    # 遍历数据
    for key in flow_group.keys():
        
        
        for flow_seq in flow_group[key]:
            count = 0
            # 存储标签对应数量
            dict_temp = {}
            for flow in flow_seq:
                # 真实标签
                label = flow["label"]
                if label not in dict_label_to_flag.keys():
                    dict_label_to_flag[label] = index
                    index += 1
                t = dict_label_to_flag[label]
                # 加入真实标签
                true_label.append(t)
                if t not in dict_temp.keys():
                    dict_temp[t] = 0
                dict_temp[t] += 1
                count +=1 
            # 判断哪个标签出现次数最多
            t = 0
            flag = 0
            for key in dict_temp.keys():
                if dict_temp[key]>t:
                    flag = key
                    t = dict_temp[key]
            for i in range(count):
                pre_label.append(flag)
    # 计算ARI
    res =adjusted_rand_score(true_label, pre_label)
    return res


"""
@Type function
@Author xjp
@CreateDate 2025-04-05_15:00:20
@Description 计算Fowlkes - Mallows指数(FMI) 
@Param 
@Return 
"""
def FMI(flow_group:dict)->Tuple:
    q1 = queue.Queue()
    q2 = queue.Queue()
    thred1 = threading.Thread(target=__FMI_in,args=(flow_group,q1))
    thred2 = threading.Thread(target=__FMI_out,args=(flow_group,q2))
    thred1.start()
    thred2.start()
    thred1.join()
    thred2.join()
    TP = 0
    FN = 0
    FP = 0
    temp = q1.get()
    TP += temp[0]
    FN += temp[1]
    FP += temp[2]
    temp = q2.get()
    TP += temp[0]
    FN += temp[1]
    FP += temp[2]
    res = math.sqrt((TP/(TP+FP)*(TP/(TP+FN))))
    return res


"""
@Type function
@Author xjp
@CreateDate 2025-04-05_15:02:52
@Description 计算FMI的类内结果 
@Param 
@Return 
"""
def __FMI_in(flow_group:dict, q:queue.Queue)->None:
    TP = 0
    FP = 0
    FN = 0
    # 先将所有的流量混合到一起
    flows = []
    for key in flow_group.keys():
        #if key == "common":
            #continue
        flows = []
        for flow_list in flow_group[key]:
            flows.extend(flow_list)
        # 计算每两条流量
        left = 0
        while left +1 <len(flows):
            right = left + 1
            while right < len(flows):
                # 计算类内每两个的标签是否相同
                flow1 = flows[left]
                flow2 = flows[right]
                if flow1["label"] == flow2["label"]:
                    # 标签相同
                    count1 = __countFlow(flow1)
                    count2 = __countFlow(flow2)
                    TP += count1 * count2
                else:
                    # 标签不同
                    count1 = __countFlow(flow1)
                    count2 = __countFlow(flow2)
                    FN += count1 * count2
                right += 1
            left += 1
    q.put((TP,FN,FP))


"""
@Type function
@Author xjp
@CreateDate 2025-04-05_15:03:07
@Description 计算FMI的类间结果 
@Param 
@Return 
"""
def __FMI_out(flow_group:dict, q:queue.Queue)->None:
    TP = 0
    FN = 0
    FP = 0
    # 先将一个组内的所有流量混合到一起  
    flows_list = []
    for key in flow_group.keys():
        flows = []
        for flow_list in flow_group[key]:
            flows.extend(flow_list)
        flows_list.append(flows)

    left = 0
    while left + 1<len(flows_list):
        right = left + 1
        # 第一个组
        flow_list1 = flows_list[left]
        while right < len(flows_list):
            # 第二个组
            flow_list2 = flows_list[right]
            temp = __calcTwoGroup(flow_list1, flow_list2)

            FN += temp[1]
            right += 1
        left += 1
    q.put((TP,FN,FP))


"""
@Type function
@Author xjp
@CreateDate 2025-04-05_15:31:01
@Description 计算两个流量集合之间的结果 
@Param 
@Return 
"""
def __calcTwoGroup(flow_list1:List[dict], flow_list2:List[dict])->Tuple:
    TP = 0
    FN = 0
    FP = 0
    # 计算每两条流量
    left = 0
    for flow1 in flow_list1:
        for flow2 in flow_list2:
            # 计算类内每两个的标签是否相同
            if flow1["label"] == flow2["label"] and "common" not in flow1["label"]:
                # 标签相同
                count1 = __countFlow(flow1)
                count2 = __countFlow(flow2)
                FN += count1 * count2
    return (TP,FN,FP)
    

"""
@Type function
@Author xjp
@CreateDate 2025-04-05_15:03:43
@Description 还原流量数量 
@Param 
@Return 
"""
def __countFlow(flow:dict)->int:
    res = 0
    if flow["direction"] == "s":
        res += 1
        res += flow["count"]
    else:
        #res += 2
        res += flow["count"]*2
    return res