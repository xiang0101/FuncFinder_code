"""
@Type doc
@Author xjp
@CreateDate 2025-03-26_16:34:11
@Description 计算结果的主函数
@Version v2.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import os
import sys

sys.path.append("../")

from mytools import myFile, mergeFlow, calcSim
from graph.graph import Graph
from graph.matchGraph import matchGraph
from tqdm import tqdm
import copy

# 标准结果的读取的根路径
rootInputStd = "./data/std"

# 挖掘的结果读取的根路径
rootInputMine = "./data/mine"

name = "postgres"
stdDatasetNum = "1"
mineDatasetNum = "2"
inputStdName = name + stdDatasetNum
inputMineName = name + mineDatasetNum

# 结果标志
# 结果描述
res_description = name + stdDatasetNum + "_std," + name + mineDatasetNum + "_mine"

# 未匹配的组被标记为common(按照不同情况修改)
common = name + "_common"

# 标准的结果输入路径
inputStd = os.path.join(rootInputStd,inputStdName+"_std.json")
# 挖掘的结果输入路径
inputMine = os.path.join(rootInputMine, inputMineName + "_mine.json")


# 1.读取数据
# 标准数据
dataStd = myFile.loadJson(inputStd)
# 挖掘数据
dataMine = myFile.loadJson(inputMine)



dataMineSeq = dataMine["seq"]
dataStdSeq = dataStd["seq"]






def __compareTwoFlow(flow1:dict, flow2:dict)->bool:
    if flow1["sport"] != flow2["sport"]:
        return False
    if flow1["dport"] != flow2["dport"]:
        return False
    if flow1["proto"] != flow2["proto"]:
        return False
    if flow1["direction"] != flow2["direction"]:
        return False
    if not calcSim.simToken(flow1["payload"],flow2["payload"]):
        return False
    return True

# 确保必出现项一致
def matchSeq(seq1, seq2):
    seq1_temp = copy.deepcopy(seq1)
    seq2_temp = copy.deepcopy(seq2)
    
    # 先匹配必出现项
    for flow1 in seq1_temp:
        if flow1["flag"] == 0:
            continue
        for flow2 in seq2_temp:
            if flow2["flag"] == 0 or flow2["matched"] == True:
                continue
            if __compareTwoFlow(flow1, flow2):
                flow1["matched"] = True
                flow2["matched"] = True
    # 再匹配0项
    for flow1 in seq1_temp:
        if flow1["matched"] == True:
            continue
        for flow2 in seq2_temp:
            if flow2["matched"] == True:
                continue
            if __compareTwoFlow(flow1, flow2):
                flow1["matched"] = True
                flow2["matched"] = True
    #判断是否有未匹配的项
    for flow in seq1_temp:
        if flow["matched"] == False and flow["flag"] == 1:
            return False
    for flow in seq2_temp:
        if flow["matched"] == False and flow["flag"] == 1:
            return False
    return True
    
match_res = {}
for key1 in dataMineSeq.keys():
    print(key1)
    for key2 in dataStdSeq.keys():
        if matchSeq(dataMineSeq[key1],dataStdSeq[key2]):
            match_res[key1] = key2
            break




"""
# 2.加载标准数据图
graph_stds  = {}
for key in dataStd["graph"].keys():
    graph = Graph()
    graph.importGraph(dataStd["graph"][key])
    graph_stds[key] = graph
    
    
    

# 3.加载挖掘数据图
graph_mines  = {}
for key in dataMine["graph"].keys():
    graph = Graph()
    graph.importGraph(dataMine["graph"][key])
    graph_mines[key] = graph


# 4.图匹配
# 挖掘的数据的图匹配上的标准数据的图
total = len(graph_mines.keys())
pbar = tqdm(total=total, desc="匹配图")

match_res = {}
for key1 in graph_mines.keys():
    match_res[key1] = []
    for key2 in graph_stds.keys():
        if matchGraph(graph_stds[key2], graph_mines[key1]) != -1:
            match_res[key1].append(key2)
            break
    pbar.update(1)
pbar.close()
"""



def __lookStdLabel(key, dataStd):
    res = ""
    flow = dataStd["data"][key][-1][0]
    res = flow["label"]
    return res
# 5.记录每一个被挖掘出来的组
match_group = {}
for key in match_res.keys():
    match_group[key] = __lookStdLabel(match_res[key], dataStd)

    
# 计算正常被识别为正常的数量
TN = 0
# 计算异常被识别为异常的数量
TP = 0
# 计算异常被识别为正常的数量
FN = 0
# 计算正常被识别为异常的数量
FP = 0
# 计算未识别出结果的数量
no = 0
    

def __countFlow(flow:dict)->int:
    res = 0
    if flow["direction"] == "s":
        res += 1
        res += flow["count"]
    else:
        res += 2
        res += flow["count"]*2
    return res


dataMineFlowList = dataMine["data"]
for key in dataMineFlowList.keys():
    if key in match_group.keys():
        flag = match_group[key]
    else:
        flag = "common"
    for flows in dataMineFlowList[key]:
        for flow in flows:
            count = __countFlow(flow)
            # 判断标签情况
            if flag == flow["label"] and "common" not in flow["label"]:
                # 完全匹配正确
                TP += count
            elif "common" in flag  and "common" in flow["label"]:
                TN += count
            elif flag != flow["label"] and "common" not in flow["label"] and "common" not in flag:
                FP += count
            else:
                print(flag + ":" + flow["label"])
                FN += count
            




# 结果
accuracy = (TP+TN)/(TP+TN+FP+FN)
recall = TP/(TP+FN)
precision = TP/(TP+FP)
F1 = 2*((precision*recall)/(precision+recall))

# 先读取结果文件
res = myFile.loadJson("./res/res.json")
if name not in res.keys():
    res[name] = {}
index = 1
while True:
    if str(index) not in res[name].keys():
        break
    index += 1


# 保存结果
res[name][str(index)] = {
    "res":{
        "accuracy":accuracy,
        "recall":recall,
        "precision":precision,
        "F1-score":F1
        },
    "description":res_description,
    "count":{
        "TP":TP,
        "TN":TN,
        "FP":FP,
        "FN":FN
        }
    }

print(res)

myFile.saveJson("./res/res.json", res)



