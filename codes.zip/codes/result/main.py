"""
@Type doc
@Author xjp
@CreateDate 2025-03-26_16:34:11
@Description 计算结果的主函数
@Version v1.0 
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import os
import sys

sys.path.append("../")

from mytools import myFile, mergeFlow
from graph2.graph import Graph
from graph2.matchGraph import matchGraphs
from tqdm import tqdm


# 标准结果的读取的根路径
rootInputStd = "./data/std"

# 挖掘的结果读取的根路径
rootInputMine = "./data/mine"

name = "postgres"
stdDatasetNum = "1"
mineDatasetNum = "2"
inputStdName = name + stdDatasetNum
inputMineName = name + mineDatasetNum

# 结果标志
# 结果描述
res_description = name + stdDatasetNum + "_std," + name + mineDatasetNum + "_mine"

# 未匹配的组被标记为common(按照不同情况修改)
common = name + "_common"

# 标准的结果输入路径
inputStd = os.path.join(rootInputStd,inputStdName+"_std.json")
# 挖掘的结果输入路径
inputMine = os.path.join(rootInputMine, inputMineName + "_mine.json")


# 1.读取数据
# 标准数据
dataStd = myFile.loadJson(inputStd)
# 挖掘数据
dataMine = myFile.loadJson(inputMine)


# 2.加载标准数据图
graph_stds  = {}
for key in dataStd["graph"].keys():
    graph = Graph()
    graph.importGraph(dataStd["graph"][key])
    graph_stds[key] = graph
    
    
    

# 3.加载挖掘数据图
graph_mines  = {}
for key in dataMine["graph"].keys():
    graph = Graph()
    graph.importGraph(dataMine["graph"][key])
    graph_mines[key] = graph


# 4.图匹配
# 挖掘的数据的图匹配上的标准数据的图
total = len(graph_mines.keys())
pbar = tqdm(total=total, desc="匹配图")

match_res = {}
for key1 in graph_mines.keys():
    match_res[key1] = {}
    for key2 in graph_stds.keys():
        match_res[key1][key2] = matchGraphs(graph_stds[key2], graph_mines[key1])
    pbar.update(1)
pbar.close()

# 保留概率最高的值
match_res_temp = {}
for key1 in match_res.keys():
    temp = -1
    key_res =""
    for key2 in match_res[key1].keys():
        if match_res[key1][key2] > temp:
            temp = match_res[key1][key2]
            key_res = key2
    match_res_temp[key1] = {
        key_res:temp
        }
    



def __lookStdLabel(key, dataStd):
    res = ""
    flow = dataStd["data"][key][0][0]
    res = flow["label"]
    return res
# 5.记录每一个被挖掘出来的组
match_group = {}
for key1 in match_res_temp.keys():
    for key2 in match_res_temp[key1].keys():
        if match_res_temp[key1][key2] <=0:
            match_group[key1] = "common"
        else:
            match_group[key1] = __lookStdLabel(key2, dataStd)

    
# 计算正常被识别为正常的数量
TN = 0
# 计算异常被识别为异常的数量
TP = 0
# 计算异常被识别为正常的数量
FN = 0
# 计算正常被识别为异常的数量
FP = 0
# 计算未识别出结果的数量
no = 0
    

def __countFlow(flow:dict)->int:
    res = 0
    if flow["direction"] == "s":
        res += 1
        res += flow["count"]
    else:
        res += 2
        res += flow["count"]*2
    return res



# 6.统计计算结果
dataMineFlowList = dataMine["data"]
for key in match_group.keys():
    flow_list = dataMineFlowList[key]
    for flows in flow_list:
        for flow in flows:
            # 先计算流量数量
            count = __countFlow(flow)
            # 判断标签情况
            if match_group[key] == flow["label"] and "common" not in flow["label"]:
                # 完全匹配正确
                TP += count
            elif match_group[key] == flow["label"] and "common" in flow["label"]:
                TN += count
            elif match_group[key] != flow["label"] and "common" not in flow["label"]:
                FP += count
            else:
                FN += count




# 结果
accuracy = (TP+TN)/(TP+TN+FP+FN)
recall = TP/(TP+FN)
precision = TP/(TP+FP)
F1 = 2*((precision*recall)/(precision+recall))

# 先读取结果文件
res = myFile.loadJson("./res/res.json")
if name not in res.keys():
    res[name] = {}
index = 1
while True:
    if str(index) not in res[name].keys():
        break
    index += 1


# 保存结果
res[name][str(index)] = {
    "res":{
        "accuracy":accuracy,
        "recall":recall,
        "precision":precision,
        "F1-score":F1
        },
    "description":res_description,
    "count":{
        "TP":TP,
        "TN":TN,
        "FP":FP,
        "FN":FN
        }
    }

print(res)

myFile.saveJson("./res/res.json", res)



