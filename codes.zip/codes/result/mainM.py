"""
@Type doc
@Author xjp
@CreateDate 2025-03-31_21:25:03
@Description 计算混合数据的结果的主函数
@Version v1.0
@Copyright Copyright (c) 2025 by xiaoxiang ,ALL Rights Reserved
"""

import os
import sys

sys.path.append("../")

from mytools import myFile, mergeFlow
from graph2.graph import Graph
from graph2.matchGraph import matchGraphs
from tqdm import tqdm
import copy

# 标准结果的读取的根路径
rootInputStd = "./data/std"

# 挖掘的结果读取的根路径
rootInputMine = "./data/mine"

# 挖掘结果的名称
nameInputMine = "mysql2+postgres2"
# 加载的std数据列表
namesInputStd = ["mysql1","postgres1"]





# 标准的结果输入路径

# 挖掘的结果输入路径
inputMine = os.path.join(rootInputMine, nameInputMine + "_mine.json")


# 1.读取数据
# 标准数据
dataStds = {}
index = 1
for name in namesInputStd:
    inputStd = os.path.join(rootInputStd,name+"_std.json")
    dataStds[str(index)] = myFile.loadJson(inputStd)
    index += 1


# 挖掘数据
dataMine = myFile.loadJson(inputMine)


# 2.加载标准数据图
graph_stds  = {}
for key1 in dataStds.keys():
    graph_stds[key1] = {}
    for key2 in dataStds[key1]["graph"].keys():
        graph = Graph()
        graph.importGraph(dataStds[key1]["graph"][key2])
        graph_stds[key1][key2] = graph
    
    
    

# 3.加载挖掘数据图
graph_mines  = {}
for key in dataMine["graph"].keys():
    graph = Graph()
    graph.importGraph(dataMine["graph"][key])
    graph_mines[key] = graph



total = len(graph_mines.keys())
pbar = tqdm(total=total, desc="匹配图")

match_res = {}
for key1 in graph_mines.keys():
    match_res[key1] = {}
    for key2 in graph_stds.keys():
        match_res[key1][key2] = {}
        for key3 in graph_stds[key2].keys():
            match_res[key1][key2][key3] = matchGraphs(graph_stds[key2][key3], graph_mines[key1])
    pbar.update(1)
pbar.close()


# 保留概率最高的值
match_res_temp = {}
for key1 in match_res.keys():
    match_res_temp[key1] = {}
    for key2 in match_res[key1].keys():
        temp = -1
        key_res =""
        for key3 in match_res[key1][key2].keys():
            if match_res[key1][key2][key3] > temp:
                temp = match_res[key1][key2][key3]
                key_res = key3
        match_res_temp[key1][key2] = {
            key_res:temp
            }

def __lookStdLabel(key, dataStd):
    res = ""
    flow = dataStd["data"][key][0][0]
    res = flow["label"]
    return res
# 5.记录每一个被挖掘出来的组
match_group = {}
for key1 in match_res_temp.keys():
    temp = -1
    key_res1 = ""
    key_res2 = ""
    for key2 in match_res_temp[key1].keys():
        for key3 in match_res_temp[key1][key2].keys():
            if match_res_temp[key1][key2][key3] > temp:
                temp = match_res_temp[key1][key2][key3]
                key_res1 = key2
                key_res2 = key3
            
            
    if temp <=0:
        match_group[key1] = "common"
    else:
        match_group[key1] = __lookStdLabel(key_res2, dataStds[key_res1])










# 4.图匹配
# 挖掘的数据的图匹配上的标准数据的图

    

# 计算正常被识别为正常的数量
TN = 0
# 计算异常被识别为异常的数量
TP = 0
# 计算异常被识别为正常的数量
FN = 0
# 计算正常被识别为异常的数量
FP = 0
# 计算未识别出结果的数量
no = 0
    

def __countFlow(flow:dict)->int:
    res = 0
    if flow["direction"] == "s":
        res += 1
        res += flow["count"]
    else:
        res += 2
        res += flow["count"]*2
    return res



# 6.统计计算结果
dataMineFlowList = dataMine["data"]
for key in match_group.keys():
    flow_list = dataMineFlowList[key]
    for flows in flow_list:
        for flow in flows:
            # 先计算流量数量
            count = __countFlow(flow)
            # 判断标签情况
            if match_group[key] == flow["label"] and "common" not in flow["label"]:
                # 完全匹配正确
                TP += count
            elif match_group[key] == flow["label"] and "common" in flow["label"]:
                TN += count
            elif match_group[key] != flow["label"] and "common" not in flow["label"]:
                FP += count
            else:
                FN += count




# 结果
accuracy = (TP+TN)/(TP+TN+FP+FN)
recall = TP/(TP+FN)
precision = TP/(TP+FP)
F1 = 2*((precision*recall)/(precision+recall))

    




# 6.统计计算结果




# 结果
accuracy = (TP+TN)/(TP+TN+FP+FN)
recall = TP/(TP+FN)
precision = TP/(TP+FP)
F1 = 2*((precision*recall)/(precision+recall))

# 先读取结果文件
res = myFile.loadJson("./res/res.json")
if name not in res.keys():
    res[name] = {}
index = 1
while True:
    if str(index) not in res[name].keys():
        break
    index += 1


# 保存结果
res[name][str(index)] = {
    "res":{
        "accuracy":accuracy,
        "recall":recall,
        "precision":precision,
        "F1-score":F1
        },
    "description":res_description,
    "count":{
        "TP":TP,
        "TN":TN,
        "FP":FP,
        "FN":FN
        }
    }

print(res)

myFile.saveJson("./res/res.json", res)



